"""Freeze a public-only, baseline-aligned package comparison before outcomes.

Preparation executes prior recorded physics only, never actors or teachers.
Publish the exact registration and reviewed runtime sources before execution.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import random
import time

from intent_trials import experiment as prior
from primary_campaign import core
from tests import reference_engine as engine

ROOT = core.ROOT
FORMAT = 'public-e8-aligned-package-comparison/1'
STAGE = prior.STAGE
FIELDS = tuple(core.FIELDS)
TURN = 75
ARMS = ('current', 'aligned')
KINDS = dict(current='joint-intent-public-history-mcts/1', aligned='public-e8-root-evaluation/1')
SEARCH = dict(prior.SEARCH)
CAUSAL_PINS = {
    'intent_trials/evidence/causal_001/registration.json': '51ec970ed61401fcdfa629bda061a9f132bc6d51694429d0ed3bf19802c4191e',
    'intent_trials/evidence/causal_001/preregistration_evidence.json': 'ab0636d62d20864284fcab28ca67a2a20c88461589a22eecf2d59282e5b9b7a1',
}
METRICS = ('aligned_minus_current_pairwise', 'current_minus_baseline_pairwise',
           'aligned_minus_baseline_pairwise', 'hindsight_opportunity_pairwise',
           'current_hindsight_regret_pairwise', 'aligned_hindsight_regret_pairwise')
PUBLIC_CASE_KEYS = frozenset(('turn', 'field', 'fixture', 'map_id', 'rotation_orbit',
    'public_scores', 'public_income', 'remaining_turns', 'projected_scores',
    'nearest_projected_rank_margin', 'legal_actions', 'focal_publicly_unfrozen', 'public_prefix_sha256'))


def sha(body):
    return hashlib.sha256(body).hexdigest()


def source_pins():
    # Called only by explicit preparation/validation, after the new arm exists.
    pins = prior.source_pins()
    from aligned_search import evaluator
    for name, digest in evaluator.source_pins().items():
        if name in pins and pins[name] != digest:
            raise ValueError('Current and aligned arms disagree on a runtime source')
        pins[name] = digest
    for name in ('aligned_trials/__init__.py', 'aligned_trials/experiment.py',
                 'aligned_search/__init__.py', 'aligned_search/evaluator.py'):
        pins[name] = sha((ROOT/name).read_bytes())
    return dict(sorted(pins.items()))


def _admission(stage):
    if Path(stage).resolve() != STAGE.resolve():
        raise ValueError('Only the fixed accepted TRAIN stage0 is authorized')
    return prior._admission(stage)


def _exclusions(registration, catalog):
    old = prior._exclusions(registration, catalog)
    for name, expected in CAUSAL_PINS.items():
        if sha((ROOT/name).read_bytes()) != expected:
            raise ValueError('Published causal exclusion evidence changed')
    causal = core.read_sealed(ROOT/'intent_trials/evidence/causal_001/registration.json')
    receipt = prior.oversight.strict_loads((ROOT/'intent_trials/evidence/causal_001/preregistration_evidence.json').read_bytes())
    if receipt['registration_sha256'] != CAUSAL_PINS['intent_trials/evidence/causal_001/registration.json']:
        raise ValueError('Causal exclusion registration binding changed')
    maps = {board['id']:board for board in catalog}
    selected = causal['selected']
    if len(selected) != 16 or len({case['map_id'] for case in selected}) != 16:
        raise ValueError('All sixteen distinct earlier causal maps must be excluded')
    causal_orbits = []
    for case in selected:
        board = maps[case['map_id']]
        if board['phase'] != 'train' or case['rotation_orbit'] != board['rotation_orbit']:
            raise ValueError('Causal exclusions disagree with TRAIN catalog metadata')
        causal_orbits.append(board['rotation_orbit'])
    union = sorted(set(old['coaching_rotation_orbits']+old['forecast_pilot_rotation_orbits']+causal_orbits))
    return dict(prior_experiments=old, causal_source_sha256=dict(CAUSAL_PINS),
        causal_map_ids=[case['map_id'] for case in selected], causal_rotation_orbits=causal_orbits,
        union_rotation_orbits=union,
        policy='Strict union of all8 old coaching, all16 predictor and all16 causal001 map orbits; no relaxation or outcome-based replacement.')


def select_cases(candidates, excluded_orbits):
    eligible = []
    for case in candidates:
        if set(case) != PUBLIC_CASE_KEYS:
            raise ValueError('Selection accepts only declared public features and task metadata')
        if case['turn'] != TURN:
            continue
        if (case['focal_publicly_unfrozen'] is not True or len(case['legal_actions']) != 6
                or set(case['legal_actions']) != set(engine.ACTIONS)):
            continue
        if (type(case['nearest_projected_rank_margin']) is not int or case['nearest_projected_rank_margin'] < 0
                or case['remaining_turns'] != 6 or any(type(v) is not int for v in case['public_scores']+case['public_income'])
                or len(case['public_scores']) != 4 or len(case['public_income']) != 4
                or case['projected_scores'] != [score+6*rate for score,rate in zip(case['public_scores'],case['public_income'])]):
            raise ValueError('Exact turn75 public accounting features required')
        eligible.append(case)
    used, selected = set(excluded_orbits), []
    for field in FIELDS:
        for _ in range(4):
            pool = [case for case in eligible if case['field'] == field and case['rotation_orbit'] not in used]
            if not pool:
                raise ValueError('Insufficient distinct strictly nonexcluded turn75 all-six-action maps; never replace or relax')
            chosen = min(pool,key=lambda case:(case['nearest_projected_rank_margin'],case['fixture']))
            selected.append(copy.deepcopy(chosen)); used.add(chosen['rotation_orbit'])
    return selected


def _prefixes(stage, registration, selected):
    fixtures = {f['id']:f for f in registration['fixtures']}
    wanted, rows = {case['fixture'] for case in selected}, {}
    with (stage/'games.jsonl').open('rb') as handle:
        for line in handle:
            row = prior.oversight.strict_loads(line)
            if row['fixture'] in wanted:
                if row['fixture'] in rows:
                    raise ValueError('Duplicate selected prefix source row')
                rows[row['fixture']] = row
    if set(rows) != wanted:
        raise ValueError('Complete selected prefix source rows required')
    prefixes = []
    for case in selected:
        # Frozen helper reads accepted prior actions only; no root/future tape.
        job = prior.public_job(fixtures[case['fixture']],rows[case['fixture']],case,202611092400)
        prefixes.append(dict(initial_observation=job['initial_observation'],transitions=job['transitions']))
    return prefixes


def _facts(stage):
    stage = Path(stage).resolve()
    registration, files = _admission(stage)
    manifest, catalog = core.load_catalog(stage.parent)  # metadata, never reserved outcomes
    core.validate_registration(registration,manifest,catalog)
    exclusions = _exclusions(registration,catalog)
    candidates = prior._selection_candidates(stage,registration)
    selected = select_cases(candidates,exclusions['union_rotation_orbits'])
    prefixes = _prefixes(stage,registration,selected)
    return dict(stage_directory=str(stage),campaign_id=registration['campaign_id'],generation=0,
        stage_files_sha256=files,accepted_snapshot_sha256=prior.SNAPSHOT_SHA256,
        manifest_sha256=sha((stage.parent/'manifest.json').read_bytes()),
        catalog_sha256=sha((stage.parent/'catalog.json').read_bytes()),candidate_sha256=core.INCUMBENT,
        exclusions=exclusions,eligible_public_roots=sum(c['turn']==75 and len(c['legal_actions'])==6 for c in candidates),
        selected=selected,public_prefixes=prefixes)


def _protocol(facts):
    selected, prefixes = facts['selected'],facts['public_prefixes']
    if len(selected) != 16 or len(prefixes) != 16:
        raise ValueError('Sixteen complete public prefixes are required before registration')
    for case,prefix in zip(selected,prefixes):
        if (set(prefix) != {'initial_observation','transitions'} or len(prefix['transitions']) != 74
                or sha(core.canonical(prefix)) != case['public_prefix_sha256']):
            raise ValueError('Exact complete preregistered turn75 public prefixes required')
    return dict(format=FORMAT,**facts,source_sha256=source_pins(),arms=list(ARMS),
        comparison='Package comparison: future-control target, root paired allocation versus adaptive tree allocation, sampling coupling and baseline tie rule change together. No one-factor causal attribution.',
        selection=dict(turn=75,fields=list(FIELDS),order='Field-major; select four greedily per fixed field, globally distinct rotation orbits.',
            eligibility='Focal publicly unfrozen; all six public legal actions; no excluded orbit.',
            rank='Minimum nearest focal-versus-rival absolute score+(81-75)*income margin, then ascending fixture SHA256.',
            forbidden='No current/future source action, final outcome, true controller/type/seed or measured headroom in selection.'),
        search=dict(SEARCH,seeds=[202611092400+i for i in range(16)],
            coupling='Same complete public prefix and diagnostic seed in both arms. Current adaptive96 trajectories versus aligned16 paired worlds times6 roots; not identical trajectories. Shared public/model RNG domains provide marginal coupling only.',
            work='Per arm per case96 root trajectories times6 turns=576 two-referee transitions. Aligned evaluates16 paired worlds for every one of6 roots; extra e8 own-policy inference/callback cost is reported.',
            order='Current arm then aligned arm for every registered case; offline timing is bookkeeping, not deployment qualification.'),
        kinds=dict(KINDS),baseline_binding='Aligned public-reconstructed baseline_action must equal actual accepted source root action, observed only after both recommendations, and regenerated unchanged baseline root action. Any mismatch aborts whole experiment.',
        intervention='Frozen intent_trials.continuation: replace one accepted focal action after simultaneous proposals, synchronize last accepted-action memory, retain original planner intent, then exact e8 continuation with actual responding rivals. Hybrid diagnostic.',
        branches='One shared complete set of6 legal root counterfactuals plus unchanged baseline per case; all80turns,320callbacks and both referees. Each branch fresh controllers/RNG. Explicit baseline root must reproduce entire original tape and scores. No future tape after deviation.',
        metrics=list(METRICS),primary_contrast=METRICS[0],
        analysis='Primary equal-field paired final officialPW aligned recommendation minus current recommendation, both0..3, evaluated on the SAME realized complete root branch set. Secondary each versus baseline, hindsight opportunity and each regret; no oracle selection for either recommendation.',
        bootstrap=dict(replicates=20000,seed=202611092430,quantile_indices=[499,19499],
            allocation='Resample four whole selected map records within each fixed field with replacement; equal field weights.',
            algorithm='stdlib Random(seed).randrange(4), replicate-major then FIELDS order then four draws; registered case order within field; identical draw indices for all six metrics.',
            scope='Unadjusted descriptive95% percentile intervals on selected consumed TRAIN sample, four maps per field and one seed per arm/case; no fresh-policy, simultaneous or universal strength guarantee.'),
        failure_policy='Any unsupported history/cap, baseline mismatch, source mutation, invalid teacher/branch, deadline/fallback, missing case/arm/action or nonfinite metric aborts whole experiment. Preserve BaseException active/partial evidence and re-raise same object; no retry, tuning, cap change, case replacement or silent omission.',
        execution_gate='Publish and commit exact sealed registration, all16 public prefixes and reviewed frozen runtime pins BEFORE execute. This is a manual publication gate; preparation makes zero teacher/controller calls or outcomes.',
        data_scope='Consumed accepted TRAIN stage0 only. Catalog metadata validates exclusion/TRAIN identity; never reserved development/final outcomes. Package diagnostic, not fresh-policy confirmation.',
        primary_games=0,completed_per_game_bmcts_audits=0,promoted=False)


def prepare(stage, output):
    output = Path(output).resolve()
    if output.exists() or output.is_relative_to(Path(stage).resolve().parent):
        raise ValueError('Fresh output outside immutable primary campaign required')
    before = source_pins()
    protocol = _protocol(_facts(stage))
    if before != protocol['source_sha256'] or before != source_pins():
        raise ValueError('Runtime source changed during outcome-free preparation')
    output.mkdir(parents=True,exist_ok=False)
    for i,prefix in enumerate(protocol['public_prefixes']):
        core.seal(output/('public_prefix_%02d.json'%i),prefix)
    core.seal(output/'registration.json',protocol)
    return protocol


def _validated(directory):
    directory = Path(directory)
    protocol = core.read_sealed(directory/'registration.json')
    if protocol['source_sha256'] != source_pins():
        raise ValueError('Exact aligned comparison runtime source changed')
    expected = _protocol(_facts(Path(protocol['stage_directory'])))
    if core.canonical(protocol) != core.canonical(expected):
        raise ValueError('Exact aligned comparison protocol/source/case/claim changed, even if rehashed')
    for i,prefix in enumerate(expected['public_prefixes']):
        if core.canonical(core.read_sealed(directory/('public_prefix_%02d.json'%i))) != core.canonical(prefix):
            raise ValueError('Registered public prefix file changed')
    return protocol


def statistics(cases, protocol):
    selected = protocol['selected']
    if len(cases) != 16 or len(selected) != 16 or any(core.canonical(r['case']) != core.canonical(c) for r,c in zip(cases,selected)):
        raise ValueError('All sixteen exact registered cases in order required')
    groups = [[i for i,c in enumerate(selected) if c['field']==f] for f in FIELDS]
    if (any(len(g)!=4 for g in groups) or len({c['rotation_orbit'] for c in selected})!=16
            or len({c['fixture'] for c in selected})!=16):
        raise ValueError('Four distinct maps per field and sixteen globally distinct orbits required')
    values = {name:[r[name] for r in cases] for name in METRICS}
    if any(type(v) not in (int,float) or not -3<=v<=3 or v*2!=int(v*2) for rows in values.values() for v in rows):
        raise ValueError('Finite official half-point pairwise metrics required for every arm/case')
    for r in cases:
        a,b,gap = r[METRICS[2]],r[METRICS[1]],r[METRICS[3]]
        if (r[METRICS[0]] != a-b or gap < max(0,a,b) or r[METRICS[4]] != gap-b or r[METRICS[5]] != gap-a):
            raise ValueError('Shared-branch primary, baseline and hindsight metrics disagree')
        if any(r[name] not in r['case']['legal_actions'] for name in ('current_action','aligned_action','baseline_action')):
            raise ValueError('Both recommendations and baseline must be registered legal actions')
        if ((r['aligned_action']==r['current_action'] and r[METRICS[0]]!=0)
                or (r['current_action']==r['baseline_action'] and b!=0)
                or (r['aligned_action']==r['baseline_action'] and a!=0)):
            raise ValueError('Identical root actions cannot have different shared-branch outcomes')
    rng,draws = random.Random(protocol['bootstrap']['seed']),hashlib.sha256()
    samples = {name:[] for name in METRICS}
    for _ in range(protocol['bootstrap']['replicates']):
        indices = [group[rng.randrange(4)] for group in groups for _ in range(4)]
        draws.update(bytes(indices))
        for name in METRICS:
            samples[name].append(sum(values[name][i] for i in indices)/16)
    lo,hi = protocol['bootstrap']['quantile_indices']
    summaries = {}
    for name in METRICS:
        samples[name].sort(); rows=values[name]
        summaries[name] = dict(mean_delta_pairwise=sum(rows)/16,
            descriptive95_interval=[samples[name][lo],samples[name][hi]],
            fields={field:sum(rows[i] for i in group)/4 for field,group in zip(FIELDS,groups)})
    primary = values[METRICS[0]]
    return dict(primary_contrast=METRICS[0],metrics=summaries,
        bootstrap=dict(protocol['bootstrap'],shared_draw_indices_sha256=draws.hexdigest()),
        aligned_better=sum(v>0 for v in primary),current_better=sum(v<0 for v in primary),ties=sum(v==0 for v in primary),
        recommendations_differ=sum(r['current_action']!=r['aligned_action'] for r in cases),
        current_changes_baseline=sum(r['current_action']!=r['baseline_action'] for r in cases),
        aligned_changes_baseline=sum(r['aligned_action']!=r['baseline_action'] for r in cases))


def _teacher(arm, job):
    if arm == 'current':
        from intent_search.mcts import recommend
    elif arm == 'aligned':
        from aligned_search.evaluator import recommend
    else:
        raise ValueError('Unknown fixed arm')
    return recommend(job)


def execute(directory):
    directory = Path(directory).resolve(); claim=directory/'.execution_claim'
    if claim.exists() or (directory/'execution_started.json').exists() or (directory/'results.json').exists():
        raise ValueError('Preserve completed/partial evidence; no automatic retry')
    protocol = _validated(directory); claim.mkdir(exist_ok=False)
    core.seal(directory/'execution_started.json',dict(format=FORMAT,registration_sha256=sha((directory/'registration.json').read_bytes()),primary_games=0))
    completed,active = [],dict(case=None,phase=None)
    try:
        stage=Path(protocol['stage_directory']); registration=core.read_sealed(stage/'registration.json')
        candidate=next(c for c in registration['candidates'] if c['sha256']==core.INCUMBENT)
        fixtures={f['id']:f for f in registration['fixtures']}; wanted={c['fixture'] for c in protocol['selected']}; rows={}
        with (stage/'games.jsonl').open('rb') as handle:
            for line in handle:
                row=prior.oversight.strict_loads(line)
                if row['fixture'] in wanted:
                    if row['fixture'] in rows: raise ValueError('Duplicate selected source row')
                    rows[row['fixture']]=row
        if set(rows)!=wanted: raise ValueError('Missing selected source row')
        for i,case in enumerate(protocol['selected']):
            fixture,row=fixtures[case['fixture']],rows[case['fixture']]; recommendations={}; durations={}
            for arm in ARMS:
                active.update(case=i,phase=arm)
                job=dict(schema=1,kind=KINDS[arm],root_id='aligned-comparison-case-%02d'%i,
                    **copy.deepcopy(protocol['public_prefixes'][i]),search=dict(SEARCH,seed=protocol['search']['seeds'][i]))
                core.seal(directory/('%s_input_%02d.json'%(arm,i)),job)
                started=time.perf_counter(); teacher=_teacher(arm,job); durations[arm]=time.perf_counter()-started
                core.seal(directory/('%s_%02d.json'%(arm,i)),teacher)
                if teacher['recommended_action'] not in case['legal_actions']:
                    raise ValueError('Teacher selected illegal root action')
                recommendations[arm]=teacher
            # Only the observer now consults the actual root action, never either teacher.
            source_action=row['actions'][74][fixture['seat']]
            if recommendations['aligned']['baseline_action'] != source_action:
                raise ValueError('Public-reconstructed aligned baseline action differs from actual source root')
            active['phase']='baseline'; runtime_case=dict(fixture=fixture,row=row,turn=TURN)
            baseline=prior.continuation(candidate,runtime_case,registration['sources'])
            core.seal(directory/('baseline_%02d.json'%i),baseline)
            if baseline['actions'][74][fixture['seat']] != source_action:
                raise ValueError('Regenerated baseline root differs from source/public baseline')
            branches={}
            for action in case['legal_actions']:
                active['phase']='branch:'+action
                branches[action]=prior.continuation(candidate,runtime_case,registration['sources'],action)
                core.seal(directory/('branch_%02d_%s.json'%(i,action)),branches[action])
            explicit=branches[source_action]
            if any(explicit[k]!=baseline[k] for k in ('scores','actions','pairwise_points')):
                raise ValueError('Explicit baseline intervention changed complete baseline tape/outcome')
            current_action=recommendations['current']['recommended_action']; aligned_action=recommendations['aligned']['recommended_action']
            base=baseline['pairwise_points']; cur=branches[current_action]['pairwise_points']; aligned=branches[aligned_action]['pairwise_points']; best=max(b['pairwise_points'] for b in branches.values())
            outcome=dict(case=case,baseline_action=source_action,current_action=current_action,aligned_action=aligned_action,
                baseline=baseline,root_counterfactuals=branches,teacher_wall_seconds=durations,
                teacher_result_sha256={arm:sha((directory/('%s_%02d.json'%(arm,i))).read_bytes()) for arm in ARMS},
                aligned_minus_current_pairwise=aligned-cur,current_minus_baseline_pairwise=cur-base,
                aligned_minus_baseline_pairwise=aligned-base,hindsight_opportunity_pairwise=best-base,
                current_hindsight_regret_pairwise=best-cur,aligned_hindsight_regret_pairwise=best-aligned,
                hindsight_best_actions=[a for a in case['legal_actions'] if branches[a]['pairwise_points']==best])
            core.seal(directory/('case_%02d.json'%i),outcome); completed.append(outcome)
            print(json.dumps(dict(completed_cases=len(completed),planned=16,primary_games=0)),flush=True)
        summary=dict(format=FORMAT,registration_sha256=sha((directory/'registration.json').read_bytes()),
            cases=completed,statistics=statistics(completed,protocol),primary_games=0,completed_per_game_bmcts_audits=0,promoted=False,
            limitation='Selected consumed TRAIN one-step hybrid package comparison, not one-factor attribution, fresh-policy strength, globally optimal strategy or deployment qualification.')
        _validated(directory); core.seal(directory/'results.json',summary); return summary
    except BaseException as error:
        core.seal(directory/'error.json',dict(format=FORMAT,active=active,completed_cases=len(completed),
            exception_type=type(error).__name__,message=str(error),partial_branch=getattr(error,'branch_evidence',None),
            primary_games=0,completed_per_game_bmcts_audits=0,promoted=False,
            status='failed_whole_experiment_preserve_partial_evidence_no_retry_or_case_replacement'))
        raise


def main():
    parser=argparse.ArgumentParser(description=__doc__); commands=parser.add_subparsers(dest='command',required=True)
    prep=commands.add_parser('prepare'); prep.add_argument('--stage',type=Path,default=STAGE); prep.add_argument('--output',type=Path,required=True)
    run=commands.add_parser('execute'); run.add_argument('--directory',type=Path,required=True)
    args=parser.parse_args()
    if args.command=='prepare':
        plan=prepare(args.stage,args.output); print(json.dumps(dict(preregistered_cases=len(plan['selected']),primary_games=0)))
    else:
        print(json.dumps(execute(args.directory)['statistics']))


if __name__=='__main__': main()
