# Paused draft checkpoint

This uncommitted draft was stopped when the user redirected work to their own
GPU. It has not been frozen, preregistered, published, prepared or executed.
No real cohort selection, teacher recommendation, controller callback or
counterfactual outcome was run for this draft.

The draft describes a package comparison of current public-history search and
a baseline-aligned root evaluator. Future-control target, sampling/allocation
and tie handling change together. A result could not isolate one factor.
Both recommendations would use one complete root-counterfactual outcome set.
The proposed sample is sixteen new consumed TRAIN map orbits at turn75, four
per field, with all six legal actions and strict earlier-experiment exclusions.
Its primary contrast is aligned minus current official pairwise points;
secondary contrasts and descriptive intervals share within-field map draws.

Only four small synthetic checkpoint tests cover selection order/exclusions,
six-action/unfrozen eligibility, paired-metric consistency and elementary
stratified bootstrap arithmetic. Full source-admission, rehashed-plan,
execution/failure, arm-result compatibility and end-to-end mock tests remain
unfinished. This is not a readiness or scientific approval. The aligned
evaluator interface and cost accounting require review before any resumption.

Existing policy, study, campaign, transport and earlier evidence sources were
left unchanged. This draft grants no primary games, BMCTS audits, deployment
qualification or promotion. Follow the current local-GPU task; do not treat
this draft's CLI as authorization to prepare or run a new CPU experiment.
