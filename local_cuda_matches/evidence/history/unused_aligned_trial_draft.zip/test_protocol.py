"""Draft-checkpoint checks on synthetic metadata only; zero study/actor calls."""
import copy
import unittest

from aligned_trials import experiment as trial


def pool():
    rows=[]
    for field in trial.FIELDS:
        for i in range(8):
            identity='SYNTHETIC-%s-%02d'%(field,i)
            rows.append(dict(turn=75,field=field,fixture=identity,map_id=identity,
                rotation_orbit=identity,public_scores=[0]*4,public_income=[1]*4,
                remaining_turns=6,projected_scores=[6]*4,nearest_projected_rank_margin=i,
                legal_actions=list(trial.engine.ACTIONS),focal_publicly_unfrozen=True,
                public_prefix_sha256='a'*64))
    return rows


def cases(protocol):
    rows=[]
    for c in protocol['selected']:
        f=trial.FIELDS.index(c['field']); current=-1+.5*f
        primary=(.5,0,-.5,1)[f]; aligned=current+primary; opportunity=max(0,current,aligned)+.5
        rows.append(dict(case=copy.deepcopy(c),current_action='NORTH',aligned_action='EAST',baseline_action='STAY',
            aligned_minus_current_pairwise=primary,current_minus_baseline_pairwise=current,
            aligned_minus_baseline_pairwise=aligned,hindsight_opportunity_pairwise=opportunity,
            current_hindsight_regret_pairwise=opportunity-current,aligned_hindsight_regret_pairwise=opportunity-aligned))
    return rows


class DraftProtocolChecks(unittest.TestCase):
    def protocol(self):
        return dict(selected=trial.select_cases(pool(),[]),
                    bootstrap=dict(seed=202611092430,replicates=20000,quantile_indices=[499,19499]))

    def test_field_major_minimum_margin_selection_is_order_independent_and_strictly_excluded(self):
        candidates=pool(); excluded=[candidates[0]['rotation_orbit']]
        selected=trial.select_cases(candidates,excluded)
        self.assertEqual(selected,trial.select_cases(list(reversed(candidates)),excluded))
        self.assertEqual([c['field'] for c in selected],[f for f in trial.FIELDS for _ in range(4)])
        self.assertEqual(selected[0]['nearest_projected_rank_margin'],1)
        self.assertEqual(len({c['rotation_orbit'] for c in selected}),16)
        self.assertFalse(set(excluded)&{c['rotation_orbit'] for c in selected})

    def test_missing_sixth_action_frozen_root_or_insufficient_distinct_maps_is_not_relaxed(self):
        for mode in ('missing-action','frozen','excluded'):
            candidates=pool()
            for c in candidates:
                if c['field']==trial.FIELDS[0]:
                    if mode=='missing-action': c['legal_actions'].remove('SHIELD')
                    if mode=='frozen': c['focal_publicly_unfrozen']=False
            exclusions=[c['rotation_orbit'] for c in candidates] if mode=='excluded' else []
            with self.subTest(mode=mode),self.assertRaises(ValueError):
                trial.select_cases(candidates,exclusions)

    def test_paired_metric_and_field_bootstrap_arithmetic_on_synthetic_constant_strata(self):
        protocol=self.protocol(); output=trial.statistics(cases(protocol),protocol)
        primary=output['metrics']['aligned_minus_current_pairwise']
        self.assertEqual(primary['mean_delta_pairwise'],.25)
        self.assertEqual(primary['descriptive95_interval'],[.25,.25])
        self.assertEqual(output['aligned_better'],8)
        self.assertEqual(output['current_better'],4)
        self.assertEqual(output['ties'],4)
        self.assertEqual(output['recommendations_differ'],16)
        self.assertEqual(len(output['bootstrap']['shared_draw_indices_sha256']),64)

    def test_missing_reassigned_nonfinite_and_inconsistent_shared_branch_metrics_are_rejected(self):
        protocol=self.protocol(); original=cases(protocol)
        bads=[original[:-1],list(reversed(original))]
        for key,value in [('aligned_minus_current_pairwise',float('nan')),
                          ('aligned_minus_current_pairwise',.25),('hindsight_opportunity_pairwise',-.5),
                          ('current_hindsight_regret_pairwise',3)]:
            bad=copy.deepcopy(original); bad[0][key]=value; bads.append(bad)
        bad=copy.deepcopy(original); bad[0]['aligned_action']=bad[0]['current_action']; bads.append(bad)
        for i,bad in enumerate(bads):
            with self.subTest(corruption=i),self.assertRaises(ValueError):
                trial.statistics(bad,protocol)


if __name__=='__main__': unittest.main()
