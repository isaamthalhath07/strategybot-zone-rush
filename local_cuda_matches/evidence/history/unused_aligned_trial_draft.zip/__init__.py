"""Preregistered package comparisons on consumed public TRAIN positions."""
