"""Generated helper launcher: actual CPU qualification, never primary credit."""
import hashlib,json,os,platform,subprocess,sys,zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
CONFIG=json.loads((ROOT/'delivery.json').read_text(encoding='utf8'))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def package():
    payload=ROOT/'worker_payload.zip'
    if sha(payload.read_bytes())!=CONFIG['inner_archive_sha256']:
        raise ValueError('The worker ZIP changed. Keep this folder and contact the owner.')
    worker=ROOT/'worker'
    if not worker.exists():
        with zipfile.ZipFile(payload) as zipped:
            for item in zipped.infolist():
                target=(worker/item.filename).resolve()
                if not target.is_relative_to(worker.resolve()) or Path(item.filename).is_absolute() or ':' in item.filename:
                    raise ValueError('Unsafe worker archive path')
            zipped.extractall(worker)
    manifest=worker/'bundle.json'
    if sha(manifest.read_bytes())!=CONFIG['bundle_sha256']:
        raise ValueError('The worker manifest changed. Do not replace results; contact the owner.')
    value=json.loads(manifest.read_text(encoding='utf8'))
    for relative,expected in value['files'].items():
        path=(worker/relative).resolve()
        if not path.is_relative_to(worker.resolve()) or sha(path.read_bytes())!=expected:
            raise ValueError('A worker source changed or extraction is incomplete. Keep this folder and contact the owner.')
    if value['target_slot']!=CONFIG['slot'] or value['work_role']!='qualify' or len(value['fixtures'])!=8:
        raise ValueError('This is not the expected eight-match qualification assignment')
    return worker

def choose_credential():
    try:
        import tkinter
        from tkinter import filedialog
        window=tkinter.Tk()
        window.withdraw()
        selected=filedialog.askopenfilename(title='Choose the PRIVATE credential sent separately for '+CONFIG['slot']['slot_id'],filetypes=[('Private helper credential','*.json')])
        window.destroy()
        if not selected:
            raise ValueError('No private credential selected; nothing was run')
        return Path(selected).resolve()
    except ImportError:
        return Path(input('Paste the full path to your separately supplied PRIVATE credential JSON: ').strip().strip('"')).resolve()

def main():
    worker=package()
    if '--check-package' in sys.argv:
        print(json.dumps({'package_verified':True,'runtime_executable':sys.executable,'python_version':platform.python_version(),'slot':CONFIG['slot']['slot_id'],'planned_known_full_matches':8,'games_executed':0,'primary_games_accepted':0,'gpu_used':False}))
        return
    if sys.implementation.name!='cpython' or sys.version_info[:2]!=(3,12) or sys.version_info.releaselevel!='final':
        raise ValueError('Select an existing CPython 3.12 release, including your old compute_share/.venv-worker. No installation is required.')
    print('First compatibility check: 8 real full matches and a complete replay of every actor.')
    print('Your CPU runs these Python bots. The GPU is not used by this job.')
    print('Runtime: CPython '+platform.python_version()+'. New campaign work follows owner approval.')
    sys.path.insert(0,str(worker))
    from distributed_campaign import auth
    local=Path(os.environ['LOCALAPPDATA'])/'ZoneRushPrivate'/('architecture-v2-'+CONFIG['slot']['slot_id'])
    credential=local/'credential.json'
    if not credential.exists():
        source=choose_credential()
        if source.stat().st_size>512*1024:
            raise ValueError('Credential file exceeds the allowed size')
        from distributed_campaign import protocol
        transfer=protocol.loads(source.read_bytes())
        if {'slot_id':transfer.get('slot_id'),'physical_slot_id':transfer.get('physical_slot_id')}!=CONFIG['slot']:
            raise ValueError('That private credential belongs to another laptop. Ask the owner for your own file.')
        print('First setup: copying only your helper key into a dedicated private local folder.')
        print('The folder is restricted to your Windows account before the key is written.')
        auth.import_credentials(source,local)
    if auth.public_identity(auth.load_credentials(credential))!=CONFIG['slot']:
        raise ValueError('Existing private configuration belongs to another helper; contact the owner')
    results=ROOT/'results'
    command=[sys.executable,'-m','distributed_campaign.worker','--root',str(worker),
             '--expected-manifest-sha',CONFIG['bundle_sha256'],'--output',str(results),
             '--workers','2','--credentials',str(credential)]
    print('Running the 8 full matches plus all-actor/two-referee audits. Please keep this window open.')
    process=subprocess.run(command,cwd=worker,capture_output=True,text=True)
    if process.returncode:
        raise RuntimeError((process.stderr or process.stdout)[-4000:])
    progress=json.loads((results/'progress.json').read_text(encoding='utf8'))
    if progress.get('complete') is not True or progress.get('completed_games')!=8:
        raise ValueError('The eight assigned checks are incomplete. Run this launcher again to resume.')
    returned=ROOT/('RETURN_TO_OWNER_'+CONFIG['slot']['slot_id']+'.zip')
    with zipfile.ZipFile(returned,'w',compression=zipfile.ZIP_DEFLATED) as zipped:
        for name in ('header.json','records.jsonl','progress.json'):
            zipped.write(results/name,name)
    print('Completed full 80-turn matches: 8. Owner acceptance is pending.')
    print('Primary games credited: 0. These repeat the fixed study references for runtime qualification.')
    print('Send ONLY this file to the owner: '+str(returned))
    print('Never send your private credential file or ZoneRushPrivate folder.')

if __name__=='__main__':
    try:
        main()
    except Exception as error:
        print('STOPPED: '+str(error),file=sys.stderr)
        print('Keep this folder and its results. Send the error text to the owner.',file=sys.stderr)
        sys.exit(1)
