$ErrorActionPreference = 'Stop'
function Test-ZrPython([string] $zrPath) {
    try {
        $zrProbe = & $zrPath -c 'import sys; print(sys.version)' 2>$null
        $zrFirst = $zrProbe | Select-Object -First 1
        return ($LASTEXITCODE -eq 0 -and $zrFirst -match '^3\.12\.\d+ \(')
    } catch { return $false }
}
try {
    Write-Host 'Looking for your existing Python worker. No installation is performed.'
    $zrCandidates = @(
        (Join-Path $PSScriptRoot 'compute_share\.venv-worker\Scripts\python.exe'),
        (Join-Path $PSScriptRoot '..\compute_share\.venv-worker\Scripts\python.exe'),
        (Join-Path $PSScriptRoot '..\..\compute_share\.venv-worker\Scripts\python.exe'),
        (Join-Path $env:USERPROFILE 'ZoneRush\compute_share\.venv-worker\Scripts\python.exe'),
        (Join-Path $env:USERPROFILE 'Downloads\compute_share\.venv-worker\Scripts\python.exe')
    )
    $zrPython = $null
    foreach ($zrCandidate in $zrCandidates) {
        if ((Test-Path -LiteralPath $zrCandidate -PathType Leaf) -and (Test-ZrPython $zrCandidate)) {
            $zrPython = $zrCandidate
            break
        }
    }
    if (-not $zrPython) {
        if (Get-Command py -ErrorAction SilentlyContinue) {
            try {
                $zrResolved = & py -3.12 -c 'import sys; print(sys.executable)' 2>$null
                if ($LASTEXITCODE -eq 0 -and $zrResolved) {
                    $zrSelected = $zrResolved | Select-Object -Last 1
                    if ((Test-Path -LiteralPath $zrSelected -PathType Leaf) -and (Test-ZrPython $zrSelected)) { $zrPython = $zrSelected }
                }
            } catch { $zrPython = $null }
        }
    }
    if (-not $zrPython) {
        Add-Type -AssemblyName System.Windows.Forms
        $zrDialog = New-Object System.Windows.Forms.OpenFileDialog
        $zrDialog.Title = 'Select Python3.12 python.exe from your previous compute_share\.venv-worker\Scripts folder'
        $zrDialog.Filter = 'Python interpreter (python.exe)|python.exe'
        $zrDialog.InitialDirectory = Join-Path $env:USERPROFILE 'Downloads'
        if ($zrDialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'No Python selected. No matches were run.' }
        $zrPython = $zrDialog.FileName
        $zrDialog.Dispose()
        if (-not (Test-ZrPython $zrPython)) { throw 'Please select an existing Python3.12 release. No matches were run.' }
    }
    $zrArguments = @((Join-Path $PSScriptRoot 'RUN_CHECK.py'))
    if ($env:ZONE_RUSH_CHECK_PACKAGE_ONLY -eq '1') { $zrArguments += '--check-package' }
    & $zrPython @zrArguments
    $zrExit = $LASTEXITCODE
    if ($env:ZONE_RUSH_CHECK_PACKAGE_ONLY -ne '1') { Read-Host 'Press Enter to close this window' }
    exit $zrExit
} catch {
    Write-Host ('Stopped: ' + $_.Exception.Message)
    Write-Host 'Keep this folder and contact the owner. Nothing is installed.'
    if ($env:ZONE_RUSH_CHECK_PACKAGE_ONLY -ne '1') { Read-Host 'Press Enter to close this window' }
    exit 1
}
