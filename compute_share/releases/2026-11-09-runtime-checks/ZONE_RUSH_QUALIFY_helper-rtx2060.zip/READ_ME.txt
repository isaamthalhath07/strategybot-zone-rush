1. Extract this ZIP to a short folder, for example %USERPROFILE%\ZoneRush\helper-rtx2060.
2. Keep the PRIVATE credential JSON sent separately; never share it or put it in a return ZIP.
3. Double-click START_HERE.cmd. It reuses an existing CPython 3.12, including the earlier GPU worker environment.
4. If asked, choose python.exe inside the previous compute_share\.venv-worker\Scripts folder.
5. Select your separately delivered PRIVATE credential when prompted.
6. After 8 full matches and complete actor audits, return only RETURN_TO_OWNER_helper-rtx2060.zip.

This CPU compatibility check qualifies your exact runtime for the forthcoming real study workload.
It does not install Python, torch or CUDA. Your GPU is not used by these Python policy matches.
The fixed reference outcomes count once in the study; these replicas create no primary/study credit.
Run START_HERE.cmd again to resume. Keep all files if there is an error.
