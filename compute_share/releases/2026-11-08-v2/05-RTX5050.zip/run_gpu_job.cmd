@echo off
setlocal
cd /d "%~dp0"
if not exist "compute_share\.venv-worker\Scripts\python.exe" goto missing
"compute_share\.venv-worker\Scripts\python.exe" -m compute_share.gpu_jobs run --root . --device cuda
if errorlevel 1 goto failed
echo Return result.json to the owner.
pause
exit /b 0
:missing
echo First run setup_gpu.cmd inside the compute_share folder.
pause
exit /b 1
:failed
echo Job failed. Keep this window for review. No primary games were credited.
pause
exit /b 1
