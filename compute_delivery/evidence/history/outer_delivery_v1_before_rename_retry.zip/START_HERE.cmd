@echo off
setlocal DisableDelayedExpansion
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0START_HERE.ps1"
exit /b %ERRORLEVEL%
