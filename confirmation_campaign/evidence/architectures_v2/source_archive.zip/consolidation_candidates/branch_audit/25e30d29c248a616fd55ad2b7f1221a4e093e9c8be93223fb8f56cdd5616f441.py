"""Shared helpers for the opponent zoo (the submitted bot.py is self-contained)."""
from collections import deque as _m0_deque
_m0_N = 8
_m0_NC = 64
_m0_MOVES = (('NORTH', -8), ('SOUTH', 8), ('WEST', -1), ('EAST', 1))
_m0_CORNERS = (0, 7, 63, 56)
_m0_NEIGH = []
for _m0__p in range(_m0_NC):
    _m0__r, _m0__c = divmod(_m0__p, _m0_N)
    _m0__a = []
    if _m0__r > 0:
        _m0__a.append(_m0__p - _m0_N)
    if _m0__r < _m0_N - 1:
        _m0__a.append(_m0__p + _m0_N)
    if _m0__c > 0:
        _m0__a.append(_m0__p - 1)
    if _m0__c < _m0_N - 1:
        _m0__a.append(_m0__p + 1)
    _m0_NEIGH.append(tuple(_m0__a))

def _m0_parse(view):
    """Flatten the Cell board into parallel arrays. Handles both documented layouts."""
    bd = view.board
    base = [0] * _m0_NC
    owner = [0] * _m0_NC
    upg = [0] * _m0_NC
    home = [0] * _m0_NC
    occ = [0] * _m0_NC
    frz = [0] * _m0_NC
    if bd and isinstance(bd[0], (list, tuple)):
        cells = [bd[r][c] for r in range(_m0_N) for c in range(_m0_N)]
    else:
        cells = list(bd)
    for p, cl in enumerate(cells):
        base[p] = cl.base_points
        owner[p] = cl.owner
        upg[p] = 1 if cl.is_upgraded else 0
        home[p] = 1 if cl.is_home else 0
        occ[p] = cl.occupant
        frz[p] = 1 if cl.is_frozen else 0
    return (base, owner, upg, home, occ, frz)

def _m0_bfs(start, blocked=()):
    """Step distances from start; blocked cells are impassable."""
    d = [99] * _m0_NC
    d[start] = 0
    q = _m0_deque([start])
    bl = set(blocked)
    while q:
        u = q.popleft()
        du = d[u] + 1
        for w in _m0_NEIGH[u]:
            if d[w] > du and w not in bl:
                d[w] = du
                q.append(w)
    return d

def _m0_first_step(start, target, blocked=()):
    """Action name for the first step of a shortest path, or None."""
    if start == target:
        return None
    d = _m0_bfs(target, blocked)
    best, bestd = (None, d[start])
    if bestd >= 99:
        return None
    for name, delta in _m0_MOVES:
        w = start + delta
        if w in _m0_NEIGH[start] and d[w] == bestd - 1:
            return name
    return best

def _m0_man(a, b):
    ar, ac = divmod(a, _m0_N)
    br, bc = divmod(b, _m0_N)
    return abs(ar - br) + abs(ac - bc)

def _m0_zone_of(p):
    """Which seat's quadrant a cell belongs to (nearest home, ties by seat order)."""
    best, bestd = (1, 99)
    for i, c in enumerate(_m0_CORNERS):
        d = _m0_man(p, c)
        if d < bestd:
            bestd, best = (d, i + 1)
    return best

def _m0_my_cells(owner, seat):
    return [p for p in range(_m0_NC) if owner[p] == seat]

def _m0_rivals_on_my_land(owner, occ, frz, seat):
    """Rival seats standing on a cell I own, excluding already-frozen ones."""
    out = []
    for p in range(_m0_NC):
        o = occ[p]
        if o and o != seat and (owner[p] == seat) and (not frz[p]):
            out.append((p, o))
    return out

"""
Opponent archetypes.

These are the field. GreedyValue / GreedyShield are my best guess at what an LLM
writes unprompted from the rulebook; the rest are the plausible deliberate designs.
Each class is instantiated once per seat per game, so instance state is per-game.
"""
import random as _m1_random

class _m1_Base(object):
    name = 'base'

    def __init__(self, seed=0):
        self.rnd = _m1_random.Random(seed)
        self.turn = 0

    def __call__(self, view):
        self.turn += 1
        try:
            a = self.act(view)
        except Exception:
            a = 'STAY'
        if a not in view.legal_actions:
            a = 'STAY'
        return a

    def act(self, view):
        return 'STAY'

    def read(self, view):
        self.base, self.owner, self.upg, self.home, self.occ, self.frz = _m0_parse(view)
        self.seat = view.bot_id
        self.me = self.occ.index(self.seat)
        self.blocked = set((p for p in range(_m0_NC) if self.occ[p] and p != self.me))
        return self.me

    def step_to(self, target):
        a = _m0_first_step(self.me, target, self.blocked)
        if a is None:
            a = _m0_first_step(self.me, target)
        return a or 'STAY'

class _m1_StayBot(_m1_Base):
    """The unmodified skeleton. A bot that crashes plays exactly this."""
    name = 'stay'

class _m1_RandomBot(_m1_Base):
    name = 'random'

    def act(self, view):
        la = [a for a in view.legal_actions if a != 'SHIELD']
        if 'SHIELD' in view.legal_actions and self.rnd.random() < 0.05:
            return 'SHIELD'
        return self.rnd.choice(la)

class _m1_GreedyValueBot(_m1_Base):
    """
    Nearest-highest-value greedy claiming, upgrade when idle, never shields.
    My prediction for the modal unprompted-LLM bot.
    """
    name = 'greedy'
    SHIELDS = False
    RAIDS = True

    def act(self, view):
        self.read(view)
        seat = self.seat
        if self.SHIELDS and 'SHIELD' in view.legal_actions:
            if _m0_rivals_on_my_land(self.owner, self.occ, self.frz, seat):
                return 'SHIELD'
        d = _m0_bfs(self.me, self.blocked)
        best, bestscore = (None, 0.0)
        for p in range(_m0_NC):
            if d[p] >= 99 or self.home[p]:
                continue
            o = self.owner[p]
            if o == seat:
                continue
            if o != 0 and (not self.RAIDS):
                continue
            cost = d[p] + (3 if o != 0 and self.upg[p] else 1)
            s = self.base[p] / float(cost)
            if o != 0:
                s *= 1.15
            if s > bestscore:
                bestscore, best = (s, p)
        if best is None:
            return 'STAY'
        if best == self.me:
            return 'STAY'
        o = self.owner[self.me]
        if o == 0 or (o != seat and (not self.home[self.me])):
            return 'STAY'
        if o == seat and (not self.upg[self.me]) and (d[best] > 1):
            return 'STAY'
        return self.step_to(best)

class _m1_GreedyShieldBot(_m1_GreedyValueBot):
    """Same economics, but shields the instant a rival sets foot on its land."""
    name = 'greedyshield'
    SHIELDS = True

class _m1_PacifistBot(_m1_GreedyValueBot):
    """Claims only neutral ground, never raids. Shields on sight."""
    name = 'pacifist'
    SHIELDS = True
    RAIDS = False

class _m1_SpineFarmerBot(_m1_Base):
    """
    The optimal-route farmer from the economic analysis: walk the high-value
    corridor out of home claiming as you go, upgrade 3-cells on arrival, backfill
    the cheap cells last. Stays in its own quadrant. Disciplined shields.
    """
    name = 'spine'

    def __init__(self, seed=0):
        _m1_Base.__init__(self, seed)
        self.route = None

    def build_route(self):
        seat = self.seat
        mine = [p for p in range(_m0_NC) if _m0_zone_of(p) == seat and (not self.home[p])]
        home = _m0_CORNERS[seat - 1]
        route, cur, left = ([], home, set(mine))
        while left:
            d = _m0_bfs(cur)
            best, bestscore = (None, -1000000000.0)
            for p in left:
                s = self.base[p] * 3.0 - d[p] * 2.0 + _m0_man(p, home) * 0.55
                if s > bestscore:
                    bestscore, best = (s, p)
            route.append(best)
            left.discard(best)
            cur = best
        self.route = route

    def act(self, view):
        self.read(view)
        seat = self.seat
        if self.route is None:
            self.build_route()
        if 'SHIELD' in view.legal_actions:
            intr = _m0_rivals_on_my_land(self.owner, self.occ, self.frz, seat)
            for p, o in intr:
                if self.base[p] >= 2:
                    return 'SHIELD'
        o = self.owner[self.me]
        if o == 0:
            return 'STAY'
        if o == seat and (not self.upg[self.me]) and (self.base[self.me] >= 2):
            return 'STAY'
        for p in self.route:
            if self.owner[p] != seat:
                if p == self.me:
                    return 'STAY'
                return self.step_to(p)
        cand = [p for p in range(_m0_NC) if self.owner[p] == seat and (not self.upg[p])]
        if not cand:
            return 'STAY'
        d = _m0_bfs(self.me, self.blocked)
        cand.sort(key=lambda p: -self.base[p] * 4 + d[p])
        t = cand[0]
        return 'STAY' if t == self.me else self.step_to(t)

class _m1_RaiderBot(_m1_Base):
    """Farms briefly, then raids the nearest rival level-1 cell. Shields on sight."""
    name = 'raider'
    SWITCH = 24

    def act(self, view):
        self.read(view)
        seat = self.seat
        if 'SHIELD' in view.legal_actions:
            if _m0_rivals_on_my_land(self.owner, self.occ, self.frz, seat):
                return 'SHIELD'
        o = self.owner[self.me]
        if o == 0 or (o != seat and (not self.home[self.me])):
            return 'STAY'
        d = _m0_bfs(self.me, self.blocked)
        if self.turn < self.SWITCH:
            cand = [p for p in range(_m0_NC) if self.owner[p] == 0 and d[p] < 99]
            if cand:
                cand.sort(key=lambda p: -(self.base[p] * 3.0 - d[p] * 2.0))
                t = cand[0]
                return 'STAY' if t == self.me else self.step_to(t)
        cand = [p for p in range(_m0_NC) if self.owner[p] not in (0, seat) and (not self.home[p]) and (d[p] < 99)]
        if cand:
            cand.sort(key=lambda p: -(8 * self.base[p] * (2 if self.upg[p] else 1) / float(d[p] + (3 if self.upg[p] else 1))))
            t = cand[0]
            return 'STAY' if t == self.me else self.step_to(t)
        if o == seat and (not self.upg[self.me]):
            return 'STAY'
        return 'STAY'

class _m1_CamperBot(_m1_Base):
    """Grabs the best few cells, upgrades them, then squats the best one (occupancy
    is immunity) and shields hard. The natural counter to raiders."""
    name = 'camper'

    def act(self, view):
        self.read(view)
        seat = self.seat
        if 'SHIELD' in view.legal_actions:
            if _m0_rivals_on_my_land(self.owner, self.occ, self.frz, seat):
                return 'SHIELD'
        mine_zone = [p for p in range(_m0_NC) if _m0_zone_of(p) == seat and (not self.home[p])]
        mine_zone.sort(key=lambda p: -self.base[p])
        target_set = mine_zone[:8]
        o = self.owner[self.me]
        if o == 0:
            return 'STAY'
        if o == seat and (not self.upg[self.me]) and (self.me in target_set):
            return 'STAY'
        for p in target_set:
            if self.owner[p] != seat:
                return 'STAY' if p == self.me else self.step_to(p)
        for p in target_set:
            if not self.upg[p]:
                return 'STAY' if p == self.me else self.step_to(p)
        best = max(target_set, key=lambda p: self.base[p]) if target_set else self.me
        return 'STAY' if best == self.me else self.step_to(best)

class _m1_BaiterBot(_m1_Base):
    """
    Deliberately draws shields: steps onto a rival border cell, then steps off
    before the take completes, and harvests while they are frozen + on cooldown.
    Included to make sure my bot is not farmable by this.
    """
    name = 'baiter'

    def __init__(self, seed=0):
        _m1_Base.__init__(self, seed)
        self.standing = 0
        self.last = -1

    def act(self, view):
        self.read(view)
        seat = self.seat
        if 'SHIELD' in view.legal_actions:
            if _m0_rivals_on_my_land(self.owner, self.occ, self.frz, seat):
                return 'SHIELD'
        d = _m0_bfs(self.me, self.blocked)
        o = self.owner[self.me]
        if o != 0 and o != seat and (not self.home[self.me]):
            self.standing = self.standing + 1 if self.me == self.last else 1
            self.last = self.me
            if self.standing >= 2 and self.rnd.random() < 0.8:
                away = [p for p in _m0_NEIGH[self.me] if p not in self.blocked]
                if away:
                    self.standing = 0
                    return self.step_to(self.rnd.choice(away))
            return 'STAY'
        self.standing = 0
        if o == 0:
            return 'STAY'
        cand = [p for p in range(_m0_NC) if self.owner[p] not in (0, seat) and (not self.home[p]) and (d[p] < 99) and (not self.upg[p])]
        if cand:
            cand.sort(key=lambda p: -(self.base[p] * 3.0 - d[p] * 2.0))
            return self.step_to(cand[0])
        cand = [p for p in range(_m0_NC) if self.owner[p] == 0 and d[p] < 99]
        if cand:
            cand.sort(key=lambda p: -(self.base[p] * 3.0 - d[p] * 2.0))
            t = cand[0]
            return 'STAY' if t == self.me else self.step_to(t)
        if self.owner[self.me] == seat and (not self.upg[self.me]):
            return 'STAY'
        return 'STAY'
_m1_ZOO = [_m1_StayBot, _m1_RandomBot, _m1_GreedyValueBot, _m1_GreedyShieldBot, _m1_PacifistBot, _m1_SpineFarmerBot, _m1_RaiderBot, _m1_CamperBot, _m1_BaiterBot]
_m1_ZOO_BY_NAME = dict(((c.name, c) for c in _m1_ZOO))

"""
Held-out opponents. These are NEVER in the tuning field, so they measure whether
the tuned weights generalise or are just overfitted to the training zoo.
"""
import random as _m2_random

class _m2_TurtleBot(_m1_Base):
    """Claims only what is near home, upgrades everything, shields by strict rule.
    Extremely low-variance; the natural 'play it safe' design."""
    name = 'turtle'
    RADIUS = 4

    def act(self, view):
        self.read(view)
        seat = self.seat
        home = _m0_CORNERS[seat - 1]
        if 'SHIELD' in view.legal_actions:
            for p, o in _m0_rivals_on_my_land(self.owner, self.occ, self.frz, seat):
                if self.base[p] >= 2:
                    return 'SHIELD'
        near = [p for p in range(_m0_NC) if _m0_man(p, home) <= self.RADIUS and (not self.home[p])]
        o = self.owner[self.me]
        if o == 0 and self.me in near:
            return 'STAY'
        if o == seat and (not self.upg[self.me]):
            return 'STAY'
        d = _m0_bfs(self.me, self.blocked)
        todo = [p for p in near if self.owner[p] != seat and d[p] < 99]
        if todo:
            todo.sort(key=lambda p: -(self.base[p] * 3.0 - d[p] * 2.0))
            t = todo[0]
            return 'STAY' if t == self.me else self.step_to(t)
        todo = [p for p in near if self.owner[p] == seat and (not self.upg[p]) and (d[p] < 99)]
        if todo:
            todo.sort(key=lambda p: -(self.base[p] * 3.0 - d[p] * 2.0))
            t = todo[0]
            return 'STAY' if t == self.me else self.step_to(t)
        return 'STAY'

class _m2_LeaderHunterBot(_m1_Base):
    """Farms, but always raids whoever is currently winning. Tracks scores itself."""
    name = 'hunter'

    def __init__(self, seed=0):
        _m1_Base.__init__(self, seed)
        self.score = [0, 0, 0, 0]

    def act(self, view):
        self.read(view)
        seat = self.seat
        for p in range(_m0_NC):
            if self.owner[p]:
                self.score[self.owner[p] - 1] += self.base[p] * (2 if self.upg[p] else 1)
        if 'SHIELD' in view.legal_actions:
            if _m0_rivals_on_my_land(self.owner, self.occ, self.frz, seat):
                return 'SHIELD'
        o = self.owner[self.me]
        if o == 0 or (o != seat and (not self.home[self.me])):
            return 'STAY'
        d = _m0_bfs(self.me, self.blocked)
        leader = max((j for j in range(4) if j != seat - 1), key=lambda j: self.score[j]) + 1
        tgt = [p for p in range(_m0_NC) if self.owner[p] == leader and (not self.home[p]) and (d[p] < 99)]
        if self.turn > 20 and tgt:
            tgt.sort(key=lambda p: -(8.0 * self.base[p] * (2 if self.upg[p] else 1) / (d[p] + (3 if self.upg[p] else 1))))
            t = tgt[0]
            return 'STAY' if t == self.me else self.step_to(t)
        free = [p for p in range(_m0_NC) if self.owner[p] == 0 and d[p] < 99]
        if free:
            free.sort(key=lambda p: -(self.base[p] * 3.0 - d[p] * 2.0))
            t = free[0]
            return 'STAY' if t == self.me else self.step_to(t)
        if o == seat and (not self.upg[self.me]):
            return 'STAY'
        return 'STAY'

class _m2_CentreRushBot(_m1_Base):
    """Sprints for the middle four cells, holds them, upgrades them, fights there.
    The 'contest the valuable ground' design."""
    name = 'centre'

    def act(self, view):
        self.read(view)
        seat = self.seat
        if 'SHIELD' in view.legal_actions:
            if _m0_rivals_on_my_land(self.owner, self.occ, self.frz, seat):
                return 'SHIELD'
        o = self.owner[self.me]
        if o == 0:
            return 'STAY'
        if o != seat and (not self.home[self.me]):
            return 'STAY'
        core = sorted(range(_m0_NC), key=lambda p: (-self.base[p], _m0_man(p, _m0_CORNERS[seat - 1])))
        core = [p for p in core if not self.home[p]][:10]
        d = _m0_bfs(self.me, self.blocked)
        todo = [p for p in core if self.owner[p] != seat and d[p] < 99]
        if todo:
            todo.sort(key=lambda p: d[p])
            t = todo[0]
            return 'STAY' if t == self.me else self.step_to(t)
        if o == seat and (not self.upg[self.me]):
            return 'STAY'
        todo = [p for p in core if self.owner[p] == seat and (not self.upg[p]) and (d[p] < 99)]
        if todo:
            todo.sort(key=lambda p: d[p])
            t = todo[0]
            return 'STAY' if t == self.me else self.step_to(t)
        free = [p for p in range(_m0_NC) if self.owner[p] == 0 and d[p] < 99]
        if free:
            free.sort(key=lambda p: -(self.base[p] * 3.0 - d[p] * 2.0))
            t = free[0]
            return 'STAY' if t == self.me else self.step_to(t)
        return 'STAY'

class _m2_CooldownRaiderBot(_m1_Base):
    """
    The dangerous one: it tracks shield cooldowns the same way my bot does, and
    raids only inside a rival's cooldown window. This is the design I argued is
    the strongest exploit available, written by someone else.
    """
    name = 'cdraider'

    def __init__(self, seed=0):
        _m1_Base.__init__(self, seed)
        self.cd = [0, 0, 0, 0]
        self.prevfrz = [0] * _m0_NC
        self.prevown = None
        self.prevpos = [None] * 4

    def act(self, view):
        self.read(view)
        seat = self.seat
        pos = [None] * 4
        for p in range(_m0_NC):
            if self.occ[p]:
                pos[self.occ[p] - 1] = p
        if self.prevown is not None:
            newly = []
            for i in range(4):
                if pos[i] is not None and self.frz[pos[i]] and (self.prevpos[i] is not None) and (not self.prevfrz[self.prevpos[i]]):
                    newly.append(i)
            sh = set()
            for i in newly:
                pp = self.prevpos[i]
                o = self.prevown[pp]
                sh.add(o - 1 if o and o != i + 1 else i)
            for s in range(4):
                if s in sh:
                    self.cd[s] = 4
                elif self.cd[s] > 0:
                    self.cd[s] -= 1
        self.prevown = self.owner[:]
        self.prevfrz = self.frz[:]
        self.prevpos = pos
        if 'SHIELD' in view.legal_actions:
            if _m0_rivals_on_my_land(self.owner, self.occ, self.frz, seat):
                return 'SHIELD'
        o = self.owner[self.me]
        if o == 0:
            return 'STAY'
        if o != seat and (not self.home[self.me]):
            return 'STAY'
        d = _m0_bfs(self.me, self.blocked)
        safe = []
        for p in range(_m0_NC):
            ow = self.owner[p]
            if ow and ow != seat and (not self.home[p]) and (d[p] < 99):
                need = 3 if self.upg[p] else 1
                if self.cd[ow - 1] >= d[p] + need:
                    safe.append(p)
        if safe:
            safe.sort(key=lambda p: -((8.0 * self.base[p] * (2 if self.upg[p] else 1) + self.base[p] * 10) / (d[p] + (3 if self.upg[p] else 1))))
            t = safe[0]
            return 'STAY' if t == self.me else self.step_to(t)
        free = [p for p in range(_m0_NC) if self.owner[p] == 0 and d[p] < 99]
        if free:
            free.sort(key=lambda p: -(self.base[p] * 3.0 - d[p] * 2.0))
            t = free[0]
            return 'STAY' if t == self.me else self.step_to(t)
        if o == seat and (not self.upg[self.me]):
            return 'STAY'
        cand = [p for p in range(_m0_NC) if self.owner[p] == seat and (not self.upg[p]) and (d[p] < 99)]
        if cand:
            cand.sort(key=lambda p: -(self.base[p] * 3.0 - d[p] * 2.0))
            t = cand[0]
            return 'STAY' if t == self.me else self.step_to(t)
        return 'STAY'
_m2_HOLDOUT = [_m2_TurtleBot, _m2_LeaderHunterBot, _m2_CentreRushBot, _m2_CooldownRaiderBot]
_PLAYERS = {}
def act(state):
    seat = state.bot_id
    if seat not in _PLAYERS:
        _PLAYERS[seat] = _m2_CooldownRaiderBot(seed=seat*7919, **{})
    return _PLAYERS[seat](state)
