"""Shared helpers for the opponent zoo (the submitted bot.py is self-contained)."""
from collections import deque as _m0_deque
_m0_N = 8
_m0_NC = 64
_m0_MOVES = (('NORTH', -8), ('SOUTH', 8), ('WEST', -1), ('EAST', 1))
_m0_CORNERS = (0, 7, 63, 56)
_m0_NEIGH = []
for _m0__p in range(_m0_NC):
    _m0__r, _m0__c = divmod(_m0__p, _m0_N)
    _m0__a = []
    if _m0__r > 0:
        _m0__a.append(_m0__p - _m0_N)
    if _m0__r < _m0_N - 1:
        _m0__a.append(_m0__p + _m0_N)
    if _m0__c > 0:
        _m0__a.append(_m0__p - 1)
    if _m0__c < _m0_N - 1:
        _m0__a.append(_m0__p + 1)
    _m0_NEIGH.append(tuple(_m0__a))

def _m0_parse(view):
    """Flatten the Cell board into parallel arrays. Handles both documented layouts."""
    bd = view.board
    base = [0] * _m0_NC
    owner = [0] * _m0_NC
    upg = [0] * _m0_NC
    home = [0] * _m0_NC
    occ = [0] * _m0_NC
    frz = [0] * _m0_NC
    if bd and isinstance(bd[0], (list, tuple)):
        cells = [bd[r][c] for r in range(_m0_N) for c in range(_m0_N)]
    else:
        cells = list(bd)
    for p, cl in enumerate(cells):
        base[p] = cl.base_points
        owner[p] = cl.owner
        upg[p] = 1 if cl.is_upgraded else 0
        home[p] = 1 if cl.is_home else 0
        occ[p] = cl.occupant
        frz[p] = 1 if cl.is_frozen else 0
    return (base, owner, upg, home, occ, frz)

def _m0_bfs(start, blocked=()):
    """Step distances from start; blocked cells are impassable."""
    d = [99] * _m0_NC
    d[start] = 0
    q = _m0_deque([start])
    bl = set(blocked)
    while q:
        u = q.popleft()
        du = d[u] + 1
        for w in _m0_NEIGH[u]:
            if d[w] > du and w not in bl:
                d[w] = du
                q.append(w)
    return d

def _m0_first_step(start, target, blocked=()):
    """Action name for the first step of a shortest path, or None."""
    if start == target:
        return None
    d = _m0_bfs(target, blocked)
    best, bestd = (None, d[start])
    if bestd >= 99:
        return None
    for name, delta in _m0_MOVES:
        w = start + delta
        if w in _m0_NEIGH[start] and d[w] == bestd - 1:
            return name
    return best

def _m0_man(a, b):
    ar, ac = divmod(a, _m0_N)
    br, bc = divmod(b, _m0_N)
    return abs(ar - br) + abs(ac - bc)

def _m0_zone_of(p):
    """Which seat's quadrant a cell belongs to (nearest home, ties by seat order)."""
    best, bestd = (1, 99)
    for i, c in enumerate(_m0_CORNERS):
        d = _m0_man(p, c)
        if d < bestd:
            bestd, best = (d, i + 1)
    return best

def _m0_my_cells(owner, seat):
    return [p for p in range(_m0_NC) if owner[p] == seat]

def _m0_rivals_on_my_land(owner, occ, frz, seat):
    """Rival seats standing on a cell I own, excluding already-frozen ones."""
    out = []
    for p in range(_m0_NC):
        o = occ[p]
        if o and o != seat and (owner[p] == seat) and (not frz[p]):
            out.append((p, o))
    return out

"""
A strong opponent that is NOT my architecture.

Every serious opponent measured so far has been either a hand-written archetype I
invented or a frozen snapshot of my own bot. Snapshots share my planner and
therefore my blind spots, so beating them proves less than it looks. The brief
was to assume every other team also used an agentic assistant, and the honest way
to model that is a bot built on a different principle and then tuned just as hard.

So this is a RATE RANKER, not a route planner: it scores every piece of work on
the board by points per action-turn and commits to the best. That is the design a
careful assistant arrives at from the rulebook, and unopposed it already outscores
my own bot (3545 against 3276) because it is not paying for defensive habits. Its
weakness is the opposite one: it prices no risk, so it walks into shields.

Its weights are tunable (tune_rival.py), which is the point -- an untuned rival
is not a fair test of a tuned bot.

The economics it encodes, straight from the rulebook:
  * a neutral cell costs 1 stay and pays base x turns-remaining;
  * a rival's LEVEL-1 cell also costs 1 stay and additionally pays 8 x base;
  * a rival's upgraded cell costs 3 stays and pays 8 x base x 2;
  * your own cell costs 3 stays to double;
  * a raid bonus is one-off, so it does not decay with the clock the way income
    does -- which makes raiding worth far more late than early.
"""
import random as _m4_random
_m4_MAX_TURNS = 80
_m4_DIST = [_m0_bfs(_m4__a) for _m4__a in range(_m0_NC)]
_m4_CENTRE = (27, 28, 35, 36)
_m4_WEIGHTS = {'w_claim': 1.0, 'w_upgrade': 1.0, 'w_raid': 1.0, 'w_raid_late': 1.0, 'bonus_mult': 1.0, 'compact': 0.0, 'centre': 0.0, 'cd_bonus': 1.0, 'cd_malus': 1.0, 'squat': 0.25, 'commit': 1.25, 'shield_floor': 22.0, 'shield_scale': 0.0, 'upg_pref': 1.0, 'home_pref': 1.0}

class _m4_ProBot(object):
    name = 'pro'

    def __init__(self, seed=0, params=None):
        self.W = dict(_m4_WEIGHTS)
        if params:
            self.W.update(params)
        self.rnd = _m4_random.Random(seed)
        self.turn = 0
        self.cd = [0, 0, 0, 0]
        self.prev_frozen = [0, 0, 0, 0]
        self.squat = {}
        self.goal = None
        self.last = None

    def __call__(self, view):
        self.turn += 1
        try:
            a = self.act(view)
        except Exception:
            a = 'STAY'
        if a not in view.legal_actions:
            a = 'STAY'
        self.last = a
        return a

    def read(self, view):
        self.base, self.owner, self.upg, self.home, self.occ, self.frz = _m0_parse(view)
        self.seat = view.bot_id
        try:
            self.me = self.occ.index(self.seat)
        except ValueError:
            return None
        self.blocked = set((p for p in range(_m0_NC) if self.occ[p] and p != self.me))
        self.R = max(1, _m4_MAX_TURNS - self.turn + 1)
        self._memory()
        return self.me

    def _memory(self):
        """Rival shield cooldowns and how long each squatter has held its ground.

        Neither is in the state object. A bot that freezes while standing on seat
        s's land was caught by s shielding, which also tells me s cannot shield
        again for four turns -- the most valuable hidden fact in the game.
        """
        for i in range(4):
            if self.cd[i] > 0:
                self.cd[i] -= 1
        pos = [None] * 4
        for p in range(_m0_NC):
            o = self.occ[p]
            if o:
                pos[o - 1] = p
        for i in range(4):
            f = 1 if pos[i] is not None and self.frz[pos[i]] else 0
            if f and (not self.prev_frozen[i]) and (pos[i] is not None):
                land = self.owner[pos[i]]
                self.cd[land - 1 if land and land != i + 1 else i] = 4
            self.prev_frozen[i] = f
        if self.last == 'SHIELD':
            self.cd[self.seat - 1] = 4
        sq = {}
        for p in range(_m0_NC):
            o = self.occ[p]
            if not o or o == self.seat or self.owner[p] != self.seat:
                continue
            was = self.squat.get(p)
            if was is not None and was[0] == o:
                sq[p] = [o, was[1] + (0 if self.frz[p] else 1)]
            else:
                sq[p] = [o, 0]
        self.squat = sq

    def step_to(self, t):
        if t == self.me:
            return 'STAY'
        a = _m0_first_step(self.me, t, self.blocked) or _m0_first_step(self.me, t)
        return a or 'STAY'

    def need_of(self, p):
        o = self.owner[p]
        if o == self.seat:
            return None if self.upg[p] else 3
        if o == 0:
            return 1
        if self.home[p]:
            return None
        return 3 if self.upg[p] else 1

    def gain(self, p, d, need):
        W = self.W
        v = self.base[p]
        rem = self.R - d - need
        o = self.owner[p]
        if o == self.seat:
            if rem <= 0:
                return None
            g = v * rem * W['w_upgrade'] * W['upg_pref']
            if self.home[p]:
                g *= W['home_pref']
            return g
        if o == 0:
            if rem <= 0:
                return None
            return v * rem * W['w_claim']
        if rem < 0:
            return None
        lvl = 2 if self.upg[p] else 1
        g = 8.0 * v * lvl * W['bonus_mult'] + v * rem
        f = 1.0 - self.R / float(_m4_MAX_TURNS)
        g *= W['w_raid'] + (W['w_raid_late'] - W['w_raid']) * max(0.0, min(1.0, f))
        g *= W['cd_bonus'] if self.cd[o - 1] >= d + need else W['cd_malus']
        return g

    def threat(self):
        """Points lost at the end of this turn if I do not shield now."""
        worst = 0.0
        for p in range(_m0_NC):
            o = self.occ[p]
            if not o or o == self.seat or self.owner[p] != self.seat or self.frz[p]:
                continue
            lvl = 2 if self.upg[p] else 1
            need = 3 if lvl == 2 else 1
            w = self.squat.get(p, [0, -1])
            if w[0] != o or w[1] < need - 1:
                continue
            v = self.base[p]
            x = v * lvl * self.R + 8.0 * v * lvl
            if x > worst:
                worst = x
        return worst

    def act(self, view):
        if self.read(view) is None:
            return 'STAY'
        W = self.W
        if 'SHIELD' in view.legal_actions:
            floor = W['shield_floor'] * (1.0 + W['shield_scale'] * self.R / 80.0)
            if self.threat() >= floor:
                return 'SHIELD'
        home = _m0_CORNERS[self.seat - 1]
        d = _m0_bfs(self.me, self.blocked)
        best, bestr, keepr = (None, 0.0, 0.0)
        for p in range(_m0_NC):
            need = self.need_of(p)
            if need is None:
                continue
            dp = d[p] if d[p] < 99 else _m4_DIST[self.me][p]
            if dp >= 99:
                continue
            g = self.gain(p, dp, need)
            if g is None or g <= 0:
                continue
            if W['compact']:
                g /= 1.0 + W['compact'] * _m0_man(p, home)
            if W['centre']:
                g /= 1.0 + W['centre'] * min((_m0_man(p, c) for c in _m4_CENTRE))
            if self.occ[p] and p != self.me:
                g *= W['squat']
            rate = g / float(dp + need)
            if p == self.goal:
                keepr = rate
            if rate > bestr:
                bestr, best = (rate, p)
        if self.goal is not None and keepr > 0.0 and (keepr * W['commit'] >= bestr):
            best = self.goal
        if best is None:
            return 'STAY'
        self.goal = best
        return 'STAY' if best == self.me else self.step_to(best)

def _m4_factory(params=None, name='pro'):

    def make(seed):
        b = _m4_ProBot(seed=seed, params=params)
        b.name = name
        return b
    return make
_PLAYERS = {}
def act(state):
    seat = state.bot_id
    if seat not in _PLAYERS:
        _PLAYERS[seat] = _m4_ProBot(seed=seat*7919, **{})
    return _PLAYERS[seat](state)
