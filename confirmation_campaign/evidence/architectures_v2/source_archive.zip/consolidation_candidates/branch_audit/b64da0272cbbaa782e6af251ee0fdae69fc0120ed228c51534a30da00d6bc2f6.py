"""Shared helpers for the opponent zoo (the submitted bot.py is self-contained)."""
from collections import deque as _m0_deque
_m0_N = 8
_m0_NC = 64
_m0_MOVES = (('NORTH', -8), ('SOUTH', 8), ('WEST', -1), ('EAST', 1))
_m0_CORNERS = (0, 7, 63, 56)
_m0_NEIGH = []
for _m0__p in range(_m0_NC):
    _m0__r, _m0__c = divmod(_m0__p, _m0_N)
    _m0__a = []
    if _m0__r > 0:
        _m0__a.append(_m0__p - _m0_N)
    if _m0__r < _m0_N - 1:
        _m0__a.append(_m0__p + _m0_N)
    if _m0__c > 0:
        _m0__a.append(_m0__p - 1)
    if _m0__c < _m0_N - 1:
        _m0__a.append(_m0__p + 1)
    _m0_NEIGH.append(tuple(_m0__a))

def _m0_parse(view):
    """Flatten the Cell board into parallel arrays. Handles both documented layouts."""
    bd = view.board
    base = [0] * _m0_NC
    owner = [0] * _m0_NC
    upg = [0] * _m0_NC
    home = [0] * _m0_NC
    occ = [0] * _m0_NC
    frz = [0] * _m0_NC
    if bd and isinstance(bd[0], (list, tuple)):
        cells = [bd[r][c] for r in range(_m0_N) for c in range(_m0_N)]
    else:
        cells = list(bd)
    for p, cl in enumerate(cells):
        base[p] = cl.base_points
        owner[p] = cl.owner
        upg[p] = 1 if cl.is_upgraded else 0
        home[p] = 1 if cl.is_home else 0
        occ[p] = cl.occupant
        frz[p] = 1 if cl.is_frozen else 0
    return (base, owner, upg, home, occ, frz)

def _m0_bfs(start, blocked=()):
    """Step distances from start; blocked cells are impassable."""
    d = [99] * _m0_NC
    d[start] = 0
    q = _m0_deque([start])
    bl = set(blocked)
    while q:
        u = q.popleft()
        du = d[u] + 1
        for w in _m0_NEIGH[u]:
            if d[w] > du and w not in bl:
                d[w] = du
                q.append(w)
    return d

def _m0_first_step(start, target, blocked=()):
    """Action name for the first step of a shortest path, or None."""
    if start == target:
        return None
    d = _m0_bfs(target, blocked)
    best, bestd = (None, d[start])
    if bestd >= 99:
        return None
    for name, delta in _m0_MOVES:
        w = start + delta
        if w in _m0_NEIGH[start] and d[w] == bestd - 1:
            return name
    return best

def _m0_man(a, b):
    ar, ac = divmod(a, _m0_N)
    br, bc = divmod(b, _m0_N)
    return abs(ar - br) + abs(ac - bc)

def _m0_zone_of(p):
    """Which seat's quadrant a cell belongs to (nearest home, ties by seat order)."""
    best, bestd = (1, 99)
    for i, c in enumerate(_m0_CORNERS):
        d = _m0_man(p, c)
        if d < bestd:
            bestd, best = (d, i + 1)
    return best

def _m0_my_cells(owner, seat):
    return [p for p in range(_m0_NC) if owner[p] == seat]

def _m0_rivals_on_my_land(owner, occ, frz, seat):
    """Rival seats standing on a cell I own, excluding already-frozen ones."""
    out = []
    for p in range(_m0_NC):
        o = occ[p]
        if o and o != seat and (owner[p] == seat) and (not frz[p]):
            out.append((p, o))
    return out

"""
The field, assuming every other team also used an agentic AI.

zoo.py holds archetypes I invented to have *something* to measure against. This
file is different: each bot here is a serious attempt at the strongest design a
well-prompted assistant would actually arrive at from the rulebook, including the
two rule facts my original zoo ignored entirely:

  * a rival's LEVEL-1 cell needs only ONE stay and still pays the 8 x v x 1 raid
    bonus, so cheap raids strictly dominate claiming an equal neutral cell;
  * a HOME cell can be upgraded and can never be captured, so an upgraded home is
    the only risk-free doubling on the board.

Every bot here keeps per-turn memory (the organisers confirmed that is legal) and
several reconstruct rival shield cooldowns, because that is the single most
valuable hidden quantity in the game.
"""
import random as _m3_random
_m3_MAX_TURNS = 80
_m3_DIST = []
for _m3__a in range(_m0_NC):
    _m3_DIST.append(_m0_bfs(_m3__a))

class _m3_AIBase(object):
    """Shared scaffolding: turn count, rival cooldown model, safe dispatch."""
    name = 'aibase'
    shield_floor = 22.0

    def __init__(self, seed=0):
        self.rnd = _m3_random.Random(seed)
        self.turn = 0
        self.cd = [0, 0, 0, 0]
        self.prev_frozen = [0, 0, 0, 0]
        self.prev_owner = None
        self.squat = {}
        self.last = None
        self.goal = None

    def __call__(self, view):
        self.turn += 1
        try:
            a = self.act(view)
        except Exception:
            a = 'STAY'
        if a not in view.legal_actions:
            a = 'STAY'
        self.last = a
        return a

    def read(self, view):
        self.base, self.owner, self.upg, self.home, self.occ, self.frz = _m0_parse(view)
        self.seat = view.bot_id
        try:
            self.me = self.occ.index(self.seat)
        except ValueError:
            self.me = None
            return None
        self.blocked = set((p for p in range(_m0_NC) if self.occ[p] and p != self.me))
        self.R = max(1, _m3_MAX_TURNS - self.turn + 1)
        self._update_cd()
        return self.me

    def _update_cd(self):
        """Infer who shielded last turn, then age every cooldown by one."""
        for i in range(4):
            if self.cd[i] > 0:
                self.cd[i] -= 1
        pos = [None] * 4
        for p in range(_m0_NC):
            o = self.occ[p]
            if o:
                pos[o - 1] = p
        newly = []
        for i in range(4):
            f = 1 if pos[i] is not None and self.frz[pos[i]] else 0
            if f and (not self.prev_frozen[i]):
                newly.append(i)
            self.prev_frozen[i] = f
        for i in newly:
            if pos[i] is None:
                continue
            land = self.owner[pos[i]]
            if land and land != i + 1:
                self.cd[land - 1] = 4
            else:
                self.cd[i] = 4
        if self.last == 'SHIELD':
            self.cd[self.seat - 1] = 4
        self.prev_owner = list(self.owner)
        sq = {}
        for p in range(_m0_NC):
            o = self.occ[p]
            if not o or o == self.seat or self.owner[p] != self.seat:
                continue
            was = self.squat.get(p)
            if was is not None and was[0] == o:
                sq[p] = [o, was[1] + (0 if self.frz[p] else 1)]
            else:
                sq[p] = [o, 0]
        self.squat = sq

    def step_to(self, target):
        if target == self.me:
            return 'STAY'
        a = _m0_first_step(self.me, target, self.blocked)
        if a is None:
            a = _m0_first_step(self.me, target)
        return a or 'STAY'

    def need_of(self, p):
        """Stays required to convert cell p, or None if it is not work."""
        o = self.owner[p]
        if o == self.seat:
            return None if self.upg[p] else 3
        if o == 0:
            return 1
        if self.home[p]:
            return None
        return 3 if self.upg[p] else 1

    def value_of(self, p, d, need):
        """Points of final score from doing the work on p, travel d away."""
        v = self.base[p]
        rem = self.R - d - need
        if rem < 0:
            return None
        o = self.owner[p]
        if o == self.seat:
            return v * rem
        if o == 0:
            return v * rem if rem > 0 else None
        lvl = 2 if self.upg[p] else 1
        return 8.0 * v * lvl + v * rem

    def threat(self):
        """Points at risk from rivals that complete a capture at the END of this
        turn if I do nothing. A rival needs `need` stays and arriving is not one,
        so it is imminent only once it has already banked need - 1 of them."""
        worst = 0.0
        for p, o in _m0_rivals_on_my_land(self.owner, self.occ, self.frz, self.seat):
            lvl = 2 if self.upg[p] else 1
            need = 3 if lvl == 2 else 1
            done = self.squat.get(p, [0, -1])
            if done[0] != o or done[1] < need - 1:
                continue
            v = self.base[p]
            w = v * lvl * self.R + 8.0 * v * lvl
            if w > worst:
                worst = w
        return worst

    def defend(self, view):
        """Shield only when the loss this turn outweighs a turn plus 4 of cover.

        Shielding on sight is the trap: it burns the cooldown, backfires whenever
        the rival was only passing through, and is exactly what a baiting opponent
        farms. So the threat has to clear a floor first.
        """
        if 'SHIELD' not in view.legal_actions:
            return None
        if self.threat() >= self.shield_floor:
            return 'SHIELD'
        return None
    commit_ratio = 1.25

    def bias(self, p, g, d, need):
        """Per-bot taste. Returns the multiplier on cell p's raw value."""
        return 1.0

    def choose(self):
        """Best work-cell by points per action-turn, with commitment.

        Commitment is the part that is easy to leave out and expensive to leave
        out: without it the rate denominator shifts as the bot closes in, a new
        cell takes the lead, and the bot paces between the two for the whole game
        without ever banking a single stay.
        """
        d = _m0_bfs(self.me, self.blocked)
        best, bestr = (None, 0.0)
        keepr = 0.0
        for p in range(_m0_NC):
            need = self.need_of(p)
            if need is None:
                continue
            dp = d[p] if d[p] < 99 else _m3_DIST[self.me][p]
            if dp >= 99:
                continue
            g = self.value_of(p, dp, need)
            if g is None or g <= 0:
                continue
            g *= self.bias(p, g, dp, need)
            if self.occ[p] and p != self.me:
                g *= 0.25
            rate = g / float(dp + need)
            if p == self.goal:
                keepr = rate
            if rate > bestr:
                bestr, best = (rate, p)
        if self.goal is not None and keepr > 0.0 and (keepr * self.commit_ratio >= bestr):
            best = self.goal
        self.goal = best
        return best

    def run(self, view):
        if self.read(view) is None:
            return 'STAY'
        dfd = self.defend(view)
        if dfd:
            return dfd
        t = self.choose()
        if t is None:
            return 'STAY'
        return 'STAY' if t == self.me else self.step_to(t)

    def act(self, view):
        return self.run(view)

class _m3_MarginalBot(_m3_AIBase):
    """
    Textbook marginal value: rank every piece of work by points per action-turn,
    where a cell is worth base x turns-remaining and a raid adds its one-off
    bonus. This is the design a careful assistant lands on from the rulebook
    alone, and it is a genuinely strong baseline.
    """
    name = 'ai_marginal'

class _m3_CheapRaiderBot(_m3_AIBase):
    """
    Lives off the rule that a rival's LEVEL-1 cell costs one stay and still pays
    8 x v x 1. Strictly prefers victims whose shield it believes is on cooldown,
    because then the raid cannot be answered at all.
    """
    name = 'ai_cheapraid'

    def bias(self, p, g, d, need):
        o = self.owner[p]
        if not o or o == self.seat:
            return 1.0
        m = 1.9 if self.cd[o - 1] >= d + need else 0.7
        if not self.upg[p]:
            m *= 1.25
        return m

class _m3_HomeFortBot(_m3_AIBase):
    """
    Upgrades its home first -- the only doubling on the board that can never be
    raided, since homes cannot be captured -- then grows an upgraded cluster
    outward from it. Very low variance, which in a pairwise-Elo format is worth
    more than it looks.
    """
    name = 'ai_homefort'
    shield_floor = 16.0

    def bias(self, p, g, d, need):
        home = _m0_CORNERS[self.seat - 1]
        m = 1.0 / (1.0 + 0.16 * _m0_man(p, home))
        if self.owner[p] == self.seat:
            m *= 1.5
        return m

    def act(self, view):
        if self.read(view) is None:
            return 'STAY'
        dfd = self.defend(view)
        if dfd:
            return dfd
        home = _m0_CORNERS[self.seat - 1]
        if not self.upg[home] and self.R > 12 and (_m3_DIST[self.me][home] + 3 < self.R):
            self.goal = home
            return 'STAY' if self.me == home else self.step_to(home)
        t = self.choose()
        if t is None:
            return 'STAY'
        return 'STAY' if t == self.me else self.step_to(t)

class _m3_CentreLockBot(_m3_AIBase):
    """
    Takes the four 3-point centre cells early and upgrades them. The centre is
    equidistant from all four homes, so holding it earns the most and denies the
    most at the same time.
    """
    name = 'ai_centre'
    CENTRE = (27, 28, 35, 36)
    commit_ratio = 2.0

    def bias(self, p, g, d, need):
        cd = min((_m0_man(p, c) for c in self.CENTRE))
        return 1.0 / (1.0 + 0.22 * cd)

class _m3_RouteBot(_m3_AIBase):
    """
    Plans a short ROUTE instead of a single target: chains the next three
    work-cells, paying the real travel between them, and commits to the first.
    Pricing travel is the main thing a rate-ranking bot gets wrong, so this is
    the strongest simple design -- provided it commits, which is the whole
    difficulty.
    """
    name = 'ai_route'

    def _route(self, start, used, depth, taken):
        if depth == 0:
            return (0.0, None)
        bestg, bestfirst = (0.0, None)
        dd = _m3_DIST[start]
        cands = []
        for p in range(_m0_NC):
            if p in taken:
                continue
            need = self.need_of(p)
            if need is None:
                continue
            dp = dd[p]
            if dp >= 99 or used + dp + need > self.R:
                continue
            g = self.value_of(p, used + dp, need)
            if g is None or g <= 0:
                continue
            if self.occ[p] and p != start:
                g *= 0.25
            cands.append((g / float(dp + need + 1), p, g, dp, need))
        cands.sort(reverse=True)
        for _, p, g, dp, need in cands[:5]:
            taken.add(p)
            sub, _f = self._route(p, used + dp + need, depth - 1, taken)
            taken.discard(p)
            tot = g + sub
            if tot > bestg:
                bestg, bestfirst = (tot, p)
        return (bestg, bestfirst)

    def act(self, view):
        if self.read(view) is None:
            return 'STAY'
        dfd = self.defend(view)
        if dfd:
            return dfd
        g = self.goal
        if g is not None and self.need_of(g) is not None and (_m3_DIST[self.me][g] + self.need_of(g) <= self.R):
            return 'STAY' if g == self.me else self.step_to(g)
        _free, first = self._route(self.me, 0, 3, set())
        if first is None:
            first = self.choose()
        if first is None:
            return 'STAY'
        self.goal = first
        return 'STAY' if first == self.me else self.step_to(first)

class _m3_CooldownHawkBot(_m3_AIBase):
    """
    Farms neutral ground until a rival burns its shield, then swarms that rival
    for the four turns it cannot defend. Shields only when the arithmetic is
    clearly in favour, so it is hard to bait.
    """
    name = 'ai_hawk'

    def bias(self, p, g, d, need):
        o = self.owner[p]
        if not o or o == self.seat:
            return 1.0
        if self.cd[o - 1] >= d + need:
            return 2.4
        return 0.55

class _m3_EloEndgameBot(_m3_AIBase):
    """
    Round 1 scores each game as three one-on-one results, so what matters is how
    many rivals you finish above, not by how much. This bot farms normally, then
    in the last stretch spends its actions only on the pairings it can still
    flip -- attacking the rival just above it and ignoring the one out of reach.
    """
    name = 'ai_elo'

    def __init__(self, seed=0):
        _m3_AIBase.__init__(self, seed)
        self.score = [0, 0, 0, 0]
        self.care = [1.0] * 4

    def bias(self, p, g, d, need):
        o = self.owner[p]
        if o and o != self.seat:
            return self.care[o - 1]
        return 1.0

    def act(self, view):
        if self.read(view) is None:
            return 'STAY'
        inc = [0] * 4
        for p in range(_m0_NC):
            o = self.owner[p]
            if o:
                inc[o - 1] += self.base[p] * (2 if self.upg[p] else 1)
        for i in range(4):
            self.score[i] += inc[i]
        proj = [self.score[i] + inc[i] * self.R for i in range(4)]
        mine = proj[self.seat - 1]
        self.care = [1.0] * 4
        if self.R <= 18:
            for j in range(4):
                if j == self.seat - 1:
                    continue
                gap = proj[j] - mine
                self.care[j] = 2.5 if -8 * self.R < gap < 8 * self.R else 0.25
        dfd = self.defend(view)
        if dfd:
            return dfd
        t = self.choose()
        if t is None:
            return 'STAY'
        return 'STAY' if t == self.me else self.step_to(t)
_m3_AIFIELD = [_m3_MarginalBot, _m3_CheapRaiderBot, _m3_HomeFortBot, _m3_CentreLockBot, _m3_RouteBot, _m3_CooldownHawkBot, _m3_EloEndgameBot]
_m3_AIFIELD_BY_NAME = dict(((c.name, c) for c in _m3_AIFIELD))
_PLAYERS = {}
def act(state):
    seat = state.bot_id
    if seat not in _PLAYERS:
        _PLAYERS[seat] = _m3_CooldownHawkBot(seed=seat*7919, **{})
    return _PLAYERS[seat](state)
