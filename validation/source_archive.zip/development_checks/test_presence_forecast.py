"""Public-history oracles for the corrected PR10 goal-forecast candidate."""
import copy
import importlib.util
from pathlib import Path
import sys
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import engine


def load():
    spec=importlib.util.spec_from_file_location('presence_forecast_contract',ROOT/'consolidation_candidates/pr10_presence_forecast.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def observe(tr,current,seat,last=None):
    view=current.views()[seat-1]; cells=[c for row in view.board for c in row]
    tr.observe([c.owner for c in cells],[c.is_upgraded for c in cells],[c.occupant for c in cells],
               [c.is_frozen for c in cells],seat,view.is_priority_token,[c.base_points for c in cells],
               [c.owner if c.is_home else 0 for c in cells],last)


def signature(public):
    return (public.bot_id,public.is_priority_token,tuple(public.legal_actions),
            tuple((c.owner,c.occupant,c.is_upgraded,c.is_home,c.is_frozen,c.base_points) for row in public.board for c in row))


class PresenceForecastTests(unittest.TestCase):
    def test_moving_arrival_and_move_within_land_are_caught(self):
        for previous_owner in (0,2):
            m=load();tr=m.Tracker();g=engine.Game(base=[2]*64,rules={'catch_requires_stay':False})
            g.pos[0]=36;g.owner[36]=previous_owner;g.owner[28]=2
            observe(tr,g,1)
            g.step(['NORTH','SHIELD','STAY','STAY']);observe(tr,g,1,'NORTH')
            self.assertEqual(g.frozen[0],2)
            self.assertEqual(tr.last_shielders,{1})
            self.assertEqual(tr.cd_possible[1],{4})
            self.assertEqual(tr.prog[0],0)

    def test_mutually_shielding_rivals_are_eligible_victims(self):
        m=load();tr=m.Tracker();g=engine.Game(base=[2]*64,rules={'catch_requires_stay':False})
        g.pos[:2]=[28,27];g.owner[28]=2;g.owner[27]=1
        observe(tr,g,1)
        g.step(['SHIELD','SHIELD','STAY','STAY']);observe(tr,g,1,'SHIELD')
        self.assertEqual(g.frozen[:2],[2,2])
        self.assertEqual(tr.last_shielders,{0,1})
        self.assertEqual(tr.cd_possible[:2],[{4},{4}])

    def test_ambiguous_backfire_or_capture_retains_both_cooldowns(self):
        m=load();tr=m.Tracker();g=engine.Game(base=[2]*64,rules={'catch_requires_stay':False})
        g.pos[1]=28;g.owner[28]=3
        observe(tr,g,1)
        g.step(['STAY','STAY','SHIELD','STAY']);observe(tr,g,1,'STAY')
        self.assertEqual(tr.last_shielders,set())
        self.assertEqual(tr.possible_shielders,{1,2})
        self.assertEqual(tr.cd[1:3],[0,0])
        for seat in (1,2):
            self.assertEqual(tr.cd_possible[seat],{0,1,2,3,4})
            self.assertIn(g.cd[seat],tr.cd_possible[seat])

    def test_all_home_clock_and_income_do_not_reset(self):
        m=load();tr=m.Tracker();g=engine.Game(base=[2]*64,rules={'catch_requires_stay':False})
        for turn in range(1,9):
            observe(tr,g,1,None if turn==1 else 'STAY')
            self.assertEqual(tr.turn,g.turn)
            self.assertEqual(tr.score,g.score)
            self.assertEqual(tr.prog,g.prog)
            g.step(['STAY']*4)

    def test_public_games_are_legal_immutable_and_obey_private_oracles(self):
        worst=0;calls=0
        for case in range(4):
            m=load();errors=[]; original=m.Agent.decide
            def checked(self,view):
                try:return original(self,view)
                except Exception as e:
                    errors.append(repr(e));raise
            m.Agent.decide=checked
            g=engine.Game(base=engine.make_map(seed=180981+case),start_token=case+1,rules={'catch_requires_stay':False})
            while not g.over():
                actions=[]
                for seat,public in enumerate(g.views(),1):
                    before=signature(public);start=time.perf_counter();action=m.act(public)
                    elapsed=(time.perf_counter()-start)*1000;worst=max(worst,elapsed);calls+=1
                    self.assertIn(action,public.legal_actions)
                    self.assertEqual(signature(public),before)
                    tr=m._AGENTS[seat].tr
                    self.assertEqual(tr.turn,g.turn)
                    self.assertEqual(tr.score,g.score)
                    self.assertIn(g.prog[seat-1],tr.prog_possible[seat-1])
                    self.assertEqual(tr.prog[seat-1],g.prog[seat-1])
                    for rival in range(4):
                        self.assertIn(g.cd[rival],tr.cd_possible[rival],(case,g.turn,seat,rival,tr.cd_possible,g.cd))
                        self.assertIn(g.prog[rival],tr.prog_possible[rival],(case,g.turn,seat,rival,tr.prog_possible,g.prog))
                    actions.append(action)
                g.step(actions)
            self.assertFalse(errors)
        self.assertLess(worst,200)
        print('PR10 presence forecast: %d legal immutable public actions; exact own progress/score/clock, truth inside all rival beliefs; worst %.3fms'%(calls,worst))


if __name__=='__main__':unittest.main()
