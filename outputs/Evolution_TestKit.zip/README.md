# Zone Rush research and replay kit

Run the commands below in the extracted folder containing this README. Use Python 3.12 or newer. The submission candidate is `outputs/bot.py`. Keep only that candidate as your competition repository's `bot.py` if your team chooses it. The recommended policy, tournament referees and replay commands use the Python standard library. The packaged user-project snapshot also preserves its optional, separate GPU development code.

## Verify the evidence and policy

    python -B work/comparison/package_evolution.py --check-unpacked

This verifies all archived SHA-256 hashes, runs the local referee tests and exercises the recommended policy's observation recovery. These tests use the published game interface and the organizer-confirmed interpretation that frozen turns earn no progress. The organizers' server is authoritative. The local engine and generated boards are independent reconstructions.

## Replay a match or a full comparison

    python -B work/comparison/package_evolution.py --replay work/comparison/final_plan.json --fixture 0
    python -B work/comparison/batch.py work/comparison/final_plan.json my_replayed_final.json --workers 4

Additional plans and full recorded results are in `work/comparison`, including the neural ablation, direct matchups, transfer screen and subsequent audits that were completed before packaging. Full replay writes a new cache and may take considerable time. Timings depend on the machine. Policies that adapt search depth to elapsed time may occasionally choose another move.

## Train a new population

    python -B work/evolution/evolve.py --directory my_new_league --generations 10 --response-generations 4 --polish-generations 2 --population 36 --workers 4 --seed 20261106
    python -B work/evolution/evolve_transfer.py --directory my_new_transfer --generations 3 --response-generations 1 --polish-generations 2 --population 18 --workers 4 --seed 20261107

Use a new directory for each run and inspect its manifest for the exact settings. The archived transfer run includes its checkpoint repairs and historical trainer versions. A fresh run with the final training code may follow a different trajectory. Historical completed checkpoints, raw per-game training caches and source locks are in `work/evolution/runs`. The original trainer includes machine-local paths in checkpoint compatibility checks and cache fingerprints. Treat those runs as read-only evidence when working on another computer.

## Where to look

- `outputs` holds the selected code and research reports. Older policies, including the obsolete frozen-progress experiment if present, are historical comparisons.
- `work/comparison/user_snapshot_001` holds the frozen external project used for comparison, including its original submission, model weights and training sources. `user_recovery.py` and `user_corrected.py` are separate experimental copies. The source project itself was left untouched.
- `work/arena.py`, `work/test_arena.py`, `work/official_bot.py` and `work/official_README.md` contain the independent referee, its tests, and the public interface snapshot. Organizer answers relayed by the user are in `work/organizer_clarifications.json`.
- `PACKAGE_MANIFEST.json` records the delivered hash and size of every other packaged file. A normalized JSON entry also records its original hash. JSON paths are relative to this extracted root. All Python policy files retain their original bytes. Original hashes embedded in archived locks continue to describe their original files.
- Historical setup and diagnostic scripts may retain their original machine paths. Use the snapshot and the portable commands above rather than rerunning host-specific setup scripts.
