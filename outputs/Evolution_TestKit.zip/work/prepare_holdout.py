import hashlib
import itertools
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parent
configs = json.loads((ROOT / "candidates.json").read_text())
policies = {name:{"path":str(ROOT / "challengers.py"),"name":name}
            for name in ["fortress","lure"]}
policies.update({
    "submission":{"path":str(ROOT.parent / "outputs" / "bot.py")},
    "planner":{"path":str(ROOT / "planner.py")},
    "variant14":{"path":str(ROOT / "planner.py"),"config":configs["variant14"]},
    "learned_tuned":{"path":str(ROOT / "planner_adaptive.py"),"config":configs["variant14"]},
    "macro_beam":{"path":str(ROOT / "planner_beam.py"),
                  "config":{"UPGRADE_WEIGHT":1.8,"RAID_WEIGHT":.7,"DEFENSE_WEIGHT":.8}},
    "beam_fort":{"path":str(ROOT / "beam.py"),
                 "config":{"UPGRADE":1.25,"RAID":.5,"DEFENSE":1.,"DEPTH":8,"WIDTH":12}},
})
lineups = [["fortress","lure","planner"], ["lure"]*3,
           ["beam_fort","macro_beam","variant14"], ["learned_tuned"]*3,
           ["learned_tuned","macro_beam","lure"]]
maps = list(itertools.product(["balanced","patchy","edge"],range(1000,1012)))
maps += [("example",2000)] + [("flat",seed) for seed in range(2001,2004)]
experiments = []
for (family,seed), lineup_index,seat,token in itertools.product(maps,range(5),range(4),range(1,5)):
    lineup = list(lineups[lineup_index])
    random.Random(seed*100 + seat*10 + token).shuffle(lineup)
    lineup.insert(seat,"submission")
    experiments.append({"bots":lineup,"family":family,"seed":seed,"token":token,
                        "target":"submission","target_seat":seat,"lineup":lineup_index})
(ROOT / "holdout.json").write_text(json.dumps({"policies":policies,"experiments":experiments},indent=2))
variant = [row | {"frozen_progress":True} for row in experiments[::20]]
(ROOT / "freeze_sensitivity.json").write_text(json.dumps({"policies":policies,"experiments":variant},indent=2))
source_files = {Path(row["path"]) for row in policies.values()}
hashes = {str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in source_files}
(ROOT / "holdout_lock.json").write_text(json.dumps({"hashes":hashes,"games":len(experiments),
                                                   "synthetic_random_maps":36,
                                                   "fixed_maps":4},indent=2))
print(f"Frozen {len(experiments)} final audit games and {len(variant)} sensitivity games")
