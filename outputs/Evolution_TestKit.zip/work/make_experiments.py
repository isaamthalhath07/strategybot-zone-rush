"""Build matched experiments before looking at their results."""
import argparse
import itertools
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parent
FAMILIES = ["example", "balanced", "patchy", "flat", "edge"]


def build(output, seeds, start_seed, candidates, variants=False):
    policies = {name: {"path": str(ROOT / "challengers.py"), "name": name}
                for name in ["skeleton", "greedy", "expansion", "fortress", "raider",
                             "sentinel", "cautious", "adaptive", "sweep"]}
    policies["planner"] = {"path": str(ROOT / "planner.py")}
    for name, config in candidates.items():
        policies[name] = {"path": str(ROOT / "planner.py"), "config": config}
    targets = list(candidates) or ["planner"]
    opponents = [
        ["expansion", "fortress", "raider"],
        ["sentinel", "cautious", "adaptive"],
        ["adaptive", "adaptive", "adaptive"],
        ["fortress", "fortress", "fortress"],
        ["planner", "planner", "planner"],
    ]
    experiments = []
    for target, seed, family, lineup, seat in itertools.product(
            targets, range(start_seed, start_seed + seeds), FAMILIES, opponents, range(4)):
        bots = list(lineup)
        bots.insert(seat, target)
        experiments.append({"bots": bots, "seed": seed, "family": family,
                            "token": 1 + (seed + seat) % 4})
    output.write_text(json.dumps({"policies": policies, "experiments": experiments}, indent=2))
    print(f"Saved {len(experiments)} experiments to {output}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--seeds", type=int, default=1)
    parser.add_argument("--start-seed", type=int, default=0)
    parser.add_argument("--candidates", type=Path)
    args = parser.parse_args()
    configs = json.loads(args.candidates.read_text()) if args.candidates else {}
    build(args.output, args.seeds, args.start_seed, configs)
