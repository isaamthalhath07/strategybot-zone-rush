import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
groups = []
for config_name, result_name in [("validation", "validation_results"),
                                  ("architecture_selection", "architecture_results"),
                                  ("macro_selection", "macro_results")]:
    result_path = ROOT / f"{result_name}.json"
    if not result_path.exists():
        continue
    config = json.loads((ROOT / f"{config_name}.json").read_text())
    result = json.loads(result_path.read_text())
    for index, (experiment, record) in enumerate(zip(config["experiments"], result["records"])):
        seat = (index // 2) % 4
        record["target_seat"] = seat
        record["target"] = record["bots"][seat]
        record["lineup"] = (index // 8) % 5
    result_path.write_text(json.dumps(result, indent=2))
    names = sorted({record["target"] for record in result["records"]})
    for name in names:
        rows = [record for record in result["records"] if record["target"] == name]
        groups.append({"name":name,"games":len(rows),
                       **{key:statistics.mean(row[key][row["target_seat"]] for row in rows)
                          for key in ["pairwise","strict_first","first_share","scores"]},
                       "worst_lineup":min(statistics.mean(row["pairwise"][row["target_seat"]]
                                                         for row in rows if row["lineup"] == i)
                                          for i in range(5))})
groups.sort(key=lambda row:row["pairwise"],reverse=True)
(ROOT / "selection_summary.json").write_text(json.dumps(groups, indent=2))
for row in groups:
    print(row["name"], row["games"],round(row["pairwise"],4),
          round(row["strict_first"],4),round(row["worst_lineup"],4))
