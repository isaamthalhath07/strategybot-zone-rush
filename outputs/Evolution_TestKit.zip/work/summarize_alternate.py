import json,statistics,hashlib
from pathlib import Path
j=json.loads(Path('work/alternate_validation_raw.json').read_text())
summary={}
for name in ['alternate_profile','submission']:
 rows=[r for r in j['records'] if r['target']==name]
 summary[name]={'games':len(rows),**{key:statistics.mean(r[key][r['target_seat']] for r in rows) for key in ['pairwise','strict_first','first_share','latency_mean_ms']},'max_ms':max(r['latency_max_ms'][r['target_seat']] for r in rows),'errors':sum(len(r['errors']) for r in rows)}
a,b=summary['alternate_profile'],summary['submission']
text=(f'A separate conditional profile, bot_frozen_progress.py, is included for an official ruling that forced frozen stays advance captures and upgrades. Six configurations were compared on the 160-game sensitivity subset, then the selected profile was frozen and compared with the main program on six new random maps, all five lineups, every seat and every initial token. Across 480 matched fixtures per program under the alternate interpretation, the conditional profile earned {a["pairwise"]:.2%} pairwise credit and {a["strict_first"]:.2%} outright wins. The main program earned {b["pairwise"]:.2%} and {b["strict_first"]:.2%}. Both had zero faults. This is a six-map conditional validation, with the same opponent programs used in the main audit. Those opponents were not independently retuned for alternate rules. The conditional profile uses ALT_UPGRADE=2.2, ALT_RAID=1.0, ALT_RISK=0.2 and ALT_DEFENSE=0.25, reconstructs its own forced-stay progress, and reduces reliance on shielding. Rival progress and cooldown remain estimates. Select this profile only after the organisers confirm that interpretation, rename the chosen profile to bot.py, and submit one file. The ordinary bot.py remains the candidate measured in the 3,200-game main audit.')
Path('work/alternate_validation_summary.json').write_text(json.dumps({'summary':summary,'source_sha256':hashlib.sha256(Path('outputs/bot_frozen_progress.py').read_bytes()).hexdigest(),'report_text':text},indent=2))
print(json.dumps(summary,indent=2))
