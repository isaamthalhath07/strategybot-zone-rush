import itertools
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parent
configs = json.loads((ROOT / "top_candidates.json").read_text())
policies = {name: {"path": str(ROOT / "challengers.py"), "name": name}
            for name in ["fortress", "lure", "adaptive", "sentinel", "cautious"]}
policies["planner"] = {"path": str(ROOT / "planner.py")}
for name, config in configs.items():
    policies[name] = {"path": str(ROOT / "planner.py"), "config": config}
for name, config in [
        ("learned_fortify", {"UPGRADE_WEIGHT":1.8, "RAID_WEIGHT":.7, "DEFENSE_WEIGHT":.8}),
        ("learned_tuned", configs["variant14"]),
        ("learned_cautious", configs["variant20"]),
        ("learned_no_bait", configs["variant14"] | {"BAIT_WEIGHT":0})]:
    policies[name] = {"path": str(ROOT / "planner_adaptive.py"), "config": config}
targets = list(configs) + ["learned_fortify", "learned_tuned", "learned_cautious",
                          "learned_no_bait", "fortress", "lure"]
lineups = [["fortress", "lure", "planner"], ["fortress"]*3, ["lure"]*3,
           ["adaptive", "sentinel", "cautious"], ["variant14"]*3]
experiments = []
for target, family, seed, lineup_index, seat, token in itertools.product(
        targets, ["example", "balanced", "patchy", "flat", "edge"], [11,12],
        range(len(lineups)), range(4), [1,3]):
    lineup = list(lineups[lineup_index])
    random.Random(seed*100 + seat*10 + token).shuffle(lineup)
    lineup.insert(seat, target)
    experiments.append({"bots":lineup, "family":family, "seed":seed, "token":token})
(ROOT / "validation.json").write_text(json.dumps({"policies":policies,
                                                 "experiments":experiments},indent=2))
print(f"Created {len(experiments)} selection games")
