import ast
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent / "outputs"
OUTPUT.mkdir(exist_ok=True)
config = json.loads((ROOT / "candidates.json").read_text())["variant20"]
source = (ROOT / "planner_adaptive.py").read_text()
for name, value in config.items():
    source = re.sub(rf"^{name} = .+$", f"{name} = {value!r}", source, flags=re.M)
source = source.replace('"turn": turn, "scores":', '"turn": turn, "known_start": pristine, "scores":')
helper = (ROOT / "planner_terminal.py").read_text()
helper = helper[helper.index("def choose_terminal("):]
source = source.replace("def act(state):", helper + "\n\n\ndef act(state):")
source = source.replace('    if best_action not in legal:\n',
    '    if best_action == "STAY" and left == 1 and memory["known_start"]:\n'
    '        terminal = choose_terminal(state, cells, me, at, memory["progress"])\n'
    '        if terminal is not None:\n'
    '            best_action = terminal\n'
    '    if best_action not in legal:\n')
source = source.replace('"""Zone Rush territory planner. Only reads the documented starter interface."""',
'''"""Zone Rush bot, selected by local empirical testing on 6 November 2026.

Standard-library-only single-file entry point. Reads the documented starter
interface and never changes the supplied state. Module memory tracks turns,
scores, progress, opponent shields and observed raid persistence within a game.
The official server and its execution lifecycle still require validation.
"""''')
ast.parse(source)
(OUTPUT / "bot.py").write_text(source, encoding="utf-8")
manifest = {"selection": "learned_cautious", "config":config,
            "addition":"proved final-turn STAY-to-SHIELD replacement when no own scoring event",
            "sha256":hashlib.sha256((OUTPUT / "bot.py").read_bytes()).hexdigest()}
(ROOT / "selection_lock.json").write_text(json.dumps(manifest, indent=2))
print(json.dumps(manifest, indent=2))
