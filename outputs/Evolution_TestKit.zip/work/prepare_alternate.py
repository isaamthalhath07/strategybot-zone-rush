import json
from pathlib import Path
j=json.loads(Path('work/freeze_sensitivity.json').read_text())
configs={
 'alternate_default':{},
 'alternate_aggressive':{'ALT_UPGRADE':1.,'ALT_RAID':1.5,'ALT_RISK':.1,'ALT_DEFENSE':.1},
 'alternate_raider':{'ALT_UPGRADE':.8,'ALT_RAID':2.,'ALT_RISK':0.,'ALT_DEFENSE':0.},
 'alternate_balanced':{'ALT_UPGRADE':1.3,'ALT_RAID':1.4,'ALT_RISK':.2,'ALT_DEFENSE':.3},
 'alternate_fortify':{'ALT_UPGRADE':2.2,'ALT_RAID':1.,'ALT_RISK':.2,'ALT_DEFENSE':.25},
 'alternate_auto':{'FROZEN_PROGRESS':None}}
base=j['experiments']; experiments=[]
for name,config in configs.items():
 j['policies'][name]={'path':str(Path('work/planner_rules.py').resolve()),'config':config}
 for e in base:
  seat=e['target_seat']; bots=e['bots'][:]; bots[seat]=name
  experiments.append(e | {'bots':bots,'target':name})
j['experiments']=experiments
Path('work/alternate_selection.json').write_text(json.dumps(j,indent=2))
