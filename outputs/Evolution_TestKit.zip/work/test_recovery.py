"""Black-box action substitution and public-observation recovery tests for Zone Rush."""
import argparse
from collections import Counter
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import random
import sys
import unittest

from arena import Game, HOMES, NEIGHBORS
from bench import load_policy
from validate_submission import public_input, snapshot


ROOT = Path(__file__).resolve().parent
SOURCE = next(p for p in (ROOT/"bot_recovery.py",ROOT/"bot.py",ROOT.parent/"outputs"/"bot.py") if p.exists())
EVIDENCE = {}
IDLE = ["STAY"]*4


def fresh():
    spec = importlib.util.spec_from_file_location("subject",SOURCE)
    bot = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bot)
    return bot


def observe(game, bot, seat=1):
    state = public_input(game.state(seat))
    before = snapshot(state)
    action = bot.act(state)
    assert action in state.legal_actions and snapshot(state)==before
    memory = bot._history[seat]
    return action, memory


def at_center(kind="own"):
    game = Game(start_token=1,values=[1]*64)
    game.pos = [27,29,63,56]
    game.owner[27] = 1 if kind=="own" else 3
    game.upgraded[27] = kind=="enemy"
    game.values[28] = 3
    return game


class Recovery(unittest.TestCase):
    def contested(self,kind):
        g,bot = at_center(kind),fresh()
        requested,_ = observe(g,bot)
        self.assertEqual(requested,"EAST")
        g.step(["invalid",*IDLE[1:]]) # First rejected departure starts real progress.
        requested,m = observe(g,bot)
        self.assertEqual((m["progress"],requested,g.token),(1,"EAST",2))
        g.step([requested,"WEST","STAY","STAY"]) # Both target neutral 28; token seat 2 wins.
        _,m = observe(g,bot)
        self.assertEqual(g.pos[:2],[27,28])
        self.assertEqual(m["progress"],g.progress[0])
        self.assertEqual(m["progress"],2)
        self.assertEqual(m["positions"][1:],g.pos)
        self.assertEqual(m["scores"][1:],g.scores)

    def test_blocked_departure_continues_own_partial_upgrade(self):
        self.contested("own")

    def test_blocked_departure_continues_rival_level_two_raid(self):
        self.contested("enemy")

    def test_requested_shield_ignored_to_stay(self):
        g,bot = at_center(),fresh()
        g.owner[29],g.values[29] = 1,3
        requested,_ = observe(g,bot)
        self.assertEqual(requested,"SHIELD")
        g.step(["invalid",*IDLE[1:]]) # A legal request is replaced at the referee boundary.
        self.assertIn("SHIELD",g.state(1).legal_actions)
        _,m = observe(g,bot)
        self.assertEqual(m["positions"][1:],g.pos)
        self.assertEqual(m["scores"][1:],g.scores)
        self.assertEqual((g.progress[0],m["progress"]),(1,1))

    def test_accepted_shield_is_not_a_stay(self):
        g,bot = at_center(),fresh()
        g.owner[29],g.values[29] = 1,3
        requested,_ = observe(g,bot)
        self.assertEqual(requested,"SHIELD")
        g.step([requested,*IDLE[1:]])
        self.assertEqual((g.cooldown[0],g.frozen[1]),(4,2))
        self.assertNotIn("SHIELD",g.state(1).legal_actions)
        _,m = observe(g,bot)
        self.assertEqual((m["progress"],m["scores"][1:]),(0,g.scores))

    def test_freeze_then_two_forced_stays_earn_zero_progress(self):
        g,bot = at_center("enemy"),fresh()
        observe(g,bot)
        g.step(["invalid",*IDLE[1:]]) # Partial enemy raid.
        _,m = observe(g,bot)
        self.assertEqual(m["progress"],1)
        g.step(["invalid","STAY","SHIELD","STAY"]) # Seat 3 owns cell 27.
        for freeze in (2,1,0):
            action,m = observe(g,bot)
            self.assertEqual((m["progress"],g.progress[0],g.frozen[0]),(0,0,freeze))
            self.assertEqual(m["scores"][1:],g.scores)
            if freeze:
                self.assertEqual(action,"STAY")
                g.step(["EAST",*IDLE[1:]]) # Frozen seat ignores even movement requests.

    def test_return_to_pristine_during_same_match(self):
        g,bot = Game(family="example"),fresh()
        observe(g,bot)
        g.step(["STAY","WEST","STAY","STAY"])
        observe(g,bot)
        g.step(["STAY","EAST","STAY","STAY"])
        # Seat 2 left then returned without capturing. No one has upgraded yet.
        self.assertEqual(g.pos,list(HOMES))
        self.assertEqual((sum(bool(o) for o in g.owner),any(g.upgraded)),(4,False))
        _,m = observe(g,bot)
        self.assertEqual((m["turn"],m["scores"][1:],m["progress"]),(3,g.scores,2))

    def test_identical_boards_at_successive_complete_game_starts(self):
        bot = fresh()
        for _ in range(3):
            g = Game(family="example",start_token=1)
            while g.turn<=80:
                _,m = observe(g,bot)
                self.assertEqual((m["turn"],m["scores"][1:]),(g.turn,g.scores))
                g.step(IDLE)

    def test_forty_games_with_real_requested_moves_and_injected_execution_faults(self):
        totals,problems = Counter(),[]
        for fixture in range(40):
            me = fixture%4+1
            rng = random.Random(99_010+fixture)
            family = ("balanced","patchy","edge","example","flat")[(fixture//4)%5]
            g = Game(201+fixture,family,1+(fixture//10)%4)
            bot = fresh()
            rivals = iter([load_policy("challengers.py", n) for n in ("fortress","lure","adaptive")])
            policies = [None if seat==me else next(rivals) for seat in range(1,5)]
            while g.turn<=80:
                a,m = observe(g,bot,me)
                totals["callbacks"] += 1
                here = g.pos[me-1]
                actionable = (g.owner[here]==me and not g.upgraded[here]) or (
                    g.owner[here]!=me and here not in HOMES)
                checks = {"scores":(m["scores"][1:],g.scores),
                          "positions":(m["positions"][1:],g.pos),"turn":(m["turn"],g.turn)}
                if actionable:
                    totals["actionable_progress_checks"] += 1
                    checks["progress"]=(m["progress"],g.progress[me-1])
                for k,(seen,truth) in checks.items():
                    if seen!=truth:
                        totals[k+"_mismatch"]+=1
                        if len(problems)<12:
                            problems.append([fixture,g.turn,me,k,seen,truth])
                acts = [a if s==me else policies[s-1](public_input(g.state(s))) for s in range(1,5)]
                before = g.pos[:]
                for idx,request in enumerate(acts):
                    if request=="STAY":
                        continue
                    probability = (.68 if request=="SHIELD" else .21) if idx==me-1 else .13
                    if rng.random()<probability:
                        substitute = rng.choice(("invalid","STAY"))
                        acts[idx] = substitute
                        side = "own" if idx==me-1 else "other"
                        case = "shield" if request=="SHIELD" else "move"
                        totals[f"{side}_{case}_substitutions"]+=1
                g.step(acts)
                if acts[me-1] in NEIGHBORS[before[me-1]] and before[me-1]==g.pos[me-1]:
                    totals["natural_own_blocked_moves"]+=1
                if g.frozen[me-1]:
                    totals["observed_own_frozen_status"]+=1
        EVIDENCE["full_games"]={"games":40,"checks":dict(totals),"mismatch_examples":problems}
        self.assertGreater(totals["own_shield_substitutions"],0)
        self.assertGreater(totals["own_move_substitutions"],0)
        self.assertGreater(totals["other_move_substitutions"],0)
        self.assertFalse(problems,f"Observation discrepancies {problems}")


if __name__ == "__main__":
    args = argparse.ArgumentParser()
    args.add_argument("--bot",type=Path,default=SOURCE)
    args.add_argument("--report",type=Path)
    opts = args.parse_args()
    SOURCE = opts.bot.resolve()
    result = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(Recovery))
    EVIDENCE.update(source_file=SOURCE.name, source_sha256=sha256(SOURCE.read_bytes()).hexdigest(),
                    tests_run=result.testsRun,status="pass" if result.wasSuccessful() else "fail",
                    failed_tests=[t.id() for t,_ in result.failures+result.errors])
    if opts.report:
        opts.report.write_text(json.dumps(EVIDENCE,indent=2),encoding="utf-8")
    print(json.dumps(EVIDENCE,indent=2))
    sys.exit(0 if result.wasSuccessful() else 1)
