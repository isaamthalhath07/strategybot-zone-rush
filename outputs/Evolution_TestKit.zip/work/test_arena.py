"""Executable rulebook examples and simultaneous-resolution regression cases."""
import random
import unittest
from arena import Cell, Game, HOMES, NEIGHBORS, Observation, map_values, play


def game_at(positions=HOMES, token=1, **kwargs):
    g = Game(start_token=token, values=[1] * 64, **kwargs)
    g.pos[:] = positions
    return g


IDLE = ["STAY"] * 4


class RefereeTests(unittest.TestCase):
    def test_interface_no_private_state_leak(self):
        g = game_at()
        state = g.state(4)
        self.assertEqual(set(Observation._fields), {"board", "bot_id", "is_priority_token", "legal_actions"})
        self.assertEqual(set(Cell._fields), {"occupant", "owner", "is_upgraded", "is_home", "base_points", "is_frozen"})
        self.assertEqual([len(row) for row in state.board], [8] * 8)
        self.assertIsInstance(state.board, list)
        self.assertEqual(state.board[7][0], Cell(4, 4, False, True, 1, False))
        self.assertEqual(state.board[6][0], Cell(0, 0, False, False, 1, False))
        self.assertFalse(state.is_priority_token)
        self.assertEqual(set(state.legal_actions), {"NORTH", "EAST", "STAY", "SHIELD"})
        state.board[0][0] = None
        self.assertIsNotNone(g.state(2).board[0][0])

    def test_uncontested_entry_neutral_take_and_score_timing(self):
        g = game_at()
        g.values[1] = 3
        g.step(["EAST", *IDLE[1:]])
        self.assertEqual((g.pos[0], g.owner[1], g.progress[0], g.scores[0]), (1, 0, 0, 1))
        g.step(IDLE)
        self.assertEqual((g.owner[1], g.upgraded[1], g.progress[0], g.scores[0]), (1, False, 0, 5))

    def test_four_way_token_contests_every_rotation(self):
        positions = [19, 26, 28, 35]
        actions = ["SOUTH", "EAST", "WEST", "NORTH"]
        for t in range(1, 5):
            g = game_at(positions, token=t)
            g.step(actions)
            self.assertEqual(g.pos[t-1], 27)
            self.assertEqual(g.owner[27], 0)
            for i, p in enumerate(positions):
                if i != t-1:
                    self.assertEqual((g.pos[i], g.owner[p]), (p, i + 1))

    def test_owner_priority_beats_every_token(self):
        for t in range(1, 5):
            for owner in range(1, 5):
                g = game_at([19, 26, 28, 35], token=t)
                g.owner[27] = owner
                g.step(["SOUTH", "EAST", "WEST", "NORTH"])
                self.assertEqual(g.pos[owner-1], 27)

    def test_token_skips_noncontender(self):
        g = game_at([26, 0, 63, 28], token=3)
        g.owner[27] = 2
        g.step(["EAST", "STAY", "STAY", "WEST"])
        self.assertEqual(g.pos, [26, 0, 63, 27])

    def test_swaps_and_following_blocked(self):
        g = game_at([17,18,63,56])
        g.step(["EAST","WEST","STAY","STAY"])
        self.assertEqual(g.pos[:2], [17,18])
        self.assertEqual(g.owner[17:19], [1,2])
        g.step(["EAST","EAST","STAY","STAY"])
        self.assertEqual(g.pos[:2], [17,19])

    def test_three_additional_own_stays_to_upgrade(self):
        g = game_at([1, 7, 63, 56])
        g.step(IDLE)
        for count in (1,2):
            g.step(IDLE)
            self.assertEqual((g.progress[0],g.upgraded[1]), (count,False))
        g.step(IDLE)
        self.assertEqual((g.progress[0],g.upgraded[1],g.scores[0]), (0,True,9))

    def test_level_one_raid_exact_bonus_and_income(self):
        g = game_at([1, 7, 63, 56])
        g.owner[1] = 2
        g.values[1] = 3
        g.step(IDLE)
        self.assertEqual((g.scores[:2],g.owner[1],g.upgraded[1]), ([28,1],1,False))

    def test_level_two_raid_three_stays_level_reset_and_reupgrade(self):
        g = game_at([1, 7, 63, 56])
        g.owner[1] = 2
        g.upgraded[1] = True
        g.values[1] = 3
        g.step(IDLE)
        g.step(IDLE)
        self.assertEqual((g.owner[1],g.progress[0],g.scores[:2]), (2,2,[2,14]))
        g.step(IDLE)
        # Seat 2's third simultaneous home STAY upgrades its home for this payout.
        self.assertEqual((g.owner[1],g.upgraded[1],g.progress[0],g.scores[:2]), (1,False,0,[54,16]))
        for _ in range(3):
            g.step(IDLE)
        self.assertTrue(g.upgraded[1])

    def test_foreign_home_is_uncapturable_even_after_long_stay(self):
        g = game_at([7, 6, 63, 56])
        for _ in range(10):
            g.step(IDLE)
        self.assertEqual((g.owner[7],g.progress[0],g.scores[0]), (2,0,10))

    def test_departure_resets_partial_progress(self):
        g = game_at([1, 7, 63, 56])
        g.owner[1], g.upgraded[1] = 2, True
        for actions in (IDLE, IDLE, ["EAST",*IDLE[1:]], ["WEST",*IDLE[1:]], IDLE):
            g.step(actions)
        self.assertEqual((g.owner[1],g.progress[0]), (2,1))

    def test_shield_catches_staying_resets_progress_and_saves_cell(self):
        g = game_at([1, 7, 63, 56])
        g.owner[1],g.upgraded[1],g.progress[0] = 2,True,2
        g.step(["STAY","SHIELD","STAY","STAY"])
        self.assertEqual((g.owner[1],g.progress[0],g.frozen[:2],g.cooldown[1]), (2,0,[2,0],4))
        self.assertEqual(g.state(1).legal_actions, ["STAY"])
        self.assertTrue(g.state(1).board[0][1].is_frozen)
        for remaining in [1,0]:
            g.step(["EAST",*IDLE[1:]])
            self.assertEqual((g.pos[0],g.frozen[0],g.progress[0]), (1,remaining,0))
        g.step(IDLE)
        self.assertEqual(g.progress[0],1)

    def test_shield_misses_an_arrival_or_departure(self):
        for start, end in [(1,2), (2,3)]:
            g = game_at([start,7,63,56])
            g.owner[2] = 2
            g.step(["EAST","SHIELD","STAY","STAY"])
            self.assertEqual((g.pos[0],g.frozen[:2],g.owner[2]), (end,[0,2],2))

    def test_blocked_move_is_catchable_including_home(self):
        g = game_at([7,6,63,56])
        g.step(["WEST","SHIELD","STAY","STAY"])
        self.assertEqual((g.pos[:2],g.frozen[:2]), ([7,6],[2,0]))

    def test_shield_while_on_rival_land_is_not_a_stay(self):
        g = game_at([1,7,63,56])
        g.owner[1], g.progress[0] = 2, 2
        g.step(["SHIELD","SHIELD","STAY","STAY"])
        self.assertEqual((g.owner[1],g.progress[:2],g.frozen[:2]), (2,[0,0],[2,2]))

    def test_multi_catch_and_already_frozen_ineligible(self):
        g = game_at([1,7,6,56])
        g.owner[1] = g.owner[6] = 2
        g.step(["STAY","SHIELD","STAY","STAY"])
        self.assertEqual(g.frozen,[2,0,2,0])
        g.cooldown[1] = 0  # independent eligibility fixture
        g.step(["STAY","SHIELD","STAY","STAY"])
        self.assertEqual(g.frozen,[1,2,1,0])

    def test_backfire_and_four_full_cooldown_turns(self):
        g = game_at()
        g.step(["SHIELD",*IDLE[1:]])
        for cd in [4,3,2,1]:
            self.assertEqual(g.cooldown[0],cd)
            self.assertNotIn("SHIELD",g.state(1).legal_actions)
            g.step(IDLE)
        self.assertIn("SHIELD",g.state(1).legal_actions)
        self.assertEqual(g.progress[0],2)

    def test_alternate_frozen_progress_begins_after_catch(self):
        g = game_at([1,7,63,56],frozen_stays_progress=True)
        g.owner[1],g.upgraded[1],g.progress[0] = 2, True, 2
        g.step(["STAY","SHIELD","STAY","STAY"])
        self.assertEqual(g.progress[0],0)
        g.step(IDLE)
        g.step(IDLE)
        self.assertEqual((g.progress[0],g.frozen[0],g.owner[1]), (2,0,2))
        g.step(IDLE)
        self.assertEqual(g.owner[1],1)

    def test_full_game_and_token_advance(self):
        g = game_at(token=3)
        for t in range(80):
            self.assertEqual(g.token, (2 + t)%4 + 1)
            g.step(IDLE)
        self.assertEqual((g.turn,g.scores), (81,[158]*4))
        with self.assertRaises(ValueError):
            g.step(IDLE)

    def test_synthetic_map_symmetry_and_range(self):
        for family in ["example","balanced","patchy","edge","flat"]:
            for seed in range(12):
                values = map_values(seed, family)
                for p, val in enumerate(values):
                    self.assertEqual(val, values[(7-p//8)*8+p%8])
                    self.assertEqual(val, values[(p//8)*8+7-p%8])
                    self.assertIn(val,(1,2,3))
        self.assertEqual(map_values(0,"example")[24:32],[2,2,3,3,3,3,2,2])

    def test_randomized_invariants(self):
        for seed in range(25):
            g = Game(seed=seed)
            rng = random.Random(seed)
            for t in range(80):
                previous = list(g.scores)
                old_pos = tuple(g.pos)
                acts = [rng.choice(g.legal(i)) for i in range(4)]
                g.step(acts)
                self.assertEqual(len(set(g.pos)),4)
                self.assertEqual([g.owner[p] for p in HOMES],[1,2,3,4])
                self.assertTrue(all(a > b for a,b in zip(g.scores,previous)))
                self.assertTrue(all(0 <= x <= 2 for x in g.progress))
                for i,p in enumerate(g.pos):
                    self.assertTrue(p==old_pos[i] or p not in old_pos)

    def test_policy_error_logged(self):
        broken = lambda state: 1 / 0
        g = play([broken] + [lambda s: "STAY"]*3,family="example")
        self.assertEqual(len(g.errors),80)
        self.assertEqual(g.scores,[158]*4)

    def test_home_then_adjacent_parking_score_against_pursuit(self):
        # Adversaries pursue the protected seat's destination and shield when adjacent.
        for family in ("example", "balanced", "patchy", "flat", "edge"):
            for seat in range(4):
                for seed in range(4):
                    g = Game(seed=seed, family=family, start_token=1 + seed)
                    h = HOMES[seat]
                    move, target = max(NEIGHBORS[h].items(), key=lambda a: g.values[a[1]])
                    for t in range(1,81):
                        actions = []
                        for i in range(4):
                            if i == seat:
                                actions.append(move if t == 4 else "STAY")
                                continue
                            opts = g.legal(i)
                            def distance(p):
                                return abs(p//8 - target//8) + abs(p%8 - target%8)
                            if "SHIELD" in opts and distance(g.pos[i]) <= 1:
                                actions.append("SHIELD")
                            else:
                                actions.append(min(opts, key=lambda a: distance(
                                    NEIGHBORS[g.pos[i]].get(a,g.pos[i]))))
                        g.step(actions)
                    self.assertEqual(g.scores[seat],158*g.values[h] + 149*g.values[target])
                    self.assertGreaterEqual(g.scores[seat],307)


if __name__ == "__main__":
    unittest.main(verbosity=2)
