import json
from pathlib import Path
p=Path('work/validation.json'); j=json.loads(p.read_text()); j['policies']['beam']={'path':str(Path('work/beam.py').resolve())}
base=[e for e in j['experiments'] if 'learned_tuned' in e['bots']]
# Exactly one target marker exists in these matched fixtures.
experiments=[]
for target in ['beam','planner']:
 for e in base:
  # learned_tuned never appears as an opponent in this selection suite.
  experiments.append(e | {'bots':[target if n=='learned_tuned' else n for n in e['bots']]})
j['experiments']=experiments
Path('work/architecture_selection.json').write_text(json.dumps(j,indent=2))
