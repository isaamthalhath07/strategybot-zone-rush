"""Build a portable evidence archive, then test the files actually extracted from it."""
from hashlib import sha256
import json
import os
from pathlib import Path, PureWindowsPath
import subprocess
import sys
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent / "outputs"
DEST = OUTPUT / "StrategyBot_TestKit.zip"
CODE = """arena bench analyze_holdout challengers beam planner planner_adaptive planner_beam
planner_terminal planner_rules safe_floor_bot test_arena test_terminal verify_testkit
validate_submission prepare_alternate_validation summarize_alternate beam_tune_trial
beam_validate_trial bot_audited test_recovery""".split()
EVIDENCE = """alternate_selection_results alternate_selection alternate_validation_raw
alternate_validation_summary alternate_validation architecture_results architecture_selection
beam_finalists_validation beam_tuning_trial candidates challenger_lure_trial
freeze_sensitivity_results freeze_sensitivity holdout_analysis holdout_lock holdout_results
holdout macro_results macro_selection official_snapshot screening_results screening
selection_lock selection_summary submission_validation top_candidates tuning_results
tuning validation_results validation organizer_clarifications clarification_revision
clarification_replay_summary recovery_before recovery_submission pre_clarification_results
pre_clarification_lock pre_clarification_plan pre_clarification_analysis pre_clarification_validation""".split()


def fingerprint(data):
    return sha256(data).hexdigest()


def json_bytes(data):
    return (json.dumps(data,ensure_ascii=False,indent=2)+"\n").encode("utf-8")


def portable_path(value):
    return PureWindowsPath(value).name if PureWindowsPath(value).is_absolute() else value


def files():
    payload = {name:(OUTPUT/name).read_bytes() for name in
               ("bot.py","bot_frozen_progress.py","StrategyBot_Research.md")}
    for name in CODE:
        file = ROOT/(name+".py")
        payload[file.name] = file.read_bytes()
    # Standalone helper scripts use the directory of the portable kit.
    script = payload["prepare_alternate_validation.py"].decode("utf-8")
    script = script.replace('OUT = ROOT.parent / "outputs"', 'OUT = ROOT')
    script = script.replace('str(OUT / "bot_frozen_progress.py")','"bot_frozen_progress.py"')
    payload["prepare_alternate_validation.py"] = script.encode("utf-8")
    script = payload["summarize_alternate.py"].decode("utf-8")
    script = script.replace("Path('work/","Path('").replace("Path('outputs/","Path('")
    payload["summarize_alternate.py"] = script.encode("utf-8")
    payload["README.md"] = (ROOT/"testkit_README.md").read_bytes()
    payload["holdout_results.csv"] = (ROOT/"holdout_results.csv").read_bytes()
    path_rewrites = {}
    for basename in EVIDENCE:
        name = basename+".json"
        raw = (ROOT/name).read_bytes()
        data = json.loads(raw)
        if isinstance(data,dict) and ("policies" in data or "hashes" in data):
            for policy in data.get("policies",{}).values():
                policy["path"] = portable_path(policy["path"])
                assert policy["path"] in payload
            if "hashes" in data:
                data["hashes"] = {portable_path(k):v for k,v in data["hashes"].items()}
            payload[name] = json_bytes(data)
            path_rewrites[name] = fingerprint(raw)
        else:
            payload[name] = raw
    analysis = json.loads(payload["holdout_analysis.json"])
    analysis["design"]["plan_sha256"] = fingerprint(payload["holdout.json"])
    payload["holdout_analysis.json"] = json_bytes(analysis)
    for name, digest in json.loads(payload["holdout_lock.json"])["hashes"].items():
        assert fingerprint(payload[name]) == digest, name
    alternate = json.loads(payload["alternate_validation_summary.json"])
    assert fingerprint(payload["bot_frozen_progress.py"]) == alternate["source_sha256"]
    # Store original score records and actual bytes of both tested programs unmodified.
    manifest = {"format_version":1, "hash_algorithm":"SHA-256",
                "primary_bot_sha256":fingerprint(payload["bot.py"]),
                "alternate_bot_sha256":fingerprint(payload["bot_frozen_progress.py"]),
                "relative_path_conversions_original_sha256":path_rewrites,
                "file_sha256":{k:fingerprint(v) for k,v in sorted(payload.items())}}
    payload["EVIDENCE_MANIFEST.json"] = json_bytes(manifest)
    private_fragments = (b"c:\\users",b"c:/users",b"/users/legion",b"documents\\\\codex")
    for k,raw in payload.items():
        assert all(fragment not in raw.lower() for fragment in private_fragments), k
    return payload


def main():
    payload = files()
    staging = ROOT/"packaging_qa"
    staging.mkdir(exist_ok=True)
    assert staging.resolve().is_relative_to(ROOT)
    with tempfile.TemporaryDirectory(dir=staging) as temp_name:
        temp = Path(temp_name).resolve()
        assert temp.is_relative_to(staging)
        zip_path = temp/"StrategyBot_TestKit.zip"
        with ZipFile(zip_path,"w",compression=ZIP_DEFLATED,compresslevel=9) as archive:
            for name,data in sorted(payload.items()):
                info = ZipInfo(name,date_time=(2026,11,6,12,0,0))
                info.compress_type = ZIP_DEFLATED
                archive.writestr(info,data,compresslevel=9)
        folder = temp/"extracted"
        with ZipFile(zip_path) as archive:
            assert archive.testzip() is None
            assert set(archive.namelist())==set(payload)
            archive.extractall(folder)
        clean = os.environ.copy()
        clean["PYTHONDONTWRITEBYTECODE"]="1"
        clean.pop("PYTHONPATH",None)
        def run(args):
            result = subprocess.run([sys.executable,"-B",*args],cwd=temp,env=clean,
                                    capture_output=True,text=True,encoding="utf-8",errors="replace")
            if result.returncode:
                raise ValueError(result.stdout+"\n"+result.stderr)
            return result.stdout+result.stderr
        print(run([str(folder/"verify_testkit.py")]),flush=True)
        rerun = temp/"replay_analysis.json"
        run([str(folder/"analyze_holdout.py"),"--output",str(rerun)])
        assert json.loads(rerun.read_bytes()) == json.loads(payload["holdout_analysis.json"])
        # Replay designated-seat, simultaneous 80-turn games using both actual output files.
        for name, comparator in (("holdout","holdout_results"),("alternate_validation","alternate_validation_raw")):
            plan = json.loads(payload[name+".json"])
            raw = json.loads(payload[comparator+".json"])["records"]
            indices = [0,len(raw)//2,len(raw)-1]
            plan["experiments"]=[plan["experiments"][i] for i in indices]
            replay_plan = temp/(name+"_sample.json")
            replay_plan.write_bytes(json_bytes(plan))
            replay_result = temp/(name+"_sample_result.json")
            run([str(folder/"bench.py"),str(replay_plan),str(replay_result)])
            records = json.loads(replay_result.read_bytes())["records"]
            for i,record in zip(indices,records):
                for k in ("scores","territory","bots","strict_first","pairwise","errors","target","target_seat"):
                    assert record[k]==raw[i][k],(name,i,k)
        os.replace(zip_path,DEST)
    print(f"PASS: {len(payload)} portable files, rule tests, terminal enumeration, two 80-turn smoke games, "
          "all 3,200 evidence rows re-analysed, six fixture replays matched. "
          f"ZIP bytes={DEST.stat().st_size}, SHA-256={fingerprint(DEST.read_bytes())}")


if __name__=="__main__":
    main()
