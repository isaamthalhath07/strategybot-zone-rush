from arena import Game
from challengers import build_policies
import beam
import json,sys
from itertools import product
from pathlib import Path
from multiprocessing import Pool
CONFIGS=[
(1.14,.84,1.,10,14), (1.35,.64,1.2,10,14), (.9,.62,1.3,10,14),
(1.1,.63,1.45,10,14), (1.35,.80,1.,8,14), (1.,.54,1.65,10,14),
(1.6,.60,1.35,10,14), (1.14,.70,1.7,12,20), (1.25,.50,1.0,8,12),
(1.35,.65,2.0,8,14), (1.10,.75,2.6,10,14)]
def run(args):
 cfg,family,seed,seat=args
 beam.UPGRADE,beam.RAID,beam.DEFENSE,beam.DEPTH,beam.WIDTH=cfg
 beam.MEM.clear()
 g=Game(seed=seed,family=family,start_token=1+(seed-seat)%4)
 names=['lure','fortress','adaptive'] if (seed+seat)%2 else ['raider','cautious','fortress']
 names.insert(seat,'beam')
 ps=[beam.act if n=='beam' else build_policies()[n] for n in names]
 while g.turn<=80:
    a=[p(g.state(i+1)) for i,p in enumerate(ps)]
    g.step(a)
 return (cfg,family,seed,seat,sum(g.scores[seat]>x for x in g.scores)/3, int(g.scores[seat]==max(g.scores)),g.scores[seat])
if __name__=='__main__':
 args=list(product(CONFIGS,['balanced','patchy','edge','example','flat'],[12],range(4)))
 with Pool(4) as pool: res=list(pool.map(run,args,chunksize=4))
 Path('beam_tuning_trial.json').write_text(json.dumps(res))
 for cfg in CONFIGS:
    x=[r for r in res if r[0]==cfg]
    print(cfg, *(round(sum(r[i] for r in x)/len(x),3) for i in [4,5,6]), flush=True)
