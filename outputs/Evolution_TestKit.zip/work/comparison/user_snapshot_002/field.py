"""
One registry, shared by every measurement script.

The realism problem with the original zoo was not that the bots were bad, it was
that they were all *mine*. The field that actually decides Round 1 is made of
other teams' bots, built the same way this one was -- so the dangerous entrants
are near-peers, not archetypes. This registry therefore has three tiers:

  peers     my own tuned versions and the counter-bots bred against them. The
            closest available model of "another team also used an agentic AI".
  designs   serious hand-written designs (aifield), each getting some part of
            the rulebook right and some part wrong, which is what real entries
            look like.
  weak      the original zoo and the held-out archetypes, because a real field
            of twenty-odd teams always contains several that barely work.

TIERS lets a script ask for a realistic mix or a deliberately brutal one.
"""
import arena


def registry(peers=True, designs=True, weak=True, holdouts=True, main=None):
    reg = arena.Registry()
    if designs:
        import aifield
        for c in aifield.AIFIELD:
            reg.add(c.name, (lambda k: (lambda s: k(s)))(c))
    if weak:
        import zoo
        for c in zoo.ZOO:
            if c.name in ("stay", "random"):
                continue                       # keep the floor, not the carpet
            reg.add(c.name, (lambda k: (lambda s: k(s)))(c))
    if holdouts:
        import holdout
        for c in holdout.HOLDOUT:
            reg.add(c.name, (lambda k: (lambda s: k(s)))(c))
    if peers:
        import rivals
        for n in rivals.names():
            reg.add(n, rivals.factory(n))
    if main is not None:
        import mybot
        reg.add("main", (lambda p: (lambda s: mybot.Agent(seed=s, params=p)))(main))
    return reg


# The mixes a measurement can be run against. "realistic" is the one that should
# drive decisions; "peer" is the hard case; "legacy" reproduces older numbers.
TIERS = {
    "realistic": ["v3", "v6", "nemesis2", "nemesis3", "ai_marginal", "ai_hawk",
                  "ai_homefort", "ai_cheapraid", "ai_centre", "ai_route",
                  "ai_elo", "spine", "camper", "greedy", "greedyshield",
                  "raider", "baiter", "turtle", "centre", "cdraider",
                  "hunter"],
    "peer": ["v3", "v4", "v6", "nemesis1", "nemesis2", "nemesis3", "ai_hawk",
             "ai_homefort", "spine"],
    "designs": [c for c in ("ai_marginal", "ai_cheapraid", "ai_homefort",
                            "ai_centre", "ai_route", "ai_hawk", "ai_elo")],
    "legacy": ["spine", "camper", "greedy_value", "greedy_shield", "raider",
               "baiter", "pacifist"],
}


def tier(name):
    return list(TIERS[name])
