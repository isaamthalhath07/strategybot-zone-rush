# StrategyBot — Zone Rush

A bot for **Zone Rush**, the four-player territory game used in StrategyBot
(ARC × Coding Club, AFKAR 2026, IIT Delhi — Abu Dhabi).

`bot.py` is the submission: one self-contained file, standard library only,
exposing `act(state)` exactly as the starter kit defines it.

Everything else here is the workshop that produced it — a rules engine, an
opponent zoo, a tournament harness, an evolutionary tuner, and a GPU self-play
track that was tried and rejected.

---

## Quickstart

```bash
python ship.py
```

Rebuilds `bot.py` from the tuned weights and verifies it. It refuses to pass
unless: imports are stdlib-only, `act(state)` is unchanged, the built file plays
move-for-move identically to the development bot, `decide()` raises no internal
exceptions, four seats can share one module without sharing state, and 40 stress
games produce no crash, no illegal action and no turn close to the 200 ms limit.

```bash
python test_engine.py
```

```bash
python strategies.py 150
```

> The check that matters most is **"decide() internal exceptions"**. `__call__`
> catches exceptions and returns `STAY`, so a completely broken bot looks healthy
> and scores zero. This caught exactly that: one parameter missing from a JSON
> file made the bot play `STAY` for all 80 turns while the stress test reported
> "0 failures".

---

## Results

Measured over **1,100 games with 20 entrants**, random seats, maps and starting
token, scored the way Round 1 scores it — each four-bot game becomes three
one-on-one results, so `PW/3` is how many of the three rivals were outscored.

| bot | Elo | PW/3 | score | 1st | what it is |
|---|---|---|---|---|---|
| **v3** | **1907** | **2.41** | **2536** | **56%** | this project |
| v1 | 1701 | 2.14 | 2345 | 44% | first tuned version |
| `spine` | 1607 | 1.77 | 2033 | 29% | best farmer written by hand |
| `camper` | 1577 | 1.59 | 2010 | 15% | takes the 3-cells and squats them |
| `cdraider` | 1457 | 1.34 | 1801 | 12% | raids only inside shield cooldowns |
| `greedy` | 1391 | 1.08 | 1566 | 10% | model of the typical AI-written bot |
| `stay` | 674 | 0.08 | 160 | 0% | an unmodified or crashing skeleton |

**300 Elo over the best bot written by hand, 516 over the modal AI-written
entry.** The `stay` row matters too: a bot that crashes, times out or returns an
illegal action plays `STAY` and finishes there.

`bot.py` ships **v6**, a later version that beats v3 on six of seven matchups:

| matchup | v3 | v6 |
|---|---|---|
| mixed zoo lineups | **2.90** | 2.81 |
| held-out lineups | 2.74 | **2.84** |
| vs 3× `spine` | 1.47 | **1.81** |
| vs 3× `camper` | 2.71 | **2.89** |
| vs 3× `cdraider` | 2.52 | **2.66** |
| vs 3× `hunter` | 2.77 | **2.91** |
| mean | 2.586 | **2.704** |

### Robustness

| | |
|---|---|
| counter-bot bred specifically to beat it | 2.17 / 3 — where 1.50 is no edge |
| held-out opponents, never tuned against | 2.84 / 3 |
| transfer ratio (held-out gain ÷ training gain) | 1.8 – 1.9 |
| all five ambiguous rules flipped at once | 2.81 / 3 |
| turn time | 2.6 ms mean, 6.1 ms max (limit 200) |
| crashes / illegal actions / timeouts | 0 |
| four identical copies against each other | 5% score spread, 1st to 4th |

v6 is the strongest version *and* the most exploitable one (v3 gives up only
1.72). It ships anyway, because no competing team has this source to breed a
counter from, and v6 generalises better to opponents it was never tuned against.
`python ship.py v3_params.json` swaps the other way in one command.

---

## How the bot works

### 1. It rebuilds the state the server hides

The starter kit's `state` exposes the board, `bot_id`, `is_priority_token` and
`legal_actions`. It does **not** expose the turn number, any bot's score, take or
upgrade progress, shield cooldowns, freeze counters, or which seat holds the
token. `Tracker` reconstructs all of it from board diffs.

Every shield is observable, because it either catches somebody (that bot freezes)
or it backfires (the shielder freezes). Attribution is genuinely ambiguous when a
bot freezes while standing on rival land — it was either caught by the landlord or
backfired on its own shield. Rather than guess, the tracker searches for the set
of shielders that *exactly explains* the freezes observed, using the hard
constraint that a shielder cannot lose a cell that turn, and stays pessimistic
where two explanations tie. Guessing gave 1,406 errors; solving gave 25.

Knowing every shield gives every four-turn cooldown — and **a rival on cooldown
cannot defend anything.**

Verified against the engine's hidden state over 3,200 turns: scores, progress,
positions, freezes and the token are **exact**; cooldowns are 99.2% exact with
residual errors in the safe direction. Worth **+0.65 pairwise wins and +376
points** per game (`test_amnesia.py`).

### 2. It plans routes, not targets

A beam search over *walks* — sequences of work-cells with the real travel cost
between them — rather than ranking single targets by rate. Scoring whole walks
prices travel correctly and prefers clusters.

An earlier version ranked single targets and **paced between two neighbouring
cells for an entire game**, scoring 1,050 instead of 2,400. The cause was cell
modifiers keyed to walk distance, so whichever cell the bot stood on was
penalised relative to its neighbour.

### 3. It treats defence as the game-theory problem it is

The shield/raid stand-off is a 2×2 game with no pure equilibrium, so a
predictable defender can be baited: step onto their cell, let them shield, step
off, and they are frozen for two turns and on cooldown for four. The bot prices
the backfire branch properly and weights it by a per-opponent estimate of whether
that rival commits or bails. Against an opponent that never commits, its shield
rate falls from 12% to 4% within a single game.

### 4. It self-throttles

The grading machine may be slower or busier than the one these weights were tuned
on, and a late turn is scored as `STAY`. The search has a hard internal deadline
checked mid-iteration, and the beam shrinks when a turn runs long and grows back
when there is room. Under 24× CPU oversubscription the worst turn was 80 ms
against the 200 ms limit.

---

## The game, in numbers

Manhattan distance splits the 8×8 board cleanly into four 4×4 quadrants, one per
corner. Each is worth **28 points per turn** and holds exactly three 3-point
cells. Nothing inside your own quadrant is reachable by a rival in under five
moves, so your inner cells are safe and the centre is the only ground genuinely
worth contesting.

A cell is worth its value multiplied by the turns remaining — a 3-point cell taken
on turn 10 pays 210 points, the same cell on turn 70 pays 30. Raid bonuses
(`8 × value × level`) are one-off and therefore do **not** decay, which is why
half of all bonus income arrives in the last 20 turns.

A perfect solo farmer restricted to its own quadrant scores 2,744. Unopposed and
free to expand, the bot scores 3,404.

---

## Layout

| file | what it is |
|---|---|
| **`bot.py`** | **the submission** — generated by `ship.py`, do not hand-edit |
| `mybot.py` | the bot's source: `Tracker`, the planner, the tactics |
| `engine.py` | rules engine; the five ambiguous rules are flags in `RULES` |
| `zoo.py` | opponent archetypes used for tuning |
| `holdout.py` | opponents never used in tuning, for the overfitting check |
| `arena.py` | Elo tournament harness |
| `tune.py` | (1+λ) evolutionary weight search, multiprocess |
| `strategies.py` | macro-strategy sweep across three opponent fields |
| `rivals.py` | frozen snapshots, so the bot can face earlier versions of itself |
| `exploit.py` | exploitability matrix: every counter against every version |
| `ship.py` | build and verify the submission |
| `gpuenv.py` | Zone Rush as batched tensors, for GPU self-play |
| `rl.py` | PPO self-play training on the GPU engine |
| `nnbot.py` | pure-Python inference twin of the learned policy |
| `v*_params.json` | tuned weight snapshots |
| `nemesis*.json` | counter-bots bred to beat a given version |

Scratch diagnostics, kept for reference and not needed to build or submit:
`diag*.py`, `dbg*.py`, `probe.py`, `calib.py`, `bench.py`, `patch_combo.py`,
`agent_new.py`, `final_eval.py`, `evaluate.py`.

### Tests

Everything, grouped by how badly a failure would hurt:

```bash
python runtests.py         # all suites; "fast" skips the two tournament ones
```

Individually:

```bash
# correctness -- every other number is measured through these
python test_engine.py      # rulebook examples + 400 fuzzed games with invariants
python test_gpuenv.py cpu  # tensor engine vs reference engine, state by state
python test_tracker.py     # the tracker's reconstruction vs the engine's hidden state

# survival -- cannot crash, stall, time out, or leak state between games
python test_guards.py      # progress-rule detection, the fallback policy, state
                           #   reuse, flat vs 8x8 boards, a server that offers
                           #   SHIELD on cooldown, stdlib shadowing
python test_timing.py      # graceful degradation on hardware up to 100x slower
python test_robust.py      # ambiguous-rule flips, malformed input, seat symmetry
python test_amnesia.py     # what happens if the server keeps no module state

# strength
python audit.py 20         # behavioural pathologies: pacing, shield-happiness
python diag_seat.py 160    # seat bias, where symmetry fixes the answer at 1.50
python diag_loss.py        # where my points actually go
python test_transfer.py    # held-out opponents never used in tuning
python test_fields.py      # how much strength depends on the assumed field
python test_oppmodel.py    # does the opponent model actually adapt
```

### Re-tuning

```bash
python tune.py <generations> <games/gen> <population> <field> <out.json> <seed.json>
python tune_rival.py <generations> <games/gen> <population> <out.json>
```

`field` is `default`, `mixed`, `realistic`, `peer`, or `counter:<snapshot>`.
`counter:` tunes a bot to *beat* a snapshot — that is how this bot's own
exploitability is measured, and how the training field was hardened.
`tune_rival.py` tunes the independent rival in `probot.py`, so that the field
contains a strong opponent built on a different architecture.

---

## Strategy sweep

`v1`…`v6` were the *same* strategy with different weights. `strategies.py` sweeps
the distinct macro plans the game admits, against three different opponent fields
with common random numbers. PW is out of 3; 1.50 is average.

| macro plan | mean PW | vs incumbent |
|---|---|---|
| **deep search + ignore rivals** | **2.824** | **+0.112** |
| deep search alone (visits 8, beam 300) | 2.802 | +0.090 |
| ignore rivals alone | 2.753 | +0.041 |
| incumbent | 2.712 | — |
| turtle (own quadrant only, upgrade everything) | 2.598 | −0.102 |
| centre-steal opening | 2.598 | −0.102 |
| pure farmer (never raid) | 2.589 | −0.111 |
| never shield | 2.287 | −0.413 |
| berserker (raid-first) | 2.253 | −0.447 |
| expansionist (claim the whole board) | 1.804 | −0.896 |

Two results worth absorbing.

**Ignoring rivals beats targeting them.** Maximising your own score and never
weighting a rival's loss scores better than the placement-margin objective the
earlier versions used. In a four-player game, hurting one rival mostly helps the
other two, and the tempo costs you more than it costs them. Maximising absolute
score turns out to be a very good proxy for placement.

**Deeper search is the biggest single lever, but not monotonically.** `visits 8,
beam 300` is the best setting found; `beam 700` is measurably *worse*, because a
wider candidate set dilutes the beam.

---

## The GPU / reinforcement-learning track

Set up, trained, and **rejected**. Recorded so it is not repeated blindly.

`gpuenv.py` reimplements the game as batched tensor operations. `test_gpuenv.py`
replays identical action sequences through it and `engine.py` and compares the
full state after **every turn** under all five ambiguous-rule settings: 9,600
comparisons, exact. That test earned its keep immediately — it caught a bug where
progress was zeroed on every turn of a freeze rather than only when a new freeze
landed, which is invisible under the default rules.

Throughput at batch 32,768: **134,000 complete 80-turn games per second**
(10.7M game-steps/s), against roughly 500K steps/s for the Python engine on one
core. The environment is effectively free.

`rl.py` trains a 75-feature MLP by PPO self-play; `nnbot.py` is its pure-Python
inference twin, verified to match the torch feature extraction to 2.8e-08. After
**164M steps** the policy plateaus and then declines:

| matchup | learned policy | the heuristic bot |
|---|---|---|
| mixed zoo lineups | 0.52 | **2.83** |
| held-out lineups | 1.10 | **2.91** |
| vs 3× `spine` | 0.08 | **1.70** |
| vs 3× `greedy` | 2.60 | **2.99** |
| vs 3× the heuristic bot | **0.00** | — |

Inference was never the obstacle (1.3 ms/turn, well inside budget). The policy is
simply weak, for two structural reasons:

- **Pure self-play converges to a weak mutual equilibrium.** All four seats share
  one policy, so it only ever has to beat itself.
- **No search.** The shipped bot beam-searches seven work-items deep over whole
  routes. Zone Rush rewards multi-turn commitment — one stay to claim, three more
  to upgrade, plus travel — and a reactive policy cannot plan a route.

If picked up again, in order: train against a **vectorised heuristic opponent on
the GPU** rather than against itself, or **warm-start by cloning the existing
bot** before any RL. Using the network as a value function inside the beam is a
dead end for the submission — thousands of forward passes per turn will not fit
200 ms of pure Python.

The GPU work needs a separate venv (`torch 2.11+cu128`, for sm_120 Blackwell
kernels). It is gitignored, and the shipped bot has no dependency on any of it.

---

## Mistakes found and fixed

There is no competition simulator and no trial run — whatever is in this
repository at the deadline is played once, by a server that cannot be inspected
beforehand. So the search for errors is worth as much as the search for strength.
These are the ones that were real.

- **A file named `select.py` shadowed the standard library.** `multiprocessing`
  imports `select`, so it loaded *this* directory's file instead, whose
  module-level code then parsed the tuner's command line and exited. A three-hour
  tuning run never started, and the symptom was an unrelated argument error about
  a filename. `test_guards.py` section F now checks that no file here shadows a
  stdlib module.
- **The bot could have shipped playing `STAY` for 80 turns.** `decide()` runs
  inside a `try/except` that returned `STAY` on any exception — so one bad
  assumption about the state object degrades the bot to the skeleton while every
  stress test still reports "no crashes". It had already happened once, from a
  single missing parameter key. There is now a `_fallback` policy that depends on
  almost nothing: stay on any cell that is not finished, otherwise walk toward the
  best unowned cell. With `decide()` forced to raise on every turn, the bot still
  scores **1365 against the skeleton's 158** — 8.6×. `ship.py` verifies the
  fallback survives into `bot.py`.
- **A seat-bias alarm that was the test's fault.** `test_robust.py` reported
  2.1 / 2.4 / 1.3 / 1.2 pairwise wins across the four seats, which looks like a
  bot hardcoded to a corner. It is not: the map is four-fold mirrored, so four
  copies of one bot must average exactly 1.50 per seat, and in self-play this bot
  scores **1.43 / 1.49 / 1.54 / 1.55** — noise. The asymmetry belonged to
  `SpineFarmerBot` (1.13 / 0.87 / 1.98 / 2.01); replacing a strong seat is a
  different experiment from replacing a weak one. The seat check is now self-play
  only (`diag_seat.py`).
- **The tuner's fitness function was non-deterministic.** Candidates were
  evaluated with the adaptive beam on, so identical parameters scored differently
  depending on machine load, and the search could chase timing artefacts.
  Evaluation now pins `throttle: 0`.
- **The progress-rule detector carried the wrong amount.** Under the carry-over
  reading, capturing an *upgraded* rival cell leaves progress at 3, not 1 — enough
  to re-upgrade it on the very next stay. Fixing it cut the reconstruction error
  from 36 wrong turns to 1 in 800.
- **`SHIELD` is now cross-checked against the bot's own cooldown**, not only
  against `legal_actions`. If the server offers `SHIELD` during cooldown and
  treats the attempt as `STAY`, the old code would waste the turn *and* record a
  shield that never went up. Verified: zero wasted shields under a server that
  offers it wrongly.
- **An opponent that paced instead of playing.** `ai_route` walked
  NORTH/SOUTH 66 times in 80 turns and banked 10 stays, because it re-planned from
  scratch every turn and the rate denominator shifted under its feet — the same
  class of bug that once halved this bot's own score. `audit.py` now flags it:
  any bot that stays on under 25% of turns, or reverses direction on over 22%, is
  doing something other than playing.

## Tested and found NOT to work

All of these were plausible, and several were confidently predicted before any
code ran. Recorded so they are not re-tried.

- **Priority-token contest avoidance** — tuned to exactly zero on a weak field, and
  back up to 0.92 on a strong one. Field-dependent, not free.
- **All-out endgame raiding** — the bot already shifts to raiding late on its own;
  forcing it harder is clearly worse (2.86 → 2.61).
- **Occupancy as deliberate defence** ("a cell I stand on cannot be entered") — no
  measurable benefit, because the planner is already parked on cells while
  upgrading them.
- **The centre-steal opening** — six turns of zero income is not recoverable.
- **Perishability bonus** and **retake credit** — both tuned to zero.
- **Equilibrium shield mixing** — the formula is correct and present, but it does
  not bind: stopping an imminent take is worth an order of magnitude more than a
  shield costs. The per-opponent commit estimate is what actually prevents
  baiting.
- **Consolidating late** and **varying risk with standing** — within noise.
- **PPO self-play**, as above.

Six more, all added after the ruleset was confirmed and all measured as paired
differences against v6 on the rebuilt field. `dPW` is the change in pairwise wins
out of 3; `z` is the paired z score, so anything inside ±2 is noise.

| idea | dPW | z | why it failed |
|---|---|---|---|
| Projected final scores in the objective | 0.0000 | — | **structurally inert**: v6's tuned `care_mode` is 4 (uniform), so the objective never reads rival scores at all |
| Home-upgrade bonus (the one unraidable doubling) | −0.013 | −1.5 | a home is only worth 1–2 base, so three early turns there costs more than immunity is worth |
| Penalise upgrading exposed cells (an upgrade doubles the bounty on it) | +0.002 | +0.6 | real, but far too small to see |
| 2 s of extra search on turn 1 | −0.005 | −0.6 | the opening is easy; depth buys nothing on an empty board |
| Pricing the progress a `SHIELD` throws away | −0.034 | **−3.4** | the cost is real, but v6's tuned `shield_bias` was already compensating for it, so adding it double-counts |
| Rival intent (discount cells a rival is visibly walking toward) | −0.027 | −1.1 | consistent with `perish` having already tuned to zero: rival-aware cell modifiers are worth nothing |

Both of the last two are left in the code at zero and handed to the tuner, which
can weigh them jointly against the parameters that were compensating for them.

Two further ideas were **killed by measurement before being built**:

- **Timing arrivals to the priority token.** The bot knows exactly which turns it
  holds the token and could schedule contested entries for them. Measured first:
  blocked moves and lost contests cost **0–0.9% of moves**, about 0.2 turns per
  game. The existing contest penalty already avoids them, so there is nothing to
  win.
- **Counting flipped pairings instead of points.** Round 1 scores each game as
  three one-on-one results, so a gain "should" be worth the number of rivals it
  lifts you past. This is **inert by construction**: a walk is scored by one
  scalar total, and any monotone transform of a scalar leaves the best walk
  unchanged. What the idea really reduces to is "prefer a certain gain when it
  already suffices, gamble when behind" — which is the existing `lead_caution`
  parameter.

### Defence has a ceiling, and it is about one cell per game

The bot shields on 1% of turns, which looked like a blind spot. `diag_loss.py`
settles it by counting what actually gets taken:

| opponent | my score | cells lost | income forgone | bonuses handed over | losses I *could* have shielded |
|---|---|---|---|---|---|
| `raider` | 2181 | 3.5 | 370 | 99 | 1.2 |
| `cdraider` | 2403 | 4.6 | 275 | 104 | 1.4 |
| `ai_hawk` | 2436 | 1.0 | 24 | 20 | 0.8 |
| `spine` | 2633 | 0.6 | 6 | 6 | 0.6 |

Most losses happen while the shield is on cooldown or the bot is frozen, so the
total headroom for better defence is **about one cell a game**. Near-zero
shielding is a correct read of the game, not an oversight — upgraded cells take
three stays to steal, so a compact upgraded cluster largely defends itself.

### One cautionary result

**v5 overfitted to beating itself.** Its training field contained four of its own
ancestors plus two counter-bots. It scored best of any version on that field and
worst of the lineage against outside opponents (2.55 against v3's 2.74).
Self-play fields need outsiders to stay honest, and version selection has to run
on an external tournament rather than on each run's own training score.

---

## The ruleset is now settled

`engine.py` originally encoded guesses at five rules the rulebook leaves
ambiguous. All five are now resolved, and **every one matched the default
reading**, so no retuning was needed on their account.

| # | Question | Answer | Source |
|---|---|---|---|
| 1 | Does a frozen bot's forced `STAY` accrue progress? | **No** | organisers, directly |
| 2 | After capturing a cell, does progress reset? | **Yes** (4 stays to own *and* upgrade a neutral cell) | starter README rules 5 + 7; also detected at runtime |
| 3 | Does losing a contested race count as a `STAY`? | **Yes** | starter README rule 4: "Unsuccessful moves count as `STAY`" |
| 4 | Can a bot `SHIELD` on rival land to dodge the catch? | **Yes** — a shield is not a stay | starter README rule 8 |
| 5 | Can a home cell be upgraded? | **Yes**, and it can never be captured | starter README rule 7 |

Two further facts from the starter kit that the bot depends on:

- `state.board` is an **8 × 8 list of lists**, row-major, `(0,0)` top-left, with
  `NORTH` = row − 1. The parser accepts a flat 64-list too, and `test_guards.py`
  checks both give the same move.
- Keeping state between turns is **explicitly allowed**, with the caveat that
  handling blocked or illegal moves is the entrant's problem. Both are handled:
  a blocked move is observed as a non-move and counted as a stay, exactly as the
  rules say.

Question 2 is the only one answered by inference rather than by a direct
statement, and it is the one that changes the arithmetic (4 stays versus 3 to own
and upgrade a neutral cell). So the bot does not rely on the inference: it
**measures the rule off the board at runtime**, by watching any bot capture a
cell and counting the stays until the upgrade appears. It takes about 7 turns to
settle and is correct in 10/10 games under either reading
(`test_guards.py`, section A).

## The field problem, and what was done about it

The honest weakness of the earlier results was that *every* opponent was written
for this project. Beating them partly meant beating my own assumptions. The brief
was to assume every other team also used an agentic assistant, so the field was
rebuilt in three tiers (`field.py`):

| tier | what it is | why |
|---|---|---|
| peers | tuned snapshots of this bot (`v3`, `v6`) and counter-bots bred against them | the closest available model of another team's tuned bot |
| designs | `aifield.py` — seven serious designs, each getting part of the rulebook right | what real entries look like |
| weak | the original zoo and held-out archetypes | a field of twenty-odd teams always contains several that barely work |

`aifield.py` exists because the original zoo missed two rule facts entirely:

- **a rival's *level-1* cell needs only one stay** and still pays the full
  `8 × base × 1` raid bonus, so cheap raids strictly dominate claiming an equal
  neutral cell;
- **a home can be upgraded and can never be captured**, making an upgraded home
  the only risk-free doubling on the board.

`probot.py` goes further: a rate-ranking bot on a genuinely different
architecture from the beam planner, with its own tunable weights
(`tune_rival.py`). Unopposed it outscores this bot — **3551 against 3276** —
because it pays nothing for defensive habits. It is in the field precisely
because it is not me.

## How changes are measured

Unpaired tournament means cannot see a change worth 0.02 pairwise wins: the
per-game standard deviation is about 1.0, so 400 unpaired games have a standard
error near 0.05 and most real improvements vanish into it.

`measure.py` therefore runs every variant over the **identical** list of
(map, seat, opponents, token) tasks and compares per-task differences. Map and
line-up luck cancels exactly, which shrinks the standard error three- to
five-fold. Two copies of the same parameters report a difference of exactly
0.0000 ± 0.0000, which is the harness validating itself.

```bash
python measure.py 700 realistic base=v6_params.json cand=v6_params.json+shield_bias:1.0
python choose.py 700          # the final three-tier comparison
```

One subtlety that mattered: the adaptive beam reacts to wall-clock time, so with
it on a candidate's *play* depends on how loaded the machine was. Evaluation now
forces `throttle: 0` everywhere (`tune.play_task`, `rivals.factory`,
`choose.py`); the throttle is shipping insurance against a slow grader, not part
of the policy, so it belongs in `bot.py` and not in the fitness function.
