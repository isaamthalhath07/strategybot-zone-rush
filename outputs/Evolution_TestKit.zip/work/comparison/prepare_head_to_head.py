import itertools,json
from pathlib import Path
j=json.loads(Path('work/comparison/final_plan.json').read_text()); evo=json.loads(Path('work/comparison/comparison_lock.json').read_text())['selected_evolved']; ex=[]
fields=[['incumbent','user',evo,'lure'],['incumbent','user',evo,'reserved_adversary'],['user','user_corrected',evo,'macro']]
for fam,seed,field in itertools.product(['balanced','patchy','edge','user_slope'],range(82000,82004),range(3)):
 for idx,bots in enumerate(itertools.permutations(fields[field])):
  ex.append({'bots':list(bots),'family':fam,'seed':seed,'lineup':field,'token':1+(idx+seed)%4,'stage':'direct head-to-head'})
j['experiments']=ex
Path('work/comparison/head_to_head_plan.json').write_text(json.dumps(j,indent=2))
print('Direct games',len(ex))
