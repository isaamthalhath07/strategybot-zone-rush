"""Write a readable account from the retained comparisons and training runs."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent.parent / "outputs"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def percent(value):
    return f"{100 * value:.2f}%"


def table(columns, rows):
    return "\n".join(["| " + " | ".join(columns) + " |",
                      "| " + " | ".join("---" for _ in columns) + " |",
                      *["| " + " | ".join(map(str, row)) + " |" for row in rows]])


def count_training(directory):
    programs, games, faults = set(), 0, 0
    for file in (directory / "cache").glob("*.json.gz"):
        with gzip.open(file, "rt", encoding="utf-8") as stream:
            rows = json.load(stream)
        games += len(rows)
        programs.update(row["target"] for row in rows)
        faults += sum(len(row["errors"]) for row in rows)
    return {"games": games, "targets": len(programs), "faults": faults}


def main():
    analysis = read(ROOT / "comparison_analysis.json")
    evolved = read(ROOT / "comparison_lock.json")["selected_evolved"]
    names = {evolved: "Evolved economic planner", "user": "Your submitted bot.py",
             "incumbent": "Previous workspace bot", "user_recovery": "Your bot with memory repairs",
             "user_corrected": "Your bot with memory and scoring repairs"}
    rows = [[names[name], stats["games"], percent(stats["pairwise"]), percent(stats["strict_first"]),
             f"{stats['latency_mean_ms']:.3f} ms", stats["errors"]]
            for name, stats in sorted(analysis["summary"].items(),
                                      key=lambda item: item[1]["pairwise"], reverse=True)]
    headline = table(["Program", "Games", "Pairwise credit", "Outright first", "Mean action", "Execution faults"], rows)
    family_table = table(["Map group", "Evolved", "Your submission", "Previous workspace bot"],
                         [[family, percent(stats[evolved]["pairwise"]), percent(stats["user"]["pairwise"]),
                           percent(stats["incumbent"]["pairwise"])]
                          for family, stats in analysis["family"].items()])
    comparison = analysis["paired"][evolved + " vs user"]
    delta = comparison["all_fixtures"]["pairwise"]["difference"]
    low, high = comparison["random_map_block_delta_95pct"]["pairwise"]
    head_rows = []
    all_counts = Counter()
    for field, data in analysis["head_to_head"].items():
        row = data["comparisons"][evolved + " vs user"]
        head_rows.append([field, row.get("wins", 0), row.get("draws", 0), row.get("losses", 0), percent(row["credit"])])
        for key in ("wins", "draws", "losses"):
            all_counts[key] += row.get(key, 0)
    head = table(["Same-game background field", "Evolved wins", "Draws", "Your wins", "Evolved pairwise credit"], head_rows)
    initial = count_training(ROOT.parent / "evolution" / "runs" / "league_001")
    initial_state = read(ROOT.parent / "evolution" / "runs" / "league_001" / "state.json")
    tested = set()
    for file in (ROOT.parent / "evolution" / "runs" / "league_001" / "cache").glob("*.json.gz"):
        with gzip.open(file, "rt", encoding="utf-8") as stream:
            tested.update(row["target"] for row in json.load(stream))
    actual_genomes = sum("family" in initial_state["registry"].get(name, {}) for name in tested)
    faults = read(ROOT / "user_fix_validation.json")
    transfer_path = ROOT / "transfer_analysis.json"
    if not transfer_path.exists():
        raise RuntimeError("Finish the transfer audit before producing the final report")
    transfer = read(transfer_path)
    recommended = transfer["recommended"]
    artifact = "bot_transfer_candidate.py" if recommended == "transfer_candidate" else "bot_evolved.py"
    digest = hashlib.sha256((OUTPUT / artifact).read_bytes()).hexdigest()
    selection_label = "second-run candidate" if recommended == "transfer_candidate" else "first-run winner"
    recommendation = (f"The recommended submission is outputs/bot.py, byte-identical to {artifact}, "
                      f"the {selection_label}. Its SHA-256 is {digest}. "
                      "It passed the locked performance decision and the exact-file reliability checks. "
                      "Both learning runs completed 22 epochs and 33,312 training games in total. "
                      "Selection, independent comparisons and diagnostic games are additional to that total.")
    text = f'''Evolutionary search and comparison with your separate model

{recommendation}

The current comparison identifies a stronger tested contender and preserves the exact programs, fixtures and results needed to challenge that conclusion. Your original project files were inspected and copied into a frozen local snapshot. Its README designates the root bot.py as the submission, so that exact 37,099-byte v6 file is the primary external comparison. Its SHA-256 is 6ebdfb1d64c848463c526a4dbb50464288227d063c6f93c9e3597339273b5d45. The separate saved neural policy is evaluated as a research variant.

**A guaranteed outright win over all opponents and all seats is impossible.** Rivals can submit the same program. In a four-copy game at most one player can finish strictly first, so at least three copies fail the proposed guarantee. Averaging over the four seats, any common policy's outright-first probability is at most 25%, including when the policy randomises. Equal-score ties may give several players shared credit, but do not produce four outright winners. This is not a 25% cap against different, weaker rivals. Rational players can optimise for their own score in different ways and respond to each other's policies. The useful objective is therefore strong measured tournament performance across maps and self-interested responses, backed by correct execution and failure recovery. No finite experiment can test every algorithm or certify an unknown final opponent population.

**The first evolved winner improved the matched field results.**

{headline}

Every row uses the same 1,024 designated-seat fixtures, with an identical map, initial token and ordered set of opponents. The panel contains 16 distinct boards across four map generators, four opponent lineups, all four seats and all four initial priority positions. The first three generators favour the centre, use irregular values, or favour the perimeter. The fourth is the generator from your project. All physical games use the confirmed frozen-STAY rule and the same independent referee, with 80 turns, a 200 ms action deadline and a 2-second first-action allowance. Round 1 equal scores receive half credit regardless of cell count. Internally caught exceptions are instrumented so an accidental STAY cannot masquerade as a clean result.

Pairwise credit is the fraction of the three rivals outscored, with half credit for a tie. Outright first requires a strictly higher score than all three. These rates describe the stated synthetic population. They are not calibrated probabilities of qualifying or winning the actual event.

The evolved planner's pairwise advantage over your submission was {100*delta:.2f} percentage points. A stratified bootstrap of whole random-board blocks gave a 95% difference interval of {100*low:.2f} to {100*high:.2f} points. Only four boards per generator were sampled. Repeated seats, tokens and opponents within a board are correlated and were kept together. The common seed IDs across generators are an additional reason to treat the interval as conditional on this map model.

{family_table}

**Direct shared games show a smaller, opponent-dependent advantage.**

{head}

Across these 1,152 games, the evolved bot beat your original submission {all_counts['wins']} times, lost {all_counts['losses']} and tied {all_counts['draws']}. The three fields contained the previous workspace bot plus a baiting rival, the previous bot plus a rival-intent challenger, or your corrected bot plus a separate job-search rival. All 24 seat permutations were used for each board and background field. This checks interactions that a single-program-against-a-fixed-field comparison can miss. An earlier 48-game diagnostic favoured your submission much more strongly. The larger panel includes more maps, opponent arrangements and a different evolved finalist.

**The learning run changes policies through actual selection, mutation and crossover.** The initial island population had three code families. Economic planning evolved 23 parameters, including one-, two- and three-job lookahead, opening and late-game weights, retention, raid risk, denial, shield thresholds and feints. Tactical search evolved eight parameters and enumerated simultaneous action alternatives, combining expected utility and downside. Action beam search evolved ten parameters controlling the horizon, width, discounts and economic guidance. Each family retained survivors so a promising algorithm could continue even when a different family led the overall panel.

The first run completed 16 epochs, comprising ten league epochs, four epochs constructing self-interested responses against the leading policy, and two epochs facing those responses. It executed {initial['games']:,} simulated games and evaluated {actual_genomes} distinct parameter configurations, plus the fixed reference. Three survivors per family progressed from 24 screening games to 96 common-fixture games. The fitness was 0.78 times mean pairwise credit, 0.20 times the worst opponent-lineup credit, and 0.02 times outright-first rate, with penalties for faults. Gaussian mutation, within-family crossover, elite survival and fresh random immigrants generated the next populations. The opponent archive grew as responses emerged. All {initial['games']:,} stored rows were independently counted, with {initial['faults']} recorded faults.

The final progress counter briefly included 30 offspring that were bred after the last epoch and never evaluated. They are excluded from the configuration count above. The checkpoint registry and raw games identify what actually played. Generation-to-generation percentages use changing maps and opponents, so their raw curve is not a fixed-benchmark learning curve. After evolution, 39 archived profiles and two references faced 2,624 selection-screen games. Six evolved finalists and both references then faced 5,120 confirmation games. The selected profile was frozen before the 5,120-game five-entrant comparison above. These are evolutionary parameter searches over a defined set of program architectures. They do not enumerate all algorithms, solve a Nash equilibrium or certify global optimality.

The selected first-run profile uses two-job planning, seven leading first jobs, a longer income-retention estimate and phase-dependent priorities. Upgrade weight rises from 1.46008 to 3.3705. Raid reward rises from 0.95839 to 1.64117, while defended-raid risk also rises from 1.97775 to 8.0. A higher raid reward therefore does not imply indiscriminate late aggression. The bot favours valuable safe opportunities and uses its observed defender model to discount exposed raids. This is a compact standard-library policy with memory recovery, rather than a neural network trained by gradient descent.

Both economic finalists also retain a limited final-turn safeguard. When the ordinary choice is STAY, staying cannot complete scoring work, SHIELD is legal and a rival occupies a vulnerable holding, shielding prevents a possible final raid without sacrificing productive work. A miss freezes the bot only after the last scoring turn. In that restricted situation SHIELD cannot worsen its score margin against any rival relative to STAY. The test kit enumerates opponents' legal joint actions in constructed positions and preserves all four classes of own scoring opportunity. This is a local dominance result, not a proof of an optimal full-game policy. The wider planner and shield model remain heuristic and deterministic, and a rival that knows the code and reconstructs its memory can predict its decisions. The response search measures some such weaknesses without eliminating them all.

{{TRANSFER_RESULTS}}

{{DEVELOPMENT_RESULTS}}

**Your submitted route-search bot has real strengths.** It searches sequences of work cells, prices travel, keeps a plan target and reconstructs scores, progress, priority and shield history. Its ordinary callback, timing and input-purity tests passed. Its wall-clock budget and beam throttling offer protection on a slow grader. In the initial same-game diagnostic, most of its advantage over the previous workspace bot came from recurring territory income. It collected more neutral cells, lost fewer upgraded holdings and spent fewer turns shielding. It also beat the previous workspace bot on the larger matched field. The measured strengths remain valid alongside the defects below.

**Two memory defects and two scoring defects were reproduced and repaired in isolated copies.**

1. The original tracker treated any home-only starting layout as a new game, even after one or several genuine turns of staying or an opening detour. After five all-home stays it still reported turn 1 and zero scores, against true turn 6 and eight points each. The repair uses an 80-turn boundary or irreversible board evidence. Returning to the original positions during an opening preserves the game clock.
2. When the server replaced a requested SHIELD with STAY, the original tracker could insist that the shield happened, invent its own cooldown and miss a rival's actual shield. The repair uses current legal shield availability and frozen status to constrain what actually executed. The tested example restores the rival cooldown of four and the correct own progress.
3. Work gains and completion pruning omitted income earned on the completion turn. In a constructed final-turn neutral 3-point case, the original chose NORTH instead of a scoring STAY and gave up three points. The corrected planner includes the completion turn in captures, upgrades and candidate pruning.
4. Defence counted a visitor on an untakeable home as a takeover threat. In a constructed final-turn case it shielded that visitor while standing on a rival's ordinary 3-point cell, giving up its own 24-point raid bonus and three income. The corrected version excludes home visitors from takeover valuation and chooses the scoring stay in that case.

Both repaired builds retain your tuned strategic weights. Independent tests checked 960 public callbacks per build with substituted actions and reused modules. Turn, score, positions, own cooldown, frozen status and own progress matched the referee. No hidden exceptions, illegal moves, input changes or deadline misses occurred. In a separate eight-game stress test, the original accumulated 474 wrong turn and score observations and 12 actionable progress mismatches. Those were mostly persistent consequences of a few early errors, rather than 474 independent faults. Both repairs eliminated those discrepancies in that test.

The standalone repaired copy is delivered as outputs/bot_user_corrected.py. Its original strategic weights are preserved so it remains a useful comparison with your work. Your project's ship.py rebuilds from its mybot.py development template. These isolated repairs were not applied to that template. Rebuilding there would overwrite them unless the corresponding fixes are also carried into that template. This work made no changes to the original project.

The ordinary, uncorrupted matched panel gave only a small aggregate change from the repairs. The corrected version's 72.80% pairwise credit compares with the original's 72.59%, and the paired confidence interval includes zero. Correcting a reproducible fault is supported by its regression test. The current data do not establish a meaningful overall win-rate improvement from those repairs alone.

Two further limitations remain. With the original v6 weights and at least eleven turns on its internal clock, one eligible raider on a single level-1 holding cannot satisfy the shield threshold, even under a maximal commitment estimate. Also, once its original defence threshold is satisfied, its computed shield probability is at least two-thirds, above shield_certain=0.6. Its final defensive action is therefore deterministic in that branch despite the source description of mixing. The opponent model still changes whether the branch is reached. These are implementation properties of those exact weights, rather than explanations for every loss. The new evolution can change the thresholds. A remaining final-turn limitation can value shielding a nonhome invader even when that invader cannot finish its raid and our bot could score elsewhere.

**The saved neural policy failed this comparison through game decisions, rather than crashes.** In the 64-game screening panel it earned 1.04% pairwise credit and zero outright firsts, with no illegal actions or recorded errors. Eight prespecified traces exactly reproduced the scores. Across their 640 turns it chose STAY 548 times, including 182 forced frozen turns. It performed no upgrades or shields and rarely left rival land, suffering 11.75 catches and 22.75 frozen turns per game on average. It did obtain raid bonuses, but its mean ownership income was about 992 against 2,823 for the strongest rival. The resulting mean final deficit was about 1,788 points. The lack of sustained income dominated the occasional bonuses.

The NNAgent stores a greedy flag but its supplied decision function always chooses the largest legal logit. Passing greedy=False changed none of the 64 final scoreboards, so that flag is not a genuine stochastic evaluation. This result concerns the saved policy and inference code. It is not a general result about PPO or neural policies. The shipped bot.py is the heuristic v6, with the neural policy remaining a separate, non-self-contained research artifact requiring helper code and weights.

**The two local referees agree on physical play under their default confirmed rules.** Five hundred complete games and 40,000 matched transitions produced equal ownership, levels, positions, freezes, cooldowns, progress, scores, token and turn. The external engine lists more in-bounds moves into occupied cells, while the workspace engine removes them from legal_actions. Both resolve an actual blocked attempt as STAY. This is an interface sensitivity to keep testing.

The external tournament harness applies cell count to equal-score standings for its Round 1 comparisons. The rulebook's Round 1 definition gives a score tie half credit, with the cell tiebreak used in Round 2. Six score ties in the differential corpus were split by the external ranking. Its generic play helper also catches exceptions without recording them and accepts actions beyond the official time budget. The submitted bot passed the sampled deadline tests, so the harness flaw is not evidence that it actually exceeded the limit. These differences mean historical Elo and win percentages from the two projects cannot be compared directly. The shared tournament uses score-only Round 1 ties, deadline enforcement and internal exception counters for both programs.

Your project's random maps are predominantly centre-sloped and inexpensive at home. Of 500 seeds, 319 distinct boards were generated, with 497 homes worth one point and three worth two. A seed count is therefore not a distinct-map count. The rulebook illustration's quadrant sums to 29, and random mirrored maps do not all have one fixed quadrant total. The comparison includes both that project generator and broader stress maps. The official map distribution and entrant population remain unavailable.

**The loss traces identify concrete limits without using future information inside a bot.** Four largest defeats and two ordinary wins were selected per program by a fixed rule. Twenty-nine of the 30 replays reproduced their original scoreboards. One time-dependent user-derived search replay differed and was excluded from the aggregate diagnoses. The saved traces reconcile each turn's score as owned-cell income plus raid bonuses. Large losses generally accumulated through an income gap in the middle and late game. The evolved bot's four sampled worst defeats still averaged an 841.5-point deficit. It can be pinned by stronger territory income and disrupted work. Its successful training does not make it unbeatable.

One-turn hindsight alternatives in turns 75-80 hold the other three realised actions fixed. They diagnose a missed immediate scoring opportunity, and were never supplied to a playing bot. They do not prove that a different early route would win or that an opponent's hidden current action could be known. Selected catastrophic losses are a case study, not an unbiased estimate of all failure causes.

The second audit added eighteen similarly selected traces, all reproducing their original scoreboards. The new finalist's four worst defeats averaged a 1,141.75-point deficit, of which 1,125.75 came from territory income. Its score margin fell from +0.75 at turn 20 to -532.5 at turn 60. The first-run winner's four worst defeats averaged a 1,145.25-point deficit, including 1,065.25 from income, and its four cases share seed ID 95002 across four distinct map groups. Both programs had extreme losses with zero backfires. No alternative final-turn action improved placement in those eight cases with the other realised actions held fixed. Two of the new finalist's defeats were won by the identical genome in a different seat. These observations point to compounding income, retained territory and seat interactions in these particular failures, rather than proving one shield weight or one architecture caused every loss. Ordinary selected wins averaged margins of 99 and 96 points respectively. Full traces retain the action and income accounting needed to investigate earlier route choices.

The practical next steps are to run the offered organiser compatibility check on the recommended single-file artifact, keep the required act(state) signature and filename bot.py for submission, and continue adding self-interested counter-strategies to the training population. The supplied trainers, genomes, opponent archive, fixtures, raw outcomes, traces, recovery tests and manifests make further cycles reviewable. A new training cycle must use a new run directory and its own fresh validation maps. More compute can improve the tested policy, while every performance statement remains conditional on the tested rules, maps and opponent population.

The population method is informed by black-box evolutionary optimisation and response-oracle research. Its implementation here is a finite genetic search with an archive of responses. [Salimans and colleagues, Evolution Strategies](https://arxiv.org/abs/1703.03864), [Lanctot and colleagues, policy-space response oracles](https://papers.nips.cc/paper_files/paper/2017/file/3323fe11e9595c09af38fe67567a9394-Paper.pdf).
'''
    transfer_summary = ROOT / "transfer_analysis.json"
    if transfer_summary.exists():
        text = text.replace("{TRANSFER_RESULTS}", read(transfer_summary)["report_text"])
    else:
        text = text.replace("{TRANSFER_RESULTS}", "The second league and its separate audit are still being completed.")
    development = ROOT / "development_analysis.json"
    if not development.exists():
        raise RuntimeError("Finish the updated-development comparison before publishing the report")
    text = text.replace("{DEVELOPMENT_RESULTS}", read(development)["report_text"])
    (OUTPUT / "Evolution_Comparison.md").write_text(text, encoding="utf-8")
    print(f"Wrote {len(text.split()):,} words")


if __name__ == "__main__":
    main()
