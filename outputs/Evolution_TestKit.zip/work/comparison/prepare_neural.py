import json
from pathlib import Path
p=Path('work/comparison/screen_plan.json'); j=json.loads(p.read_text()); old=[r for r in j['experiments'] if r['target']=='user']; snapshot=Path('work/comparison/user_snapshot_001').resolve()
j['policies']['user_nn']={'path':str(snapshot/'nnbot.py'),'entry_class':'NNAgent','weights':str(snapshot/'nn_policy.json'),'audit_internal':True}
j['experiments']=[r | {'target':'user_nn','bots':['user_nn' if n=='user' else n for n in r['bots']]} for r in old]
Path('work/comparison/neural_plan.json').write_text(json.dumps(j,indent=2))
