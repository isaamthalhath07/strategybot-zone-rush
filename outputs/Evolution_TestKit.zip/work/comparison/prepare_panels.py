"""Freeze common selection and comparison fixtures before examining outcomes."""
import argparse
import itertools
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parent
EVOLUTION = ROOT.parent / "evolution"
SNAPSHOT = ROOT / "user_snapshot_001"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def registry():
    state = read(EVOLUTION / "runs" / "league_001" / "state.json")
    policies = dict(state["registry"])
    policies["user"] = {"path": str(SNAPSHOT / "bot.py"), "audit_internal": True}
    policies["reserved_adversary"] = {"path": str(EVOLUTION / "adversary.py")}
    policies["user_spine"] = {"path": str(SNAPSHOT / "zoo.py"), "zoo_name": "spine"}
    policies["user_camper"] = {"path": str(SNAPSHOT / "zoo.py"), "zoo_name": "camper"}
    policies["user_cdraid"] = {"path": str(SNAPSHOT / "holdout.py"), "entry_class": "CooldownRaiderBot"}
    policies["user_nn"] = {"path": str(SNAPSHOT / "nnbot.py"), "entry_class": "NNAgent",
                           "weights": str(SNAPSHOT / "nn_policy.json"), "audit_internal": True}
    for name in ("user_recovery", "user_corrected"):
        path = ROOT / (name + ".py")
        if path.exists():
            policies[name] = {"path": str(path), "audit_internal": True}
    return policies, state


def panel(targets, lineups, seed_base, maps_per_family, tokens, stage):
    fixtures = []
    for target, family, map_index, lineup_index, seat, token_index in itertools.product(
            targets, ["balanced", "patchy", "edge", "user_slope"], range(maps_per_family),
            range(len(lineups)), range(4), range(tokens)):
        seed = seed_base + map_index
        token = 1 + (map_index + seat + 2 * token_index + lineup_index) % 4
        if tokens == 4:
            token = token_index + 1
        rivals = list(lineups[lineup_index])
        random.Random(seed * 100 + seat * 10 + token + lineup_index * 1000).shuffle(rivals)
        bots = list(rivals)
        bots.insert(seat, target)
        fixtures.append({"target": target, "target_seat": seat, "bots": bots,
                         "family": family, "seed": seed, "lineup": lineup_index,
                         "token": token, "stage": stage})
    return fixtures


def save(path, policies, fixtures):
    involved = {name for fixture in fixtures for name in fixture["bots"]}
    path.write_text(json.dumps({"policies": {name: policies[name] for name in sorted(involved)},
                                "experiments": fixtures}, indent=2), encoding="utf-8")
    print(f"Saved {len(fixtures)} games to {path.name}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["screen", "confirm", "final"])
    args = parser.parse_args()
    policies, state = registry()
    history = state["history"]
    league = history[9]["leader"]
    response = next(name for name in reversed(state["response_ids"]))
    beam = "action_beam_1ea33eef3561"
    tactical = "tactical_9d8c8555d2a9"
    lineups = [["fortress", "lure", "macro"], ["incumbent"] * 3,
               [league, response, beam], ["user_spine", "user_camper", "user_cdraid"]]
    if args.stage == "screen":
        targets = list(dict.fromkeys(state["archive"] + ["incumbent", "user", beam, tactical]))
        fixtures = panel(targets, lineups, 40000, 1, 1, "selection screen")
    elif args.stage == "confirm":
        screen = read(ROOT / "screen_results.json")["summary"]
        ranked = sorted(screen, key=lambda name: (screen[name]["pairwise"], screen[name]["strict_first"]), reverse=True)
        evolved = [name for name in ranked if name not in ("user", "incumbent")][:6]
        targets = [*evolved, "incumbent", "user"]
        fixtures = panel(targets, lineups, 50000, 5, 2, "selection confirmation")
        (ROOT / "finalist_ids.json").write_text(json.dumps(targets, indent=2))
    else:
        confirm = read(ROOT / "confirm_results.json")["summary"]
        evolved = max((name for name in confirm if name not in ("user", "incumbent")),
                      key=lambda name: (confirm[name]["pairwise"], confirm[name]["strict_first"]))
        targets = ["incumbent", "user", evolved, "user_recovery", "user_corrected"]
        # This opponent was reserved throughout evolution and selection.
        lineups[1] = ["reserved_adversary", "user_cdraid", tactical]
        fixtures = panel(targets, lineups, 80000, 4, 4, "final comparison")
        (ROOT / "comparison_lock.json").write_text(json.dumps({"selected_evolved": evolved,
              "targets": targets, "selection": confirm[evolved], "final_maps_seen_before": False}, indent=2))
    save(ROOT / (args.stage + "_plan.json"), policies, fixtures)


if __name__ == "__main__":
    main()
