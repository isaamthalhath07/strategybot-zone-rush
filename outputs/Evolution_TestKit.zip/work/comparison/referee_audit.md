# Independent external referee and bot audit

## Physical game transitions

With the projects' default rules, both local referees produced identical cell ownership and upgrades, positions, freeze and cooldown counters, action progress, cumulative scores, token and turn after all 40,000 matched turns. The 500 complete games included all four seats, all starting tokens, movement contests, shields, frozen turns and invalid action strings. Both implement the organiser's clarification that a frozen stay adds zero progress.

The public legal-action lists differ. External `engine.py`, line 133, offers any in-bounds direction. The other referee excludes occupied destinations. The engines gave the same resulting stay for attempted entries into start-occupied squares. We counted 10,699 extra occupied directions in the external action lists across the four seats and all tested turns. A bot that relies on list order or assumes every listed move will succeed may make different decisions even when physical rules agree.

## Differences affecting benchmark interpretation

* External `engine.py`, line 321, ranks by score followed by end-of-game territory; its tournament applies those places to Round 1 pairwise ratings. Round 1 uses score ties as draws. On one reachable board the external referee ranked seat 1 second and seat 4 third. Both scored 528, with 10 and 7 cells. We found six such pairwise ties in these 500 games. Territory is a valid Round 2 tiebreaker.
* External `engine.py`, line 338, accepts late legal returns and silently replaces raised exceptions with a stay. In a two-turn test, a deliberately 230 ms EAST on turn 2 moved a bot from square 1 to square 2. Under the 200 ms rule the bot stays at square 1 and captures it. This identifies a harness limitation; the shipped entrant stayed within the deadline in the independent sample.
* The other project's generator produces mostly cheap homes and a strongly center-weighted map. Seeds 0 through 499 produced 319 distinct boards, with home base 1 on 497 seeds and 2 on three. Its example map quadrant is worth 29. The rulebook permits variation; the external README's fixed figure of 28 and invariant argument about quadrant value do not characterize all competition maps. Its 56% tournament-first table is labeled v3, while current `bot.py` is labeled v6.
* The shipped bot searches with an internal 60 ms deadline and adjusts beam width according to elapsed wall time. Comparable fixtures should run under comparable system load. The tournament is an approximation to the unknown event field and Elo schedule.

## Two reproducible memory defects in the submitted file

1. External `bot.py`, lines 180–185 and 401–408, infers a new game whenever all bots occupy their homes and other squares are neutral. After a genuine all-STAY turn it reports turn 1 with four zero scores and own progress 0; the server is on turn 2, has awarded every player one point and has granted one upgrade stay. It still reports turn 1 after three stays despite all four homes being upgraded. A full game reset detector should use an actual preceding game boundary or irreversible board changes.
2. External `bot.py`, lines 256–305, treats its last requested SHIELD as authoritative during attribution. In the included two-intruder position it genuinely requests SHIELD, the host rejects it into a stay, and its rival's own shield backfires. The public list still offers the player SHIELD. Nevertheless the tracker assigns its own cooldown 4 rather than 0, its rival cooldown 0 rather than 4, and own partial-upgrade progress 0 rather than 1. The score reconstruction remains correct in this case. A still-legal shield directly excludes an accepted shield on the previous turn.

## Actual external callback sample

The shipped candidate imports only `collections` and `time` and exposes the standard one-argument entry point. Across 640 calls on the exact public four-field view in eight sampled games, no input was mutated, every return was legal and on time, and instrumentation inside its exception-catching wrapper observed no internal exceptions or illegal replacements. Mean latency was 2.61 ms, p99 was 5.30 ms and maximum was 6.40 ms on this host. These measurements support interface compatibility independently of the two memory defects above.

See `referee_audit_results.json` for source fingerprints, fixtures and measurements. `referee_audit.py --external-dir PATH` repeats the checks using the external sources read-only.
