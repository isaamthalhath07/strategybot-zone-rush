"""Freeze the concurrently updated development code without touching its project."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
SOURCE = Path("C:/Users/LEGION/stratergybot")
DEST = ROOT / "user_snapshot_002"


def main():
    assert not DEST.exists(), "Use another snapshot number instead of overwriting evidence"
    DEST.mkdir()
    files = {}
    for path in SOURCE.iterdir():
        if not path.is_file() or not (path.suffix in (".py", ".json") or path.name == "README.md"):
            continue
        before = path.stat()
        data = path.read_bytes()
        after = path.stat()
        assert before.st_mtime_ns == after.st_mtime_ns and len(data) == before.st_size
        (DEST / path.name).write_bytes(data)
        files[path.name] = {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
    source = (DEST / "mybot.py").read_text(encoding="utf-8-sig")
    tree = ast.parse(source)
    assignment = next(n for n in tree.body if isinstance(n, ast.Assign) and
                      any(isinstance(t, ast.Name) and t.id == "PARAMS" for t in n.targets))
    parameters = ast.literal_eval(assignment.value)
    parameters.update(json.loads((DEST / "best_params.json").read_text(encoding="utf-8")))
    lines = source.splitlines(keepends=True)
    baked = "PARAMS = " + repr(parameters) + "\n"
    exported = "".join(lines[:assignment.lineno-1]) + baked + "".join(lines[assignment.end_lineno:])
    output = ROOT / "user_development_002.py"
    output.write_text(exported, encoding="utf-8")
    lock = {"snapshot_utc": datetime.now(timezone.utc).isoformat(),
            "files": files, "development_source": "mybot.py", "weights": "best_params.json",
            "build_method": "Literal PARAMS replacement with defaults plus best_params, matching ship.build semantics; did not execute original builder",
            "exported_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
            "exported_bytes": output.stat().st_size, "parameters": parameters}
    (ROOT / "user_development_lock.json").write_text(json.dumps(lock, indent=2), encoding="utf-8")
    plan = json.loads((ROOT / "transfer_audit_plan.json").read_text(encoding="utf-8"))
    fixtures = []
    for original in plan["experiments"]:
        if original["target"] != "user":
            continue
        row = dict(original, target="user_development", stage="updated development independent comparison")
        row["bots"] = list(original["bots"])
        row["bots"][row["target_seat"]] = "user_development"
        fixtures.append(row)
    plan["policies"]["user_development"] = {"path": str(output), "audit_internal": True}
    plan["experiments"] = fixtures
    (ROOT / "development_plan.json").write_text(json.dumps(plan, indent=2), encoding="utf-8")
    print(json.dumps({"files": len(files), "source_sha256": lock["exported_sha256"], "games": len(fixtures)}, indent=2))


if __name__ == "__main__":
    main()
