"""Rule-based selection and concrete replay for diagnostic cases. Never sends postgame actions to bots."""
from collections import Counter,defaultdict
import gzip
import json
from pathlib import Path
import statistics
import sys
from failure_analysis import trace_fixture

D=Path(__file__).resolve().parent
FIELDS=("neutral_captures","upgrades","raids","upgraded_raids","cells_lost","lost_upgraded_cells",
        "income_points","raid_points","successful_moves","blocked_moves","shields","rivals_caught",
        "backfires","frozen_turns_served","caught_by_shield","foreign_stays","foreign_departures")

def read(name):
 return json.loads((D/name).read_text(encoding='utf-8-sig'))

def case(trace,seat):
 i=seat-1; turns=trace['turns']; scores=trace['final_scores']; rival=max((s for s in range(4) if s!=i),key=scores.__getitem__)
 stats=trace['metrics'][i]; rivalstats=trace['metrics'][rival]; actions=Counter(t['actions'][i] for t in turns)
 visits=[turns[0]['positions_before'][i]]+[t['positions_after'][i] for t in turns]
 reversals=sum(visits[j]==visits[j-2] and visits[j]!=visits[j-1] for j in range(2,len(visits)))
 milestones={m['turn']:m['scores'][i]-m['scores'][rival] for m in trace['milestones']}
 end=turns[-1]['hindsight'].get(seat,{})
 return {'seat':seat,'bots':trace['bots'],'family':trace['family'],'seed':trace['seed'],
         'token':trace['token'],'target':trace['bots'][i],'reference_rival':trace['bots'][rival],
         'actual_scores':scores,'end_gap':scores[i]-scores[rival],'margins_by_turn':milestones,
         'metrics':{k:stats.get(k,0) for k in FIELDS},'best_opponent_metrics':{k:rivalstats.get(k,0) for k in FIELDS},
         'actions':dict(actions),'distinct_cells_visited':len(set(visits)),'immediate_reversals':reversals,
         'first_owner_change_turn':next((t['turn'] for t in turns if any(e[0] in ('raid','neutral_capture') and e[1]==seat for e in t['events'])),None),
         'turn80_hindsight_own_score_gain':end.get('one_turn_max_own_points_gain',0),
         'turn80_hindsight_pairwise_credit_gain':end.get('one_turn_max_credit_gain',0),
         'turn80_hindsight_margin_against_reference_gain':end.get('one_turn_max_margin_gain_by_rival',[0]*4)[rival]}
def pick_neural(fixtures):
 # Plan-only stratification. Two fixtures per map family, two per starting seat and two per lineup.
 out=[]
 for f,family in enumerate(['balanced','patchy','edge','user_slope']):
  for offset in [0,1]:
   lineup=(f+offset)%4;seat=(f+lineup)%4
   out.append(next(j for j,x in enumerate(fixtures) if x['family']==family and x['lineup']==lineup and x['target_seat']==seat))
 return [(i,'stratified') for i in out]

def pick_outcomes(rows):
 by=defaultdict(list)
 for idx,r in enumerate(rows):
  seat=r['target_seat'];scores=r['scores'];others=[v for j,v in enumerate(scores) if j!=seat]
  by[r['target']].append((scores[seat]-max(others),idx))
 out=[]
 for key,data in sorted(by.items()):
  # All defeats available, sorted by exact gap to winner. Det. tie-break: fixture-plan order.
  losses=sorted((p for p in data if p[0]<0))[:4]
  # Median and lower-quartile strict wins contrast with worst defeats without cherry-picking blowouts.
  wins=sorted(p for p in data if p[0]>0)
  indices=sorted(set([len(wins)//4,len(wins)//2])) if wins else []
  out.extend((i,'worst_defeat') for _,i in losses);out.extend((wins[k][1],'ordinary_win') for k in indices)
 return out

def summary(cases):
 keys=tuple(cases[0]['metrics']); counts=Counter()
 for c in cases:counts.update(c['actions'])
 return {'games':len(cases),'actions':dict(counts),
         **{k:round(statistics.mean(c[k] for c in cases),3) for k in ['end_gap','distinct_cells_visited','immediate_reversals']},
         'metrics':{k:round(statistics.mean(c['metrics'][k] for c in cases),3) for k in keys},
         'best_opponent_metrics':{k:round(statistics.mean(c['best_opponent_metrics'][k] for c in cases),3) for k in keys},
         'turn80_hindsight_higher_score_count':sum(c['turn80_hindsight_own_score_gain']>0 for c in cases),
         'turn80_hindsight_better_placement_count':sum(c['turn80_hindsight_pairwise_credit_gain']>0 for c in cases),
         'mean_gaps_by_turn':{t:round(statistics.mean(c['margins_by_turn'][t] for c in cases),2) for t in cases[0]['margins_by_turn']}}
def run(stage):
 plan=read(stage+'_plan.json'); raw=read(stage+'_results.json')
 fixtures=plan['experiments']; rows=raw['records']
 picked=pick_neural(fixtures) if stage=='neural' else pick_outcomes(rows)
 cases=[];traces=[];groups=defaultdict(list)
 for ix,reason in picked:
  fixture=fixtures[ix]; row=rows[ix]; seat=fixture['target_seat']+1
  # Preserve maps and accepted actions. Timing is inherently host-dependent,
  # so mismatched replays are identified and excluded from aggregate diagnoses.
  trace=trace_fixture(plan['policies'],dict(fixture,map_values=row['map_values']),watch=(seat,),late_start=75)
  c=case(trace,seat);c.update(index=ix,sample_reason=reason,replays_original=(row['scores']==trace['final_scores']),reference_scores=row['scores'],faults=trace['faults'])
  cases.append(c);traces.append(trace)
  if c['replays_original']:groups[c['target']+' '+reason].append(c)
 out={'sampling':('2 per map/seat/lineup, selected only by fixture metadata' if stage=='neural' else
                 'per target: four largest final deficits and two strict wins at lower quartile and median winning margin'),
      'case_count':len(cases),'exact_score_replays':sum(c['replays_original'] for c in cases),
      'cases':cases,'groups':{k:summary(v) for k,v in groups.items()}}
 (D/(stage+'_trace_findings.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
 with gzip.open(D/(stage+'_case_traces.json.gz'),'wt',encoding='utf-8') as stream:json.dump(traces,stream)
 print(stage, 'score-consistent',out['exact_score_replays'],'of',len(cases))
 for key,g in out['groups'].items():print(key,g['actions'],g['end_gap'],g['mean_gaps_by_turn'])
if __name__=='__main__':
 run(sys.argv[1])
