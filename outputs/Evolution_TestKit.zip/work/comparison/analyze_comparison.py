"""Paired, map-aware comparisons and direct same-game results."""
from collections import Counter
import itertools
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "evolution"))
from validate_evolution import paired_card
from batch import designated_summary


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def head_summary(rows):
    fields = {}
    for field in sorted({row["lineup"] for row in rows}):
        cases = [row for row in rows if row["lineup"] == field]
        names = cases[0]["bots"]
        comparisons = {}
        for first, second in itertools.combinations(sorted(names), 2):
            outcomes = Counter()
            margins = []
            for row in cases:
                i, j = row["bots"].index(first), row["bots"].index(second)
                margin = row["scores"][i] - row["scores"][j]
                outcomes["wins" if margin > 0 else "losses" if margin < 0 else "draws"] += 1
                margins.append(margin)
            comparisons[first + " vs " + second] = {
                **dict(outcomes), "games": len(cases), "mean_score_margin": statistics.mean(margins),
                "credit": (outcomes["wins"] + 0.5 * outcomes["draws"]) / len(cases)}
        fields[field] = {"games": len(cases), "opponents": sorted(names), "comparisons": comparisons}
    return fields


def main():
    rows = read("final_results.json")["records"]
    evolved = read("comparison_lock.json")["selected_evolved"]
    pairs = {}
    for candidate, reference in [(evolved, "user"), (evolved, "incumbent"),
                                  ("user", "incumbent"), ("user_corrected", "user"),
                                  ("user_recovery", "user")]:
        pairs[candidate + " vs " + reference] = paired_card(rows, candidate, reference)
    by_family = {}
    for family in sorted({row["family"] for row in rows}):
        by_family[family] = designated_summary([row for row in rows if row["family"] == family])
    data = {"summary": designated_summary(rows), "paired": pairs, "family": by_family,
            "head_to_head": head_summary(read("head_to_head_results.json")["records"])}
    (ROOT / "comparison_analysis.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    print(json.dumps({"summary": data["summary"], "delta_intervals": {
        name: card["random_map_block_delta_95pct"] for name, card in pairs.items()},
        "head_to_head": data["head_to_head"]}, indent=2))


if __name__ == "__main__":
    main()
