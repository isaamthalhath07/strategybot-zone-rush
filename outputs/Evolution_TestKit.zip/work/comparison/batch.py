"""Matched four-player comparisons with deadline and swallowed-error auditing."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import gzip
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent))
from arena import Game, NEIGHBORS, map_values

SNAPSHOT = ROOT / "user_snapshot_001"
sys.path.append(str(SNAPSHOT))
COMPILED = {}
WEIGHTS = {}


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def load_player(spec, seed):
    path = Path(spec["path"]).resolve()
    if str(path) not in COMPILED:
        COMPILED[str(path)] = compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    namespace = {"__name__": "comparison_policy", "__file__": str(path)}
    exec(COMPILED[str(path)], namespace)
    if spec.get("config_style") == "dict":
        namespace["CONFIG"] = dict(spec["config"])
    else:
        namespace.update(spec.get("config", {}))
    internal = []
    if spec.get("audit_internal"):
        for class_name in ("Agent", "NNAgent"):
            if class_name not in namespace:
                continue
            cls = namespace[class_name]
            original = cls.decide
            def audited(self, view, method=original):
                try:
                    return method(self, view)
                except Exception as error:
                    internal.append(repr(error))
                    raise
            cls.decide = audited
    if "zoo_name" in spec:
        player = namespace["ZOO_BY_NAME"][spec["zoo_name"]](seed=seed)
    elif "entry_class" in spec:
        kwargs = dict(spec.get("kwargs", {}))
        if "weights" in spec:
            file = str(Path(spec["weights"]).resolve())
            if file not in WEIGHTS:
                WEIGHTS[file] = read(file)
            kwargs["weights"] = WEIGHTS[file]
        player = namespace[spec["entry_class"]](seed=seed, **kwargs)
    elif "name" in spec:
        player = namespace["POLICIES"][spec["name"]]
    else:
        player = namespace["act"]
    return player, internal


def values_for(fixture):
    if "map_values" in fixture:
        return fixture["map_values"]
    if fixture["family"] == "user_slope":
        import engine
        return engine.make_map(seed=fixture["seed"])
    return map_values(fixture["seed"], fixture["family"])


def play(registry, fixture):
    players = [load_player(registry[name], fixture["seed"] * 7919 + seat)
               for seat, name in enumerate(fixture["bots"], 1)]
    game = Game(values=values_for(fixture), start_token=fixture["token"])
    maxima, totals = [0.0] * 4, [0.0] * 4
    errors = []
    while game.turn <= 80:
        actions = []
        for seat, (player, internal) in enumerate(players, 1):
            state = game.state(seat)
            if fixture.get("legal_style") == "bounds" and not game.frozen[seat - 1]:
                legal = list(NEIGHBORS[game.pos[seat - 1]]) + ["STAY"]
                if not game.cooldown[seat - 1]:
                    legal.append("SHIELD")
                state = state._replace(legal_actions=legal)
            start = time.perf_counter()
            try:
                action = player(state)
                duration = time.perf_counter() - start
                if action not in state.legal_actions:
                    raise ValueError(f"Illegal return {action!r}")
                if duration > (2 if game.turn == 1 else 0.2):
                    raise TimeoutError("Official action deadline exceeded")
            except Exception as error:
                duration = time.perf_counter() - start
                errors.append([game.turn, seat, repr(error)])
                action = "STAY"
            if internal:
                errors.extend([game.turn, seat, "Caught internally: " + message] for message in internal)
                internal.clear()
            maxima[seat - 1] = max(maxima[seat - 1], duration * 1000)
            totals[seat - 1] += duration * 1000
            actions.append(action)
        game.step(actions)
    scores = list(game.scores)
    pairwise = [sum((value > rival) + 0.5 * (value == rival)
                    for j, rival in enumerate(scores) if i != j) / 3
                for i, value in enumerate(scores)]
    strict = [int(value > max(rival for j, rival in enumerate(scores) if i != j))
              for i, value in enumerate(scores)]
    fraction = [float(value == max(scores)) / scores.count(max(scores)) for value in scores]
    return {**fixture, "scores": scores, "territory": [game.owner.count(seat) for seat in range(1, 5)],
            "map_values": game.values, "pairwise": pairwise, "strict_first": strict,
            "first_share": fraction, "latency_max_ms": maxima,
            "latency_mean_ms": [value / 80 for value in totals], "errors": errors,
            "frozen_progress": False}


def worker(job):
    registry, fixture, cache = job
    cache = Path(cache)
    if cache.exists():
        with gzip.open(cache, "rt", encoding="utf-8") as stream:
            return json.load(stream)
    row = play(registry, fixture)
    temporary = cache.with_suffix(".tmp")
    with gzip.open(temporary, "wt", encoding="utf-8") as stream:
        json.dump(row, stream)
    temporary.replace(cache)
    return row


def designated_summary(rows):
    result = {}
    for name in sorted({row["target"] for row in rows if "target" in row}):
        items = [row for row in rows if row.get("target") == name]
        result[name] = {"games": len(items), **{
            key: statistics.mean(row[key][row["target_seat"]] for row in items)
            for key in ("pairwise", "strict_first", "first_share", "latency_mean_ms")},
            "max_ms": max(row["latency_max_ms"][row["target_seat"]] for row in items),
            "errors": sum(error[1] == row["target_seat"] + 1 for row in items for error in row["errors"])}
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("plan", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    plan = read(args.plan)
    cache = args.output.parent / (args.output.stem + "_cache")
    cache.mkdir(exist_ok=True)
    started = time.perf_counter()
    rows = [None] * len(plan["experiments"])
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        pending = {}
        for index, fixture in enumerate(plan["experiments"]):
            registry = {name: plan["policies"][name] for name in set(fixture["bots"])}
            fingerprint = hashlib.sha256(json.dumps([registry, fixture], sort_keys=True).encode()).hexdigest()
            pending[executor.submit(worker, (registry, fixture, str(cache / (fingerprint + ".json.gz"))))] = index
        for complete, future in enumerate(as_completed(pending), 1):
            rows[pending[future]] = future.result()
            if complete % 100 == 0:
                progress = {"completed": complete, "games": len(rows),
                            "elapsed_seconds": time.perf_counter() - started}
                args.output.with_suffix(".progress.json").write_text(json.dumps(progress))
                print(f"{complete}/{len(rows)} games in {progress['elapsed_seconds']:.1f}s", flush=True)
    report = {"records": rows, "summary": designated_summary(rows),
              "elapsed_seconds": time.perf_counter() - started}
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
