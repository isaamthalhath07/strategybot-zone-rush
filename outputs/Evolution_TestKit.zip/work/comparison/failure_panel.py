"""Matched four-way diagnostic sample. These interpretable trajectories are separate from selection."""
from collections import Counter,defaultdict
from concurrent.futures import ProcessPoolExecutor
import gzip, json, statistics, sys
from pathlib import Path
from failure_analysis import trace_game
DIR=Path(__file__).resolve().parent
ROOT=DIR.parent
USER="user_submitted"
HERO="economic_8950867ccc9d"
NAMES=["incumbent",USER,HERO,"lure"]
def one(task):
 family,si,shift=task
 reg=json.loads((ROOT/"evolution/runs/league_001/state.json").read_text())["registry"]
 reg.update(json.loads((DIR/"trace_user_registry.json").read_text(encoding="utf-8-sig")))
 bots=NAMES[shift:]+NAMES[:shift]
 seed=800200+si
 token=1+(si+shift)%4
 res=trace_game(reg,bots,family,seed,token,watch=tuple(range(1,5)),late_start=77)
 return res
def summarize(recs):
 stats={}
 for n in NAMES:
  totals=Counter(); point=[]; rankings=[]
  for r in recs:
   i=r['bots'].index(n);scores=r['final_scores'];point.append(scores[i])
   rankings.append(sum(scores[i]>v for v in scores)/3.)
   for k,v in r['metrics'][i].items():totals[k]+=v
  stats[n]={"mean":statistics.mean(point),"pairwise":statistics.mean(rankings),"metrics":{k:round(v/len(recs),3) for k,v in totals.items()}}
 pairs={}
 for a,b in [(USER,'incumbent'),(HERO,USER),(HERO,'incumbent')]:
  out=defaultdict(list)
  for r in recs:
   ia=r['bots'].index(a);ib=r['bots'].index(b);ma,mb=r['metrics'][ia],r['metrics'][ib];sa,sb=r['final_scores'][ia],r['final_scores'][ib]
   row={"end":sa-sb,"income":ma.get('income_points',0)-mb.get('income_points',0),"raid":ma.get('raid_points',0)-mb.get('raid_points',0)}
   for m in r['milestones']:
      row['t'+str(m['turn'])] = m['scores'][ia]-m['scores'][ib]
   out['win' if sa>sb else 'tie' if sa==sb else 'loss'].append(row)
  pairs[a+' minus '+b]={k:{'n':len(rows),'means':{s:round(statistics.mean(x[s] for x in rows),2) for s in rows[0]}} for k,rows in out.items()}
 return {"stats":stats,"head_to_head":pairs,"games":len(recs),"faults":sum(len(r['faults']) for r in recs)}
if __name__=='__main__':
 tasks=[(fam,si,sh) for fam in ('balanced','patchy','edge') for si in range(4) for sh in range(4)]
 with ProcessPoolExecutor(max_workers=3) as pool:
  docs=list(pool.map(one,tasks,chunksize=2))
 summary=summarize(docs)
 (DIR/'diagnostic_summary.json').write_text(json.dumps(summary,indent=2))
 with gzip.open(DIR/'diagnostic_traces.json.gz','wt',encoding='utf-8') as f:json.dump(docs,f)
 print(json.dumps(summary['head_to_head']))
