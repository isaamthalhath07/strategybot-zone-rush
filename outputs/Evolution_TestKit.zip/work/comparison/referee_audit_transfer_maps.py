"""Inspect actual map contents before looking at any transfer-audit outcomes."""
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path

from batch import values_for
from referee_audit import HERE, WORK


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    sources=defaultdict(set)
    boards={}
    def add(rows,stage):
        for r in rows:
            if "family" not in r or "seed" not in r:
                continue
            vals=r.get("map_values")
            identity=(r["family"],r["seed"],tuple(vals) if vals else None)
            if identity not in boards:
                boards[identity]=sha256(bytes(values_for(r))).hexdigest()
            sources[boards[identity]].add(stage)
    for name in ("league_001","transfer_001"):
        for gen in read(WORK/"evolution/runs"/name/"state.json")["history"]:
            add(gen["fixtures"],name)
    for path in sorted(HERE.glob("*_plan.json")):
        if path.name!="transfer_audit_plan.json":
            add(read(path)["experiments"],path.stem)
    for name in ("screening","tuning","validation","architecture_selection","macro_selection","holdout",
                 "alternate_selection","alternate_validation","freeze_sensitivity","pre_clarification_plan"):
        if (WORK/(name+".json")).exists():
            add(read(WORK/(name+".json"))["experiments"],name)
    families=("balanced","patchy","edge","user_slope")
    add([{"family":f,"seed":s} for f in families for s in [91000,91001]],
        "transfer_confirm_predeclared")
    audit=[]
    for f in families:
        for s in range(95000,95004):
            h=sha256(bytes(values_for({"family":f,"seed":s}))).hexdigest()
            audit.append({"family":f,"seed":s,"hash":h,"earlier_stages":sorted(sources.get(h,[]))})
    overlaps=[r for r in audit if r["earlier_stages"]]
    result={"planned_family_seed_pairs":len(audit),"unique_actual_boards":len({r["hash"] for r in audit}),
            "earlier_unique_boards_checked":len(sources),"earlier_stage_names":sorted(set.union(*sources.values())),
            "overlaps":overlaps,"boards":audit}
    (HERE/"transfer_audit_map_check.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k!="boards"},indent=2))


if __name__=="__main__":
    main()
