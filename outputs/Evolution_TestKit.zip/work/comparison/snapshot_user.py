from pathlib import Path
import hashlib,json,shutil
source=Path(r'C:/Users/LEGION/stratergybot'); target=Path('work/comparison/user_snapshot_001'); target.mkdir(parents=True,exist_ok=True)
manifest={}
for p in source.iterdir():
 if p.is_file() and (p.suffix in ['.py','.json'] or p.name=='README.md'):
  destination=target/p.name
  if not destination.exists(): shutil.copyfile(p,destination)
  manifest[p.name]={'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'bytes':destination.stat().st_size}
Path('work/comparison/user_snapshot_manifest.json').write_text(json.dumps({'submission':'bot.py','files':manifest},indent=2))
print('Snapshot files',len(manifest)); print('Submission',manifest['bot.py'])
