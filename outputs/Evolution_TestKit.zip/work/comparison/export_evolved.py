import hashlib
import json
from pathlib import Path
import pprint
import re

ROOT = Path(__file__).resolve().parent
run = ROOT.parent / "evolution" / "runs" / "league_001"
registry = json.loads((run / "state.json").read_text())["registry"]
summary = json.loads((ROOT / "confirm_results.json").read_text())["summary"]
candidate = max((name for name in summary if name not in ("user", "incumbent")),
                key=lambda name: (summary[name]["pairwise"], summary[name]["strict_first"]))
spec = registry[candidate]
source = Path(spec["path"]).read_text(encoding="utf-8-sig")
config = pprint.pformat(spec["config"], sort_dicts=True, width=90)
source, count = re.subn(r"^CONFIG = .*?$", lambda match: "CONFIG = " + config,
                        source, count=1, flags=re.M)
assert count == 1
output = ROOT.parent.parent / "outputs" / "bot_evolved.py"
output.write_text(source, encoding="utf-8")
locked = {"candidate": candidate, "config": spec["config"], "selection": summary[candidate],
          "sha256": hashlib.sha256(output.read_bytes()).hexdigest(), "filename": output.name}
(ROOT / "evolved_export.json").write_text(json.dumps(locked, indent=2))
print(json.dumps(locked, indent=2))
