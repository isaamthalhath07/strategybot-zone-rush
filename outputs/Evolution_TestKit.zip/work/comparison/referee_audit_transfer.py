"""Check the exact locked transfer output, without modifying the source under test."""
import ast
import hashlib
import json
from pathlib import Path
import random
import sys
from time import perf_counter_ns

from referee_audit_patched import accept as route_faults
from referee_audit import HERE, WORK
sys.path.insert(0,str(WORK/"evolution"))
import validate_evolution as validator
from arena import Game, HOMES, NEIGHBORS
from bench import load_policy
from validate_submission import public_input, snapshot


def normalised(source):
    tree=ast.parse(source)
    patches=0
    for n in tree.body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=="CONFIG":
            n.value=ast.Constant(None)
            patches+=1
    assert patches==1
    return ast.dump(tree)


def occupied_direction_check(path,games=8):
    mod=validator.module_at(path)
    faults=[]; moves=0; frozen=0; exposed=0; checks=0; times=[]
    if hasattr(mod,"Agent"):
        original=mod.Agent.decide
        def guarded(this,state):
            try:
                a=original(this,state)
                if a not in state.legal_actions:
                    faults.append("internally illegal")
                return a
            except Exception as exc:
                faults.append(repr(exc));raise
        mod.Agent.decide=guarded
    for fixture in range(games):
        g=Game(16300+fixture,("balanced","edge","patchy","example")[fixture%4],start_token=fixture%4+1)
        me=fixture%4
        other=iter(load_policy("challengers.py",n) for n in ("lure","fortress","adaptive"))
        ps=[None if i==me else next(other) for i in range(4)]
        rng=random.Random(627182+fixture)
        while g.turn<=80:
            actions=[]
            for i in range(4):
                state=public_input(g.state(i+1))
                p=g.pos[i]
                if not g.frozen[i]:
                    # Match the external engine's documented in-bounds list and ordering.
                    state.legal_actions=["STAY"]+[a for a in ("NORTH","SOUTH","WEST","EAST") if a in NEIGHBORS[p]]
                    if not g.cooldown[i]:
                        state.legal_actions.append("SHIELD")
                if i!=me:
                    actions.append(ps[i](state));continue
                before=snapshot(state)
                start=perf_counter_ns();actual=mod.act(state);duration=(perf_counter_ns()-start)/1e6
                times.append(duration)
                assert actual in state.legal_actions and snapshot(state)==before
                assert duration<(2000 if g.turn==1 else 200)
                if hasattr(mod,"_history"):
                    m=mod._history[i+1]
                    observed=(m["turn"],m["scores"][1:],m["positions"][1:])
                    progress=m["progress"]
                else:
                    tr=mod._AGENTS[i+1].tr
                    observed=(tr.turn,tr.score,tr.pos)
                    progress=tr.prog[i]
                assert observed==(g.turn,g.scores,g.pos)
                actionable=(g.owner[p]==i+1 and not g.upgraded[p]) or (g.owner[p]!=i+1 and p not in HOMES)
                if actionable:
                    checks+=1
                    assert progress==g.progress[i],(fixture,g.turn,p,progress,g.progress[i])
                blocked=[a for a in state.legal_actions if NEIGHBORS[p].get(a) in g.pos]
                if blocked:
                    exposed+=1
                if blocked and rng.random()<.48:
                    # The chosen physical intent targets a presently occupied cell. The referee
                    # executes a stay even if the initial occupant is also about to move.
                    actual=rng.choice(blocked);moves+=1
                frozen+=int(bool(g.frozen[i]))
                actions.append(actual)
            g.step(actions)
    assert moves>0 and not faults
    return {"games":games,"callbacks":len(times),"calls_offering_occupied_moves":exposed,
            "injected_blocked_directions":moves,"frozen_callbacks":frozen,
            "actionable_progress_checks":checks,"turn_score_position_vectors_checked":len(times),
            "internal_faults":len(faults),"illegal_returns":0,"deadline_misses":0,"mutations":0,
            "max_ms":max(times)}


if __name__=="__main__":
    path=WORK.parent/"outputs/bot_transfer_candidate.py"
    lock=json.loads((HERE/"transfer_selection_lock.json").read_text(encoding="utf-8"))
    state=json.loads((WORK/"evolution/runs/transfer_001/state.json").read_text(encoding="utf-8"))
    name=lock["selected_profile"]; spec=state["registry"][name]
    source=path.read_bytes()
    assert hashlib.sha256(source).hexdigest()==lock["source_sha256"]
    assert normalised(source)==normalised(Path(spec["path"]).read_bytes())
    mod=validator.module_at(path)
    assert mod.CONFIG==lock["genome"]==spec["config"]
    r={"profile":name,"family":spec["family"],"locked_sha256":lock["source_sha256"],
       "only_top_level_CONFIG_changed_from_family":True,"registry_and_exported_genome_match":True,
       "source":validator.inspect_candidate(path),"runtime":validator.audit_runtime(path,8)}
    if spec["family"]=="user_route":
        r["recovery"]=route_faults(path,n=16)
        assert not r["recovery"]["mismatches"],r["recovery"]["examples"]
    else:
        r["recovery"]=validator.audit_recovery(path)
    r["occupied_direction_legality"]=occupied_direction_check(path)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==r["locked_sha256"]
    r["status"]="pass"
    target=HERE/"transfer_candidate_acceptance.json"
    target.write_text(json.dumps(r,indent=2),encoding="utf-8")
    print(json.dumps(r,indent=2))
