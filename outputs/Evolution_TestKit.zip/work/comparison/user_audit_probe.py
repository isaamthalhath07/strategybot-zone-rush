"""Read-only audit of the external strategy. All output stays beside this script."""
import copy
from collections import Counter
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from arena import Game
from bench import load_policy

USER=Path(r'C:/Users/LEGION/stratergybot/bot.py')
OURS=HERE.parent.parent/'outputs'/'bot.py'


def enter_last_turn(home_visitor):
    a=load_policy(USER)
    g=Game(values=[1]*64)
    g.turn=79
    g.pos=[9,1 if home_visitor else 7,63,56]
    if home_visitor:
        g.owner[10]=3
    g.values[10]=3
    a(g.state(1))
    agent=a.__globals__['_AGENTS'][1]
    agent.tr.turn=79
    g.step(['EAST','WEST' if home_visitor else 'STAY','STAY','STAY'])
    chosen=a(g.state(1))
    scores={}
    for move in set((chosen,'STAY')):
        twin=copy.deepcopy(g)
        twin.step([move,'STAY','STAY','STAY'])
        scores[move]=twin.scores
    return {'action':chosen,'scores_for_last_actions':scores}


def memory_fixture():
    a=load_policy(USER);g=Game(values=[1]*64)
    for _ in range(5):
        a(g.state(1))
        g.step(['STAY']*4)
    a(g.state(1));m=a.__globals__['_AGENTS'][1].tr
    return {'true_turn':g.turn,'inferred_turn':m.turn,'true_scores':g.scores,'inferred_scores':m.score}


def rejected_shield_fixture():
    a=load_policy(USER);g=Game(values=[1]*64)
    g.pos=[0,9,36,37]
    g.owner[9],g.owner[37]=1,3
    a(g.state(1));agent=a.__globals__['_AGENTS'][1]
    # The sensor observes a request for own shield that the server substitutes
    # with STAY, simultaneous with another seat successfully shielding a raider.
    agent.last_action='SHIELD'
    g.step(['bad','STAY','SHIELD','STAY'])
    a(g.state(1))
    return {'true_cooldown_seat3':g.cooldown[2],'inferred_cooldown_seat3':agent.tr.cd[2],
            'true_frozen_seat4':g.frozen[3],'inferred_frozen_seat4':agent.tr.frozen[3]}


def field_probe():
    stats=Counter()
    for family in ['balanced','edge','flat','example','patchy']:
        for seat in range(4):
            g=Game(seed=327,family=family,start_token=1+(seat+2)%4)
            external=load_policy(USER)
            policies=[load_policy(OURS),load_policy('challengers.py','fortress'),load_policy('challengers.py','lure')]
            policies.insert(seat,external)
            ours_seat=1 if seat==0 else 0
            errors=[]
            original=external.__globals__['Agent'].decide
            def inspect_decide(self,obs):
                try:
                    return original(self,obs)
                except Exception as error:
                    errors.append(str(error))
                    raise
            external.__globals__['Agent'].decide=inspect_decide
            while g.turn<=80:
                before_owner=g.owner[:]; before_level=g.upgraded[:]
                actions=[pol(g.state(i+1)) for i,pol in enumerate(policies)]
                agent=external.__globals__['_AGENTS'][seat+1]
                eligible=[k for k,p in enumerate(g.pos) if k!=seat and before_owner[p]==seat+1 and not g.frozen[k]]
                opportunity=(len(eligible)==1 and not before_level[g.pos[eligible[0]]]
                             and g.pos[eligible[0]] not in (0,7,56,63)
                             and 'SHIELD' in g.state(seat+1).legal_actions and 81-agent.tr.turn>=11)
                target=g.pos[eligible[0]] if opportunity else None
                if opportunity:
                    stats['isolated_l1_opportunities']+=1
                    stats['shields_on_isolated_l1']+=actions[seat]=='SHIELD'
                g.step(actions)
                if opportunity and g.owner[target]!=seat+1:
                    stats['isolated_l1_lost']+=1
                    stats['isolated_l1_raid_points_paid']+=8*g.values[target]
                for p,(old,new) in enumerate(zip(before_owner,g.owner)):
                    if old and old!=new:
                        cash=8*g.values[p]*(1+before_level[p])
                        if old==seat+1:stats['v6_raid_points_paid']+=cash
                        if old==ours_seat+1:stats['ours_raid_points_paid']+=cash
                        if new==seat+1:stats['v6_raid_income']+=cash
                        if new==ours_seat+1:stats['ours_raid_income']+=cash
                for k,tag in [(seat,'v6'),(ours_seat,'ours')]:
                    stats[tag+'_shields']+=actions[k]=='SHIELD'
            stats['games']+=1
            stats['masked_internal_exceptions']+=len(errors)
            stats['v6_score']+=g.scores[seat]
            stats['ours_score']+=g.scores[ours_seat]
            stats['v6_h2h']+=float(g.scores[seat]>g.scores[ours_seat])+.5*(g.scores[seat]==g.scores[ours_seat])
    return dict(stats)


if __name__=='__main__':
    result={'neutral_final_turn':enter_last_turn(False),'home_and_raid_final_turn':enter_last_turn(True),
            'all_stay_at_home':memory_fixture(),'simultaneous_substitution':rejected_shield_fixture(),
            'field_probe':field_probe()}
    (HERE/'user_probe_results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result))
