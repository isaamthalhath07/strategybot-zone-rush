"""Check particular repairs against the three immutable submission variants."""
from pathlib import Path
import copy
import hashlib
import json
import random
import sys

sys.dont_write_bytecode = True
DIR = Path(__file__).resolve().parent
sys.path.insert(0,str(DIR))
import user_audit_probe as probe
from arena import Game
from bench import load_policy


def check_transitions(source):
    fn=load_policy(source)
    # Four legal opening departures can all reverse with no capture.
    g=Game(values=[1]*64)
    for moves in [('EAST','WEST','WEST','EAST'),('WEST','EAST','EAST','WEST')]:
        fn(g.state(1));g.step(moves)
    fn(g.state(1));m=fn.__globals__['_AGENTS'][1].tr
    opening=(g.turn,m.turn,g.scores[:],m.score[:])
    # Later departure from that board does produce irreversible ownership.
    g.step(['EAST','WEST','WEST','EAST']);fn(g.state(1));g.step(['STAY']*4);fn(g.state(1))
    fresh=Game(values=[1]*64);fn(fresh.state(1));m=fn.__globals__['_AGENTS'][1].tr
    return {'opening_return':[opening[0],opening[1],opening[2],opening[3]],
            'new_game':[m.turn,m.score]}


def check_fuzz(source):
    checks=0;errors=0;progress_errors=0;elapsed_errors=0;score_errors=0;own_shields=0
    for seed in range(8):
        g=Game(seed=seed,family=['flat','edge','balanced','patchy'][seed%4],start_token=seed%4+1)
        me=1+seed%4
        fn=load_policy(source);rr=random.Random(500+seed)
        policies=[load_policy('challengers.py',p) for p in ('fortress','raider','lure')]
        policies.insert(me-1,fn)
        original=fn.__globals__['Agent'].decide
        def strict(self,s):
            nonlocal errors
            try:
                return original(self,s)
            except Exception:
                errors+=1
                raise
        fn.__globals__['Agent'].decide=strict
        while g.turn<=80:
            acts=[p(g.state(s)) for s,p in enumerate(policies,1)]
            m=fn.__globals__['_AGENTS'][me].tr;k=me-1;spot=g.pos[k]
            elapsed_errors+=m.turn!=g.turn
            score_errors+=m.score!=g.scores
            if (g.owner[spot]==me and not g.upgraded[spot]) or (g.owner[spot]!=me and spot not in (0,7,56,63)):
                checks+=1;progress_errors+=m.prog[k]!=g.progress[k]
            for i,act in enumerate(acts):
                if act!='STAY' and rr.random() < (.65 if act=='SHIELD' else .18):
                    if i==k and act=='SHIELD':own_shields+=1
                    acts[i]='invalid'
            g.step(acts)
    return {'games':8,'calls':640,'own_shields_replaced':own_shields,'progress_checks':checks,
            'wrong_progress':progress_errors,'wrong_turn':elapsed_errors,'wrong_score':score_errors,
            'internal_exceptions':errors}


def check():
    report={}
    for variant in ['user_snapshot_001/bot.py','user_recovery.py','user_corrected.py']:
        source=DIR/variant;probe.USER=source
        report[variant]=dict(sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
            last_neutral=probe.enter_last_turn(False),home_visitor=probe.enter_last_turn(True),
            home_stays=probe.memory_fixture(),fallback=probe.rejected_shield_fixture(),
            resets=check_transitions(source),fuzz=check_fuzz(source))
        row=report[variant]
        if variant!='user_snapshot_001/bot.py':
            assert row['home_stays']['true_scores']==row['home_stays']['inferred_scores']
            assert row['home_stays']['true_turn']==row['home_stays']['inferred_turn']
            assert row['fallback']['true_cooldown_seat3']==row['fallback']['inferred_cooldown_seat3']==4
            assert row['resets']['opening_return']==[3,3,[2]*4,[2]*4]
            assert row['resets']['new_game']==[1,[0]*4]
        if variant=='user_corrected.py':
            assert row['last_neutral']['action']=='STAY' and row['home_visitor']['action']=='STAY'
    (DIR/'user_fix_validation.json').write_text(json.dumps(report,indent=2))
    for name,row in report.items():print(name,row['last_neutral']['action'],row['home_visitor']['action'],row['fuzz'])


if __name__=='__main__':
    check()
