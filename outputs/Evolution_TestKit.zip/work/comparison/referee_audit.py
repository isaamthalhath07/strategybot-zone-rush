"""Differential check of two independent Zone Rush referees plus targeted entrant defects.

Invoke with --external-dir pointing at the previously snapshotted stratergybot project.
Code is imported without writing bytecode to the external project.
"""
import argparse
import ast
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import random
import statistics
import sys
import time

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
WORK=HERE if (HERE/"arena.py").is_file() else HERE.parent
sys.path.insert(0,str(WORK))
from arena import Game as LocalGame, map_values, NEIGHBORS
from bench import load_policy
from validate_submission import public_input, snapshot


def module_at(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def compare_games(eng,n):
    matched=0; ties=0; tie_example=None; offered_blocked=0
    for seed in range(n):
        rng=random.Random(seed+90731)
        family=("balanced","patchy","edge","flat","example")[seed%5]
        values=map_values(seed,family)
        token=seed%4+1
        ours=LocalGame(start_token=token,values=values)
        other=eng.Game(base=values,start_token=token)
        for t in range(1,81):
            for i in range(4):
                extra=set(other.legal(i))-set(ours.legal(i))
                assert all(NEIGHBORS[ours.pos[i]].get(a) in ours.pos for a in extra)
                assert not set(ours.legal(i))-set(other.legal(i))
                offered_blocked+=len(extra)
            # Include legal actions, out-of-bounds, occupied, cooldown, and invalid returns.
            choices=["NORTH","EAST","SOUTH","WEST","STAY","STAY","SHIELD","invalid"]
            actions=rng.choices(choices,k=4)
            ours.step(actions); other.step(actions)
            assert (ours.owner,ours.upgraded,ours.pos,ours.frozen,ours.cooldown,ours.progress,
                    ours.scores,ours.token,ours.turn)==(
                    other.owner,other.upg,other.pos,other.frozen,other.cd,other.prog,
                    other.score,other.token,other.turn),(seed,t,actions)
            matched+=1
        places=other.places()
        counts=[other.cells_owned(i) for i in range(4)]
        for i in range(4):
            for j in range(i):
                if other.score[i]==other.score[j] and counts[i]!=counts[j]:
                    ties+=1
                    if tie_example is None:
                        tie_example={"seed":seed,"family":family,"token":token,"scores":other.score,
                                     "territory":counts,"external_places":places,
                                     "score_tied_seats":[i+1,j+1]}
    return {"maps":n,"matched_turns":matched,"state_keys":["owner","level","position","freeze",
            "shield cooldown","progress","scores","token","turn"],
            "additional_occupied_directions_offered":offered_blocked,
            "round1_equal_score_pairs_broken_by_territory":ties,
            "first_reachable_tie_example":tie_example}


def tracker_witnesses(bot):
    g=LocalGame(family="example")
    bot.act(g.state(1))
    g.step(["STAY"]*4)
    action=bot.act(g.state(1))
    tracker=bot._AGENTS[1].tr
    first={"turn":g.turn,"tracker_turn":tracker.turn,"scores":g.scores[:],
           "tracker_scores":tracker.score[:],"own_progress":g.progress[0],
           "tracker_own_progress":tracker.prog[0],"action_after":action}
    for _ in range(2):
        g.step(["STAY"]*4)
        bot.act(g.state(1))
    first["after_three_stays"]={"turn":g.turn,"tracker_turn":tracker.turn,
                                "home_upgraded":bool(g.upgraded[g.pos[0]])}
    assert first["tracker_turn"]==1 and first["turn"]==2
    # Use the entrant's genuine choice of SHIELD if it selects that tactic on this board.
    # Seat 2's shield backfires after seat 1's submitted SHIELD is rejected to a STAY.
    for count in (1,2,3):
        bot._AGENTS.clear()
        alt=LocalGame(values=[1]*64); alt.pos=[27,28,30,45]; alt.owner[27]=1
        for i in range(1,count+1):
            p=alt.pos[i]; alt.owner[p]=1; alt.values[p]=3
        own_request=bot.act(alt.state(1))
        if own_request!="SHIELD":
            continue
        # All extra intruders leave; only seat 2 stays by shielding and backfires.
        acts=["invalid","SHIELD","NORTH","SOUTH"]
        alt.step(acts)
        own_still_ready="SHIELD" in alt.state(1).legal_actions
        bot.act(alt.state(1))
        tr=bot._AGENTS[1].tr
        witness={"initial_positions":[27,28,30,45],"source_requested":own_request,
                 "executed_inputs":acts,"initial_intruders":count,"still_shield_legal":own_still_ready,
                 "scores":alt.scores[:],"tracker_scores":tr.score[:],"own_progress":alt.progress[0],
                 "tracker_own_progress":tr.prog[0],"own_cooldown":alt.cooldown[0],
                 "tracker_own_cooldown":tr.cd[0],"rival_cooldown":alt.cooldown[1],
                 "tracker_rival_cooldown":tr.cd[1]}
        if witness["tracker_own_cooldown"]!=witness["own_cooldown"]:
            return {"reset":first,"misattributed_rejected_shield":witness}
    return {"reset":first,"misattributed_rejected_shield":None}


def slow_policy_witness(eng):
    # Only the second turn sleeps. A correct 200 ms fallback STAY at cell 1 would take it.
    turns=[0]
    def slow(view):
        turns[0]+=1
        if turns[0]==2:
            time.sleep(.23)
        return "EAST"
    game=eng.play([slow]+[lambda state:"STAY"]*3,max_turns=2)
    assert game.pos[0]==2 and game.owner[1]==0
    return {"late_turn":2,"slept_ms":230,"external_end_position":game.pos[0],
            "external_cell1_owner":game.owner[1],"deadline_enforced_end_position":1,
            "deadline_enforced_cell1_owner":1}


def external_callback_check(bot,source):
    """Instrument the internal decide path so the submission's fallback cannot hide exceptions."""
    errors=[]; illegal=[]; mutated=[]; durations=[]; late=[]; short_internal=[]
    native=bot.Agent.decide
    def strict(self,state):
        try:
            action=native(self,state)
            if action not in state.legal_actions:
                short_internal.append(repr(action))
            return action
        except Exception as error:
            errors.append(repr(error)); raise
    bot.Agent.decide=strict
    bot._AGENTS.clear()
    try:
        for fixture in range(8):
            me=fixture%4+1
            family=("balanced","patchy","edge","flat")[fixture%4]
            g=LocalGame(7088+fixture,family,1+(fixture//2)%4)
            other=iter(load_policy("challengers.py",n) for n in ("lure","fortress","adaptive"))
            policies=[None if seat==me else next(other) for seat in range(1,5)]
            while g.turn<=80:
                state=public_input(g.state(me)); old=snapshot(state)
                t=time.perf_counter(); a=bot.act(state); duration=(time.perf_counter()-t)*1000
                durations.append(duration)
                if a not in state.legal_actions: illegal.append([fixture,g.turn,a]); a="STAY"
                if duration>(2000 if g.turn==1 else 200): late.append([fixture,g.turn,duration]); a="STAY"
                if old!=snapshot(state): mutated.append([fixture,g.turn])
                acts=[a if s==me else policies[s-1](g.state(s)) for s in range(1,5)]
                g.step(acts)
    finally:
        bot.Agent.decide=native
    tree=ast.parse(source.read_bytes())
    imports=sorted({n.name for node in ast.walk(tree) if isinstance(node,ast.Import) for n in node.names}
                   | {node.module for node in ast.walk(tree) if isinstance(node,ast.ImportFrom)})
    return {"public_callbacks":len(durations),"imported_modules":imports,
            "mean_ms":statistics.mean(durations),"p99_ms":sorted(durations)[int(.99*len(durations))-1],
            "max_ms":max(durations),"over_deadline":late,"illegal":illegal,"input_mutations":mutated,
            "internal_exceptions":errors,"internally_replaced_illegal":short_internal}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--external-dir",required=True,type=Path)
    parser.add_argument("--games",type=int,default=500)
    parser.add_argument("--output",type=Path)
    args=parser.parse_args()
    ext=args.external_dir.resolve()
    engine=module_at("external_engine",ext/"engine.py")
    bot=module_at("external_bot",ext/"bot.py")
    report={"source_sha256":{n:sha256((ext/n).read_bytes()).hexdigest() for n in ("engine.py","arena.py","bot.py")},
            "referee":compare_games(engine,args.games),"tracker":tracker_witnesses(bot),
            "timeout":slow_policy_witness(engine),"external_bot_sample":external_callback_check(bot,ext/"bot.py")}
    if args.output:
        args.output.write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
