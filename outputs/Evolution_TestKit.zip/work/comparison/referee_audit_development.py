"""Verify a frozen development export against ship.build and independently test its public contract."""
import ast
from hashlib import sha256
import json
from pathlib import Path
import sys
import tempfile

from referee_audit import HERE, WORK, module_at
from referee_audit_patched import accept as route_faults
from user_fix_validation import check_transitions
import user_audit_probe as probe
sys.path.insert(0,str(WORK/"evolution"))
import validate_evolution as validator


def code_check(path,directory):
    tree=ast.parse(path.read_bytes())
    if isinstance(tree.body[0],ast.Expr) and isinstance(tree.body[0].value,ast.Constant):
        tree.body.pop(0)
    for node in tree.body:
        if isinstance(node,ast.Assign) and any(isinstance(v,ast.Name) and v.id=="PARAMS" for v in node.targets):
            params=ast.literal_eval(node.value)
            node.value=ast.Constant(None)
            break
    else:
        raise ValueError("Missing literal PARAMS")
    return ast.dump(tree),params


def main():
    folder=HERE/"user_snapshot_002"; candidate=HERE/"user_development_002.py"
    sig=sha256(candidate.read_bytes()).hexdigest()
    assert sig=="6abf403ab207a9b208c8e5a00d7c64b2318c2ab59d4c7a6e54a4ee976130968c"
    ship=module_at("frozen_ship",folder/"ship.py")
    sys.modules["mybot"]=module_at("mybot",folder/"mybot.py")
    with tempfile.TemporaryDirectory(dir=HERE) as tmp:
        assert Path(tmp).resolve().is_relative_to(HERE)
        rebuilt=Path(tmp)/"bot.py"
        ship.build(str(folder/"mybot.py"),str(folder/"best_params.json"),str(rebuilt))
        delivered_code,delivered_params=code_check(candidate,folder)
        rebuilt_code,rebuilt_params=code_check(rebuilt,folder)
        assert delivered_code==rebuilt_code and delivered_params==rebuilt_params
        result={"locked_sha256":sig,"ship_build_sha256":sha256(rebuilt.read_bytes()).hexdigest(),
                "build_semantics":{"equal_executable_AST_except_PARAMS":True,"PARAMS_equal":True,
                                   "parameter_keys":len(delivered_params),
                                   "same_file_bytes":rebuilt.read_bytes()==candidate.read_bytes()}}
    result["source"]=validator.inspect_candidate(candidate)
    result["public_runtime"]=validator.audit_runtime(candidate,8)
    result["fault_injection"]=route_faults(candidate,12)
    probe.USER=candidate
    result["targeted_recovery"]={"reversible_opening_and_restart":check_transitions(candidate),
                                 "all_home_stays":probe.memory_fixture(),"rejected_shield":probe.rejected_shield_fixture()}
    rr=result["targeted_recovery"]
    raw=rr["reversible_opening_and_restart"]["opening_return"]; home=rr["all_home_stays"]; shield=rr["rejected_shield"]
    bad=bool(result["fault_injection"]["mismatches"] or raw[0]!=raw[1] or raw[2]!=raw[3]
             or home["true_scores"]!=home["inferred_scores"] or home["true_turn"]!=home["inferred_turn"]
             or shield["true_cooldown_seat3"]!=shield["inferred_cooldown_seat3"])
    result["public_contract_status"]="pass"
    result["recovery_status"]="fail" if bad else "pass"
    assert sha256(candidate.read_bytes()).hexdigest()==sig
    (HERE/"development_acceptance.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result,indent=2))


if __name__=="__main__":
    main()
