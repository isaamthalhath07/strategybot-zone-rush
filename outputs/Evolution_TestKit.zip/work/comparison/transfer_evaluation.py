"""Select the second league's contenders, then run a frozen matched audit."""
import argparse
import hashlib
import json
from pathlib import Path
import pprint
import re
import subprocess
import sys
import time

from prepare_panels import panel, save

ROOT = Path(__file__).resolve().parent
RUN = ROOT.parent / "evolution" / "runs" / "transfer_001"
OUTPUT = ROOT.parent.parent / "outputs"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def run_batch(stage, policies, fixtures, workers):
    plan = ROOT / (stage + "_plan.json")
    result = ROOT / (stage + "_results.json")
    save(plan, policies, fixtures)
    subprocess.run([sys.executable, "-B", str(ROOT / "batch.py"), str(plan), str(result),
                    "--workers", str(workers)], check=True)
    return read(result)


def ranking(data):
    ranked = []
    for name, stats in data["summary"].items():
        subsets = [[row for row in data["records"] if row["target"] == name and row["lineup"] == i]
                   for i in range(3)]
        tail = min(sum(row["pairwise"][row["target_seat"]] for row in group) / len(group)
                   for group in subsets)
        fitness = 0.78 * stats["pairwise"] + 0.2 * tail + 0.02 * stats["strict_first"]
        ranked.append((fitness, name))
    return sorted(ranked, reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    started = time.perf_counter()
    while read(RUN / "progress.json")["phase"] != "evolution complete":
        if time.perf_counter() - started > 2400:
            raise TimeoutError("Training has not completed. Inspect its process and progress before restarting.")
        time.sleep(5)
    state = read(RUN / "state.json")
    base = read(ROOT / "final_plan.json")["policies"]
    policies = dict(base)
    for name, spec in state["registry"].items():
        if "family" in spec:
            policies[name] = dict(spec)
            if spec["family"] == "user_route":
                policies[name]["audit_internal"] = True
    policies["evolved_reference"] = {"path": str(OUTPUT / "bot_evolved.py")}
    lineups = [["evolved_reference"] * 3, ["user", "user_corrected", "macro"],
               ["economic_11c655468adf", "action_beam_1ea33eef3561", "reserved_adversary"]]
    targets = list(dict.fromkeys(state["archive"] + [row["leader"] for row in state["history"]]))
    targets += ["evolved_reference", "user"]
    screen = run_batch("transfer_screen", policies,
                       panel(targets, lineups, 90000, 2, 1, "transfer selection screen"), args.workers)
    promoted = [name for score, name in ranking(screen) if name not in ("evolved_reference", "user")][:3]
    confirm = run_batch("transfer_confirm", policies,
                        panel([*promoted, "evolved_reference", "user"], lineups, 91000, 2, 2,
                              "transfer selection confirmation"), args.workers)
    candidate = next(name for score, name in ranking(confirm) if name not in ("evolved_reference", "user"))
    specification = policies[candidate]
    source = Path(specification["path"]).read_text(encoding="utf-8-sig")
    genome = pprint.pformat(specification["config"], width=90, sort_dicts=True)
    source, replacements = re.subn(r"^CONFIG = .*?$", lambda match: "CONFIG = " + genome,
                                   source, count=1, flags=re.M)
    assert replacements == 1
    artifact = OUTPUT / "bot_transfer_candidate.py"
    artifact.write_text(source, encoding="utf-8")
    policies["transfer_candidate"] = {"path": str(artifact), "audit_internal": True}
    response = state["response_ids"][-1]
    user_route = next(row["id"] for row in state["history"][-1]["ranked"]
                      if state["registry"][row["id"]].get("family") == "user_route")
    final_lineups = lineups + [[response, user_route, "lure"]]
    lock = {"selected_profile": candidate, "source_sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
            "genome": specification["config"], "selection": confirm["summary"][candidate],
            "promotion_rule": "No faults, positive lower 95% map-block pairwise delta versus evolved reference, and no decline in mean strict-first rate",
            "targets": ["transfer_candidate", "evolved_reference", "user"]}
    (ROOT / "transfer_selection_lock.json").write_text(json.dumps(lock, indent=2), encoding="utf-8")
    final = run_batch("transfer_audit", policies,
                      panel(lock["targets"], final_lineups, 95000, 4, 4, "transfer frozen audit"), args.workers)
    print(json.dumps(final["summary"], indent=2), flush=True)


if __name__ == "__main__":
    main()
