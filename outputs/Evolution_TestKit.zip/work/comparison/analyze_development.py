"""Compare the second frozen development snapshot with the completed audit."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "evolution"))
from validate_evolution import paired_card


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def main():
    latest = read("development_results.json")
    audit = read("transfer_audit_results.json")
    selection = read("transfer_analysis.json")
    acceptance = read("development_acceptance.json")
    rows = audit["records"] + latest["records"]
    pair = {name: paired_card(rows, "user_development", name)
            for name in ("user", "evolved_reference", "transfer_candidate")}
    stats = latest["summary"]["user_development"]
    against_best = pair[selection["recommended"]]
    lo, hi = against_best["random_map_block_delta_95pct"]["pairwise"]
    delta = against_best["all_fixtures"]["pairwise"]["difference"]
    pct = lambda v: f"{v*100:.2f}%"
    report = f'''**The development files in your other project changed during this work, so a second snapshot was tested too.** Its root bot.py remained the exact v6 submission used above. Seven of the 54 earlier snapshotted files had changed and additional development files had appeared. Snapshot 002 freezes 68 source, settings and README files. The current mybot.py was exported with its defaults merged with best_params.json, matching the current builder's fifty parameter values and executable source structure. The original builder was never run in your project and your submission was never overwritten. The new self-contained experimental export is identified by SHA-256 6abf403ab207a9b208c8e5a00d7c64b2318c2ab59d4c7a6e54a4ee976130968c. This tests the current development code with the available best parameters, rather than an unfinished tuning run's future output.

That updated build played the same 1,024 fixtures as the second audit. It earned {pct(stats['pairwise'])} pairwise credit and {pct(stats['strict_first'])} outright first, with {stats['errors']} recorded execution faults. Its paired difference from the recommended economic policy was {delta*100:+.2f} points, with a 95% whole-board interval of {lo*100:+.2f} to {hi*100:+.2f} points. Full paired comparisons against both economic finalists and your original submission are saved in development_analysis.json. Machine load and the route planner's wall-clock throttle can affect exact replay choices, so its measured action times are not pure algorithmic complexity comparisons.

The updated build passed the public callback, standard-library, input-purity, timing and internally suppressed exception checks. It still failed the independently reproduced recovery cases: an opening return or repeated all-home stays reset its clock and scores, and a rejected shield could be attributed to the wrong player. In 960 separate injected-fallback callbacks, its turn and score vectors were wrong 790 times, with 19 actionable own-upgrade-progress and eight active own-cooldown mismatches. These are correlated observations after a smaller number of initiating errors, not 790 independent failures. They concern memory correctness even when the callback returns a legal action. The exact diagnoses and build check are saved in development_acceptance.json. The validated repaired v6 copy remains available separately. The new development snapshot and results preserve this later comparison without altering either live project.'''
    traces = read("development_trace_findings.json")
    assert traces["exact_score_replays"] == 6
    report += "\n\nSix selected development-build traces reproduced the saved scoreboards. Its four worst defeats were the same fixtures and score vectors as the original submission's worst four in this audit. Their mean 1,314.5-point deficit included 1,260.5 points of lost relative territory income. The development bot averaged 6.5 upgrades and 5.25 lost cells against the winner's twelve upgrades and one lost cell. No final-turn alternative changed placement with other realised actions fixed. These are selected examples of compounding midgame losses, rather than an unbiased census of every failure."
    result = {"summary": latest["summary"], "paired": pair,
              "public_contract_status": acceptance["public_contract_status"],
              "recovery_status": acceptance["recovery_status"],
              "report_text": report}
    (ROOT / "development_analysis.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"summary": result["summary"], "against_recommended": {
        "difference": delta, "delta_95pct": [lo, hi]},
        "recovery_status": result["recovery_status"]}, indent=2))


if __name__ == "__main__":
    main()
