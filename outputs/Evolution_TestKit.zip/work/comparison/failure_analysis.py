"""Post-game Zone Rush diagnostics. Bots see only the public pre-move observation.

trace_game(registry, bots, family, seed, token, watch, values) -> JSON-ready dict.
watch contains one-based seats, bots are four registry IDs. See --help for CLI.
"""
import argparse
from collections import Counter
import copy
import hashlib
import json
from pathlib import Path
import sys
from time import perf_counter

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(Path(__file__).resolve().parent), str(ROOT)]
from arena import Game, NEIGHBORS
from batch import load_player, values_for


def credit(scores, i):
    return sum((scores[i] > s) + .5 * (scores[i] == s)
               for j, s in enumerate(scores) if j != i) / 3.


def snapshot(game):
    return {key: list(getattr(game, key)) for key in
            ("pos", "owner", "upgraded", "frozen", "scores", "progress", "cooldown")}


def income(game):
    totals = [0]*4
    for cell, seat in enumerate(game.owner):
        if seat:
            totals[seat-1] += game.values[cell]*(1+game.upgraded[cell])
    return totals


def _one_turn_alternatives(before, actions, watch):
    """Hindsight against observed, fixed simultaneous actions; no information sent to bots."""
    candidates = {}
    for seat in watch:
        i = seat-1
        rows = []
        # Some server interpretations include attempts to enter occupied cells
        # in legal_actions. Such a recorded attempt resolves as STAY.
        for action in dict.fromkeys([*before.legal(i),actions[i]]):
            hypothesis = copy.deepcopy(before)
            counterfactual = list(actions)
            counterfactual[i] = action
            hypothesis.step(counterfactual)
            scores = hypothesis.scores
            rows.append({"action": action, "scores": scores, "credit": credit(scores,i)})
        actual = next(row for row in rows if row["action"]==actions[i])
        best_credit = max(row["credit"] for row in rows)
        best_points = max(row["scores"][i] for row in rows)
        best_margin = [max(row["scores"][i]-row["scores"][j] for row in rows)
                       if j!=i else 0 for j in range(4)]
        gains = [round(best_margin[j]-(actual["scores"][i]-actual["scores"][j]),6)
                 if j!=i else 0 for j in range(4)]
        if best_points>actual["scores"][i] or best_credit>actual["credit"] or any(gains):
            candidates[seat] = {"actual": actual, "choices": rows,
                                "one_turn_max_own_points_gain": best_points-actual["scores"][i],
                                "one_turn_max_credit_gain": round(best_credit-actual["credit"],6),
                                "one_turn_max_margin_gain_by_rival": gains}
    return candidates


def trace_game(registry, bots, family="balanced", seed=0, token=1, watch=(1,2), values=None,
               late_start=73, legal_style="unoccupied"):
    if len(bots)!=4 or any(seat not in range(1,5) for seat in watch):
        raise ValueError("Supply four bot IDs and one-based watch seats.")
    if values is None:
        values=values_for({"seed":seed,"family":family})
    game=Game(seed=seed,start_token=token,values=values)
    players=[load_player(registry[bot],seed*7919+idx) for idx,bot in enumerate(bots,1)]
    totals=[Counter() for _ in range(4)]
    milestones=[]
    turns=[]
    faults=[]
    for turn in range(1,81):
        before=snapshot(game)
        actions=[]
        for i,(player,internal) in enumerate(players):
            state=game.state(i+1)
            if legal_style=="bounds" and not game.frozen[i]:
                extra_legal=list(NEIGHBORS[game.pos[i]])+["STAY"]
                if not game.cooldown[i]:
                    extra_legal.append("SHIELD")
                state=state._replace(legal_actions=extra_legal)
            start=perf_counter()
            try:
                action=player(state)
                if action not in state.legal_actions:
                    raise ValueError(f"illegal action {action!r}")
                if perf_counter()-start>(2 if turn==1 else .2):
                    raise TimeoutError("turn deadline")
            except Exception as exc:
                faults.append([turn,i+1,repr(exc)])
                action="STAY"
            if internal:
                faults.extend([turn,i+1,"caught internally: "+reason] for reason in internal)
                internal.clear()
            actions.append(action)
        hindsight=(_one_turn_alternatives(game,actions,watch) if turn>=late_start else {})
        game.step(actions)
        inc=income(game)
        events=[]
        for i, action in enumerate(actions):
            s=i+1
            p0,p=before["pos"][i],game.pos[i]
            base=game.values[p]
            totals[i]["income_points"]+=inc[i]
            totals[i]["income_t01_20" if turn<=20 else "income_t21_40" if turn<=40 else
                      "income_t41_60" if turn<=60 else "income_t61_80"]+=inc[i]
            if before["frozen"][i]:
                totals[i]["frozen_turns_served"]+=1
            elif action in ("NORTH","EAST","SOUTH","WEST"):
                if p!=p0:
                    totals[i]["successful_moves"]+=1
                else:
                    totals[i]["blocked_moves"]+=1
                    events.append(["blocked",s,p,NEIGHBORS[p].get(action)])
            if before["owner"][p0] not in (0,s) and not before["frozen"][i]:
                totals[i]["foreign_departures" if p!=p0 else "foreign_shields" if action=="SHIELD"
                          else "foreign_stays"]+=1
            if action=="SHIELD" and not before["frozen"][i]:
                totals[i]["shields"]+=1
                if game.frozen[i]==2:
                    totals[i]["backfires"]+=1
                    events.append(["shield_backfire",s,p])
            if game.frozen[i]==2 and not before["frozen"][i] and action!="SHIELD":
                defender=before["owner"][p]
                totals[i]["caught_by_shield"]+=1
                totals[defender-1]["rivals_caught"]+=1
                events.append(["shield_catch",defender,s,p])
            owner0=before["owner"][p]
            if owner0!=game.owner[p]:
                assert game.owner[p]==s
                if owner0:
                    units=base*(1+before["upgraded"][p])
                    bonus=8*units
                    totals[i]["raids"]+=1
                    totals[i]["upgraded_raids"]+=int(before["upgraded"][p])
                    totals[i]["raid_points"]+=bonus
                    totals[owner0-1]["cells_lost"]+=1
                    totals[owner0-1]["lost_upgraded_cells"]+=int(before["upgraded"][p])
                    events.append(["raid",s,p,owner0,units,bonus])
                else:
                    totals[i]["neutral_captures"]+=1
                    events.append(["neutral_capture",s,p,base])
            elif game.upgraded[p] and not before["upgraded"][p]:
                totals[i]["upgrades"]+=1
                events.append(["upgrade",s,p,base])
            assert totals[i]["income_points"]+totals[i]["raid_points"]==game.scores[i]
        turns.append({"turn":turn,"actions":actions,"positions_before":before["pos"],
                      "positions_after":list(game.pos),"scores_after":list(game.scores),
                      "income_after":inc,"frozen_after":list(game.frozen),
                      "events":events,"hindsight":hindsight})
        if turn in (10,20,40,60,70,80):
            milestones.append({"turn":turn,"scores":list(game.scores),"income":inc,
                               "territory":[game.owner.count(s) for s in range(1,5)],
                               "upgraded":[sum(a==s and b for a,b in zip(game.owner,game.upgraded))
                                           for s in range(1,5)]})
    return {"bots":bots,"source_sha256":{name:hashlib.sha256(Path(registry[name]["path"]).read_bytes()).hexdigest()
                                         for name in set(bots)},
            "family":family,"seed":seed,"token":token,"legal_style":legal_style,"cell_values":game.values,
            "note":"Cell positions are zero-based row*8+column; seats 1–4. Hindsight fixes the other three "
                   "realized simultaneous actions and scores the next turn only. On turn 80 that equals "
                   "the final score. Other turns omit future strategic consequences.",
            "metrics":[dict(row) for row in totals],"milestones":milestones,"faults":faults,
            "final_scores":list(game.scores),"turns":turns}


def trace_fixture(registry, fixture, watch=(1,2), late_start=73):
    """Replay an exact work/comparison/batch.py fixture (including Zoo, neural and bounds-only)."""
    return trace_game(registry,fixture["bots"],fixture["family"],fixture["seed"],fixture["token"],
                      watch,values_for(fixture),late_start,fixture.get("legal_style","unoccupied"))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--registry",type=Path,required=True,help="registry mapping or league state.json")
    p.add_argument("--override",type=Path,help="additional registry records such as the user's bot")
    p.add_argument("--bots",nargs=4,required=True)
    p.add_argument("--family",default="balanced")
    p.add_argument("--seed",type=int,default=0)
    p.add_argument("--token",type=int,default=1)
    p.add_argument("--watch",type=int,nargs="*",default=[1,2])
    p.add_argument("--late-start",type=int,default=73)
    p.add_argument("--out",type=Path,required=True)
    args=p.parse_args()
    spec=json.loads(args.registry.read_text(encoding="utf-8-sig"))
    registry=spec.get("registry",spec)
    if args.override:
        registry.update(json.loads(args.override.read_text(encoding="utf-8-sig")))
    result=trace_game(registry,args.bots,args.family,args.seed,args.token,args.watch,
                      late_start=args.late_start)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(result["final_scores"],result["metrics"],result["faults"])


if __name__=="__main__":
    main()
