"""Independent acceptance of both patched entrants and actual map/fixture accounting."""
from collections import Counter, defaultdict
from copy import deepcopy
from hashlib import sha256
import inspect
import json
from pathlib import Path
import random
import statistics
import sys
from time import perf_counter_ns

from referee_audit import HERE, WORK, LocalGame, module_at, map_values, public_input, snapshot, load_policy


def plan_audit():
    slope=module_at("slope_engine",HERE/"user_snapshot_001"/"engine.py")
    def board(f,s):
        vals=slope.make_map(s) if f=="user_slope" else map_values(s,f)
        return sha256(bytes(vals)).hexdigest()
    plan=json.loads((HERE/"final_plan.json").read_text())["experiments"]
    boards={(r["family"],r["seed"]):board(r["family"],r["seed"]) for r in plan}
    by_subject=defaultdict(set)
    counts=Counter()
    for r in plan:
        i=r["target_seat"]; s=r["target"]; bots=r["bots"]
        assert bots[i]==s
        rivals=tuple(v for j,v in enumerate(bots) if i!=j)
        key=(r["family"],boards[r["family"],r["seed"]],r["lineup"],i,r["token"],rivals)
        assert key not in by_subject[s]
        by_subject[s].add(key)
        counts[(s,r["family"],r["seed"],r["lineup"],i,r["token"])]+=1
    assert len(by_subject)==5 and all(v==1 for v in counts.values())
    assert all(v==next(iter(by_subject.values())) for v in by_subject.values())
    assert all(counts[(s,f,n,l,i,t)]==1 for s in by_subject for f,n in boards for l in range(4)
               for i in range(4) for t in range(1,5))
    prior_maps=set()
    for name in ("screen_plan","confirm_plan"):
        prev=json.loads((HERE/(name+".json")).read_text())["experiments"]
        prior_maps.update((r["family"],r["seed"]) for r in prev)
    state=json.loads((WORK/"evolution/runs/league_001/state.json").read_text())
    for epoch in state["history"]:
        prior_maps.update((r["family"],r["seed"]) for r in epoch["fixtures"])
    previous_hashes={board(f,s) for f,s in prior_maps}
    duplicate=sorted([list(k) for k,h in boards.items() if h in previous_hashes])
    return {"games":len(plan),"targets":list(by_subject),"matched_fixtures_per_target":len(next(iter(by_subject.values()))),
            "family_seed_pairs":len(boards),"distinct_actual_boards":len(set(boards.values())),
            "maps_with_prior_hash":duplicate,"number_of_training_selection_maps_checked":len(previous_hashes),
            "seats_and_tokens_crossed":True,"lineups":4,"number_seed_ids":len({n for f,n in boards}),
            "actual_maps":[{"family":f,"seed":n,"sha256":h} for (f,n),h in sorted(boards.items())]}


def accept(path, n=12):
    mod=module_at("tested",path); original=mod.Agent.decide
    assert str(inspect.signature(mod.act))=="(state)"
    cnt=Counter(); mismatches=Counter(); examples={}; times=[]
    def guarded(this,state):
        try:
            a=original(this,state)
            if a not in state.legal_actions:
                mismatches["internal_illegal"]+=1
            return a
        except Exception:
            mismatches["internal_exception"]+=1
            raise
    mod.Agent.decide=guarded
    for k in range(n):
        rng=random.Random(144300+k)
        me=k%4+1
        g=LocalGame(144300+k,("balanced","patchy","edge","flat")[(k//4+k)%4],start_token=1+((k//4)%4))
        other=iter(load_policy("challengers.py",x) for x in ("fortress","adaptive","lure"))
        policies=[None if s==me else next(other) for s in range(1,5)]
        for t in range(1,81):
            state=public_input(g.state(me))
            before=snapshot(state)
            begin=perf_counter_ns(); action=mod.act(state); dt=(perf_counter_ns()-begin)/1e6
            times.append(dt)
            assert action in state.legal_actions and snapshot(state)==before and dt<(2000 if t==1 else 200)
            tr=mod._AGENTS[me].tr; i=me-1; p=g.pos[i]
            kind=("own_upgraded" if g.owner[p]==me and g.upgraded[p] else "own_unupgraded" if g.owner[p]==me
                  else "rival_home" if p in (0,7,56,63) else "neutral" if g.owner[p]==0 else
                  "rival_upgraded" if g.upgraded[p] else "rival_unupgraded")
            cnt[kind+"_progress_calls"]+=1
            checks={"positions":(tr.pos,g.pos),"scores":(tr.score,g.scores),"turn":(tr.turn,g.turn),
                    kind+"_progress":(tr.prog[i],g.progress[i]),"own_freeze":(tr.frozen[i],g.frozen[i]),
                    "own_cd_frozen" if g.frozen[i] else "own_cd_active":(tr.cd[i],g.cooldown[i])}
            for label,(seen,real) in checks.items():
                if seen!=real:
                    mismatches[label]+=1
                    examples.setdefault(label,{"fixture":k,"turn":t,"seat":me,"seen":deepcopy(seen),"truth":deepcopy(real)})
            acts=[action if s==me else policies[s-1](g.state(s)) for s in range(1,5)]
            for j,a in enumerate(acts):
                if a!="STAY" and rng.random()<(.55 if a=="SHIELD" else .16):
                    cnt[("own" if j==i else "opponent")+("_shield_subs" if a=="SHIELD" else "_move_subs")]+=1
                    acts[j]=rng.choice(("STAY","invalid"))
            g.step(acts)
    return {"source_sha256":sha256(path.read_bytes()).hexdigest(),"games":n,"callbacks":len(times),
            "mean_ms":statistics.mean(times),"p99_ms":sorted(times)[int(len(times)*.99)-1],"max_ms":max(times),
            "internal_caught_errors":mismatches["internal_exception"],"internal_illegal":mismatches["internal_illegal"],
            "deadline_misses":0,"input_mutations":0,"external_illegal":0,"coverage":dict(cnt),
            "mismatches":dict(mismatches),"examples":examples}


if __name__=="__main__":
    result={"fixture_audit":plan_audit()}
    for name in ("user_recovery","user_corrected"):
        result[name]=accept(HERE/(name+".py"))
    (HERE/"referee_audit_patched_results.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    del result["fixture_audit"]["actual_maps"]
    print(json.dumps(result,indent=2))
