"""Apply the frozen promotion rule to a fresh matched audit."""
from collections import defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import random
import statistics
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "evolution"))
from validate_evolution import paired_card, quantile
from batch import designated_summary


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def count_training(run):
    state = read(run / "state.json")
    ids, games, faults = set(), 0, 0
    for path in (run / "cache").glob("*.json.gz"):
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            rows = json.load(stream)
        games += len(rows)
        ids.update(row["target"] for row in rows)
        faults += sum(len(row["errors"]) for row in rows)
    families = defaultdict(int)
    for name in ids:
        spec = state["registry"].get(name, {})
        if "family" in spec:
            families[spec["family"]] += 1
    return {"actual_cached_games": games, "tested_configurations": sum(families.values()),
            "configurations_by_family": dict(families), "recorded_faults": faults,
            "completed_epochs": len(state["history"])}


def shared_seed_sensitivity(rows, candidate, reference, draws=5000):
    """Keep all four generators with a common seed in the same bootstrap block."""
    sides = {name: {} for name in (candidate, reference)}
    for row in rows:
        if row["target"] in sides:
            key = (row["seed"], row["family"], row["target_seat"], row["token"], row["lineup"])
            sides[row["target"]][key] = row["pairwise"][row["target_seat"]]
    assert sides[candidate].keys() == sides[reference].keys()
    blocks = defaultdict(list)
    for key, value in sides[candidate].items():
        blocks[key[0]].append(value - sides[reference][key])
    means = [statistics.mean(v) for v in blocks.values()]
    rng = random.Random(16531)
    boot = [statistics.mean(rng.choices(means, k=len(means))) for _ in range(draws)]
    return {"seed_blocks": len(means), "mean_delta": statistics.mean(means),
            "delta_95pct": [quantile(boot, .025), quantile(boot, .975)],
            "draws": draws, "bootstrap_seed": 16531,
            "note": "Sensitivity only. Four seed blocks are too few for strong general claims."}


def round_two_diagnostics(rows):
    grouped = defaultdict(list)
    for row in rows:
        seat = row["target_seat"]
        ranks = list(zip(row["scores"], row["territory"]))
        ours = ranks[seat]
        rivals = [v for i, v in enumerate(ranks) if i != seat]
        grouped[row["target"]].append({
            "pairwise": sum((ours > other) + .5 * (ours == other) for other in rivals) / 3,
            "strict_first_after_cells": int(ours > max(rivals)),
            "unresolved_first_tie": int(ours == max(ranks) and ranks.count(ours) > 1),
            "score_tie_involving_target": int(any(row["scores"][seat] == value
                for i, value in enumerate(row["scores"]) if i != seat)),
        })
    return {name: {metric: statistics.mean(v[metric] for v in values) for metric in values[0]}
            for name, values in grouped.items()}


def main():
    data = read(ROOT / "transfer_audit_results.json")
    rows, summary = data["records"], data["summary"]
    lock = read(ROOT / "transfer_selection_lock.json")
    paired = {other: paired_card(rows, "transfer_candidate", other)
              for other in ("evolved_reference", "user")}
    reference_user = paired_card(rows, "evolved_reference", "user")
    versus_reference = paired["evolved_reference"]
    conditions = {
        "no_recorded_faults": summary["transfer_candidate"]["errors"] == 0,
        "positive_lower_map_block_95pct_delta": versus_reference["random_map_block_delta_95pct"]["pairwise"][0] > 0,
        "no_decline_mean_strict_first": summary["transfer_candidate"]["strict_first"] >= summary["evolved_reference"]["strict_first"],
    }
    selected = "transfer_candidate" if all(conditions.values()) else "evolved_reference"
    run = ROOT.parent / "evolution" / "runs" / "transfer_001"
    training = count_training(run)
    family = {name: designated_summary([r for r in rows if r["family"] == name])
              for name in sorted({r["family"] for r in rows})}
    lineup = {str(i): designated_summary([r for r in rows if r["lineup"] == i])
              for i in sorted({r["lineup"] for r in rows})}
    sensitivity = {name: shared_seed_sensitivity(rows, "transfer_candidate", name)
                   for name in ("evolved_reference", "user")}
    round_two = round_two_diagnostics(rows)
    def pct(x):
        return f"{100*x:.2f}%"
    names = {"transfer_candidate": "Second-run candidate", "evolved_reference": "First-run winner", "user": "Your submitted bot.py"}
    table = "\n".join(["| Program | Games | Pairwise credit | Outright first | Execution faults |",
                        "| --- | --- | --- | --- | --- |",
                        *[f"| {names[name]} | {s['games']} | {pct(s['pairwise'])} | {pct(s['strict_first'])} | {s['errors']} |"
                          for name, s in sorted(summary.items(), key=lambda p:p[1]['pairwise'], reverse=True)]])
    delta = versus_reference["all_fixtures"]["pairwise"]["difference"]
    lo, hi = versus_reference["random_map_block_delta_95pct"]["pairwise"]
    decision = ("The second-run candidate met all three frozen promotion conditions and becomes the recommended bot."
                if selected == "transfer_candidate" else
                "The second-run candidate did not meet all three frozen promotion conditions. The first-run winner remains the recommended bot.")
    lower, upper = sensitivity["evolved_reference"]["delta_95pct"]
    reference_delta = reference_user["all_fixtures"]["pairwise"]["difference"]
    reference_low, reference_high = reference_user["random_map_block_delta_95pct"]["pairwise"]
    report = f'''**The second evolutionary run included your corrected route planner as an evolving family.** It completed {training['completed_epochs']} further epochs and {training['actual_cached_games']:,} actual stored games, testing {training['tested_configurations']} parameter configurations across economic, action-beam and user-route families. It used three league epochs, one response epoch and two polish epochs. The starting economic policy was the first-run winner. The user-route family kept its code architecture and evolved twelve strategic parameters. Every tested configuration is identified in the checkpoint and raw outcomes. Training recorded {training['recorded_faults']} faults.

After four epochs, a single-response scheduling defect constructed a field with too few opponents. It stopped before writing any invalid games. The 4,704 completed games were retained. The driver was repaired to fill the opponent slots, normalise checkpoint metadata across JSON round trips, and retry transient Windows file locks during progress writes. Original and repaired driver hashes, the retained checkpoint and the reasons for repair are saved in training_repair.json. Policy and referee sources remained fixed. Resuming reproduced the first four epochs from cache and added the final two. The final progress counter counts only newly simulated games since that resume, so the total above comes from the stored cache rows.

Archived and generation-leading profiles then faced 1,056 separate screening games, followed by 960 top-three confirmation and reference games. The chosen profile, {lock['selected_profile']}, was exported and frozen before the audit. It uses {lock['genome']['depth']}-job lookahead with {lock['genome']['breadth']} leading first jobs, late upgrade weight {lock['genome']['upgrade_late']}, late defended-raid risk {lock['genome']['risk_late']}, and safety slope {lock['genome']['safety_slope']}. Those parameters were selected together. Their individual causal effects have not been established by ablation. The new audit contains 1,024 identical fixtures per program on sixteen distinct boards, all four map groups, seats, initial tokens and four opponent fields. Its board hashes overlap none of the 258 previously checked boards. The fields include three copies of the first-run winner, the original and corrected route planners with a job-search rival, prior search and rival-intent policies, and a later response with an evolved route planner. These include self-interested responses but do not represent every rational policy.

{table}

The new candidate's paired advantage over the first-run winner was {100*delta:+.2f} percentage points, with a stratified whole-board bootstrap interval of {100*lo:+.2f} to {100*hi:+.2f} points. A secondary sensitivity calculation resampled the four seed IDs, keeping all four map generators together, and gave {100*lower:+.2f} to {100*upper:+.2f} points. Four boards per generator, or four shared-seed blocks, remain a small map sample. These are conditional intervals for this experiment, not competition win guarantees.

The first-run winner's advantage over your original submission replicated in this second panel: {100*reference_delta:+.2f} pairwise points, with a whole-board interval of {100*reference_low:+.2f} to {100*reference_high:+.2f} points.

The predeclared promotion rule requires zero faults, a positive lower 95% whole-board interval for pairwise improvement, and no decline in mean outright-first rate. {decision} Rates from this stronger, different opponent population should be compared only within this table. In particular, the first table's 80.78% cannot be substituted for the first-run winner's result in this second panel. Applying the Round 2 cell-count tiebreak to these saved scoreboards gives the recommended bot {pct(round_two[selected]['pairwise'])} pairwise credit and {pct(round_two[selected]['strict_first_after_cells'])} uniquely first after cell count. Any remaining equal score and cell count needs the actual event seed, which is unavailable. The recommended single file is outputs/bot.py. Earlier winners and the tested transfer candidate are preserved separately, together with their exact hashes and results.'''
    result = {"summary": summary, "paired": paired, "reference_vs_user": reference_user, "shared_seed_sensitivity": sensitivity,
              "family": family, "lineup": lineup, "training": training, "round_two_diagnostics": round_two,
              "promotion_conditions": conditions, "recommended": selected,
              "selected_profile": lock["selected_profile"], "source_sha256": lock["source_sha256"],
              "report_text": report}
    (ROOT / "transfer_analysis.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items()
                      if key in ("summary", "promotion_conditions", "recommended", "training")}, indent=2))


if __name__ == "__main__":
    main()
