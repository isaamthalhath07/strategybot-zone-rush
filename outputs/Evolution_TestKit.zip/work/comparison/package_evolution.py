"""Build or verify the portable Zone Rush research bundle. Uses only the standard library."""
import argparse
import ast
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / "work"
OUTPUT = ROOT / "outputs" / "Evolution_TestKit.zip"
MANIFEST = "PACKAGE_MANIFEST.json"
SNAPSHOT = "work/comparison/user_snapshot_001"
SOURCE_SNAPSHOT = "C:/Users/LEGION/stratergybot"
SKIP_DIRS = {".git", "__pycache__", ".venv", ".venv-rl", "node_modules",
             "packaging_qa", "smoke_001", ".pytest_cache"}
WORK_SUFFIXES = {".py", ".json", ".gz", ".csv", ".md", ".txt"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def package_paths():
    for top in (WORK, ROOT / "outputs"):
        for directory, folders, names in os.walk(top):
            base = Path(directory)
            folders[:] = sorted(name for name in folders if name not in SKIP_DIRS and
                                not name.endswith("_cache") and not name.startswith(".") and
                                not (base / name).is_symlink())
            for name in sorted(names):
                path = base / name
                if path.is_symlink() or name.startswith("."):
                    continue
                if top == ROOT / "outputs":
                    if path.suffix.lower() not in {".py", ".md"} or path.parent != top:
                        continue
                elif path.suffix.lower() not in WORK_SUFFIXES:
                    continue
                if (name.endswith((".progress.json", "_log.txt", ".tmp", ".pyc")) or
                    name in {"trace_smoke.json","trace_smoke2.json"}):
                    continue
                yield path


def portable_json(path, original):
    """Keep every byte of genuine policy sources and path-free JSON evidence."""
    if not (path.name.endswith(".json") or path.name.endswith(".json.gz")):
        return original
    zipped = path.name.endswith(".gz")
    plain = gzip.decompress(original) if zipped else original
    # Both the original location and a rebuilder's current workspace can occur
    # in historical lock records. Treat both slash spellings identically.
    workspace_roots = {ROOT.as_posix(), "C:/Users/LEGION/Documents/Codex/2026-11-06/ba"}
    prefixes = [(SOURCE_SNAPSHOT, SNAPSHOT)] + [(value, ".") for value in workspace_roots]
    variants = [variant.encode().lower() for prefix,_ in prefixes
                for variant in (prefix, prefix.replace("/", "\\"), prefix.replace("/", "\\\\"))]
    if not any(variant in plain.lower() for variant in variants):
        return original
    content = json.loads(plain.decode("utf-8-sig"))

    def normalize_string(value):
        slashed = value.replace("\\", "/")
        matched = False
        for prefix, target in prefixes:
            test = re.compile(re.escape(prefix)+r"(?=/|$)", re.IGNORECASE)
            if not test.search(slashed):
                continue
            matched = True
            if target==".":
                slashed = re.sub(re.escape(prefix)+"/", "", slashed, flags=re.IGNORECASE)
                slashed = re.sub(re.escape(prefix)+"$", ".", slashed, flags=re.IGNORECASE)
            else:
                slashed = test.sub(target,slashed)
        return slashed if matched else value

    def visit(value):
        if isinstance(value, str):
            return normalize_string(value)
        if isinstance(value, list):
            return [visit(entry) for entry in value]
        if isinstance(value, dict):
            rebuilt = {}
            for key, item in value.items():
                portable_key = normalize_string(key)
                if portable_key in rebuilt:
                    raise ValueError(f"Path normalization collides in {path.name}: {portable_key}")
                rebuilt[portable_key] = visit(item)
            return rebuilt
        return value

    portable = visit(content)
    if portable == content:
        return original
    encoded = (json.dumps(portable, ensure_ascii=False, separators=(",",":"))+"\n").encode("utf-8")
    return gzip.compress(encoded, compresslevel=5, mtime=0) if zipped else encoded


def readme(recommended):
    return f"""# Zone Rush research and replay kit

Run the commands below in the extracted folder containing this README. Use Python 3.12 or newer. The submission candidate is `{recommended}`. Keep only that candidate as your competition repository's `bot.py` if your team chooses it. The recommended policy, tournament referees and replay commands use the Python standard library. The packaged user-project snapshot also preserves its optional, separate GPU development code.

## Verify the evidence and policy

    python -B work/comparison/package_evolution.py --check-unpacked

This verifies all archived SHA-256 hashes, runs the local referee tests and exercises the recommended policy's observation recovery. These tests use the published game interface and the organizer-confirmed interpretation that frozen turns earn no progress. The organizers' server is authoritative. The local engine and generated boards are independent reconstructions.

## Replay a match or a full comparison

    python -B work/comparison/package_evolution.py --replay work/comparison/final_plan.json --fixture 0
    python -B work/comparison/batch.py work/comparison/final_plan.json my_replayed_final.json --workers 4

Additional plans and full recorded results are in `work/comparison`, including the neural ablation, direct matchups, transfer screen and subsequent audits that were completed before packaging. Full replay writes a new cache and may take considerable time. Timings depend on the machine. Policies that adapt search depth to elapsed time may occasionally choose another move.

## Train a new population

    python -B work/evolution/evolve.py --directory my_new_league --generations 10 --response-generations 4 --polish-generations 2 --population 36 --workers 4 --seed 20261106
    python -B work/evolution/evolve_transfer.py --directory my_new_transfer --generations 3 --response-generations 1 --polish-generations 2 --population 18 --workers 4 --seed 20261107

Use a new directory for each run and inspect its manifest for the exact settings. The archived transfer run includes its checkpoint repairs and historical trainer versions. A fresh run with the final training code may follow a different trajectory. Historical completed checkpoints, raw per-game training caches and source locks are in `work/evolution/runs`. The original trainer includes machine-local paths in checkpoint compatibility checks and cache fingerprints. Treat those runs as read-only evidence when working on another computer.

## Where to look

- `outputs` holds the selected code and research reports. Older policies, including the obsolete frozen-progress experiment if present, are historical comparisons.
- `work/comparison/user_snapshot_001` holds the frozen external project used for comparison, including its original submission, model weights and training sources. `user_recovery.py` and `user_corrected.py` are separate experimental copies. The source project itself was left untouched.
- `work/arena.py`, `work/test_arena.py`, `work/official_bot.py` and `work/official_README.md` contain the independent referee, its tests, and the public interface snapshot. Organizer answers relayed by the user are in `work/organizer_clarifications.json`.
- `PACKAGE_MANIFEST.json` records the delivered hash and size of every other packaged file. A normalized JSON entry also records its original hash. JSON paths are relative to this extracted root. All Python policy files retain their original bytes. Original hashes embedded in archived locks continue to describe their original files.
- Historical setup and diagnostic scripts may retain their original machine paths. Use the snapshot and the portable commands above rather than rerunning host-specific setup scripts.
"""


def run(command, cwd):
    subprocess.run([sys.executable, "-B", *map(str,command)],cwd=cwd,check=True)


def verify_folder(base):
    manifest = json.loads((base / MANIFEST).read_text(encoding="utf-8"))
    for rel, entry in manifest["files"].items():
        path = base / rel
        if not path.is_file() or path.stat().st_size != entry["bytes"] or digest(path.read_bytes())!=entry["sha256"]:
            raise ValueError(f"Packaged file mismatch: {rel}")
    print(f"Verified {len(manifest['files'])} packaged files.",flush=True)
    tests = base / "work" / "test_arena.py"
    rule_tests = sum(isinstance(n, ast.FunctionDef) and n.name.startswith("test_")
                     for n in ast.walk(ast.parse(tests.read_text(encoding="utf-8-sig"))))
    if rule_tests < 23:
        raise ValueError(f"Expected at least 23 referee tests, found {rule_tests}")
    run([tests],base)
    run([base / "work" / "test_terminal.py"],base)
    plan_file=base/"work/comparison/transfer_audit_plan.json"
    result_file=base/"work/comparison/transfer_audit_results.json"
    if plan_file.exists() and result_file.exists():
        plan=json.loads(plan_file.read_text(encoding="utf-8"))
        result=json.loads(result_file.read_text(encoding="utf-8"))
        for target in ("evolved_reference","transfer_candidate"):
            index=next(i for i,r in enumerate(plan["experiments"])
                       if r["target"]==target and r["lineup"]==0)
            command=[sys.executable,"-B",str(base/"work/comparison/package_evolution.py"),
                     "--replay","work/comparison/transfer_audit_plan.json","--fixture",str(index)]
            played=subprocess.run(command,cwd=base,check=True,capture_output=True,text=True)
            row=json.loads(played.stdout)
            assert row["scores"]==result["records"][index]["scores"]
            assert not row["errors"]
        print("Two portable audit replays matched all four saved scores.",flush=True)
    selected = base / manifest["recommended"]
    source = selected.read_text(encoding="utf-8-sig")
    if "_history" in source:
        scratch_root=base/"work/packaging_qa"
        scratch_root.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="recovery_",dir=scratch_root) as scratch:
            result = Path(scratch) / "recovery.json"
            run([base/"work/evolution/validate_evolution.py","accept","--bot",selected,
                 "--games","4","--output",result],base)
            if json.loads(result.read_text(encoding="utf-8")).get("status")!="pass":
                raise ValueError("Recommended policy recovery acceptance did not pass.")
    elif "_AGENTS" in source:
        # The original project's public entry point keeps per-seat Trackers
        # under _AGENTS. Validate through the independent project adapter.
        program = """from pathlib import Path
import sys
sys.path.insert(0,'work/comparison')
import user_fix_validation as v
p=Path(sys.argv[1]).resolve()
v.probe.USER=p
s=v.probe.memory_fixture(); assert s['true_turn']==s['inferred_turn'] and s['true_scores']==s['inferred_scores']
s=v.probe.rejected_shield_fixture(); assert s['true_cooldown_seat3']==s['inferred_cooldown_seat3']
s=v.check_transitions(p); assert s['opening_return']==[3,3,[2]*4,[2]*4] and s['new_game']==[1,[0]*4]
s=v.check_fuzz(p); assert not any(s[k] for k in ('wrong_turn','wrong_score','wrong_progress','internal_exceptions')),s
print('Recommended route-policy observation and fallback tests passed:',s)
"""
        run(["-c",program,selected],base)
    else:
        raise ValueError("The selected policy requires a compatible recovery-test adapter.")
    print(f"Verified recommended policy {manifest['recommended']}.",flush=True)


def build(recommended, archive, verify):
    files = list(package_paths())
    selected = ROOT / recommended
    if selected not in files or selected.suffix!=".py" or selected.parent!=ROOT/"outputs":
        raise ValueError("Use a selected .py file under outputs.")
    needed = ["work/evolution/evolve.py","work/evolution/evolve_transfer.py",
              "work/evolution/runs/league_001/state.json","work/evolution/runs/transfer_001/state.json",
              SNAPSHOT+"/bot.py","work/comparison/final_plan.json","work/comparison/final_results.json"]
    for name in needed:
        if not (ROOT/name).is_file():
            raise FileNotFoundError(name)
    scratch_parent = WORK / "packaging_qa"
    scratch_parent.mkdir(exist_ok=True)
    uncompressed = sum(p.stat().st_size for p in files)
    reserve = uncompressed*(2 if verify else 1)+32*1024**2
    if shutil.disk_usage(scratch_parent).free < reserve:
        raise OSError("Insufficient free space for archive and verification. Existing archive was preserved.")
    with tempfile.TemporaryDirectory(prefix="evolution_kit_",dir=scratch_parent) as scratch:
        temporary = Path(scratch)/"candidate.zip"
        catalog = {}
        changed=[]
        def add(z, rel, data, original=None):
            catalog[rel] = {"bytes":len(data),"sha256":digest(data)}
            if original is not None:
                catalog[rel]["original_sha256"] = digest(original)
                changed.append(rel)
            z.writestr(rel,data,compress_type=zipfile.ZIP_STORED if rel.endswith(".gz") else zipfile.ZIP_DEFLATED,
                       compresslevel=3)
        with zipfile.ZipFile(temporary,"w",allowZip64=True) as z:
            for source in files:
                rel=source.relative_to(ROOT).as_posix()
                before=source.stat()
                original=source.read_bytes()
                after=source.stat()
                if before.st_mtime_ns!=after.st_mtime_ns or len(original)!=before.st_size:
                    raise OSError(f"Evidence changed during packaging: {rel}")
                data=portable_json(source,original)
                add(z,rel,data,original if data!=original else None)
            add(z,"README.md",readme(recommended).encode("utf-8"))
            manifest={"format":1,"recommended":recommended,"normalized_json_count":len(changed),
                      "files":catalog}
            z.writestr(MANIFEST,json.dumps(manifest,indent=2).encode("utf-8"),
                       compress_type=zipfile.ZIP_DEFLATED,compresslevel=3)
        if verify:
            unpack=Path(scratch)/"unpacked"
            with zipfile.ZipFile(temporary) as z:
                bad=z.testzip()
                if bad is not None:
                    raise ValueError(f"Archive CRC failed: {bad}")
                z.extractall(unpack)
            verify_folder(unpack)
        temporary.replace(archive)
    print(f"Saved {archive}, {archive.stat().st_size:,} bytes, {len(catalog)} files; "
          f"{len(changed)} JSON paths documents normalized.",flush=True)


def replay(plan_name,index):
    os.chdir(ROOT)
    sys.path.insert(0, str(WORK/"comparison"))
    import batch
    plan=json.loads((ROOT/plan_name).read_text(encoding="utf-8-sig"))
    fixture=plan["experiments"][index]
    print(json.dumps(batch.play(plan["policies"],fixture),indent=2))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--recommended",default="outputs/bot_evolved.py",
                        help="Actual .py recommendation relative to the workspace root")
    parser.add_argument("--verify",action="store_true",help="Unpack the completed ZIP and test before publishing it")
    parser.add_argument("--check-unpacked",action="store_true",help="Verify evidence and test the extracted package")
    parser.add_argument("--replay",help="Replay one fixture from a packaged comparison plan")
    parser.add_argument("--fixture",type=int,default=0)
    args=parser.parse_args()
    if args.check_unpacked:
        verify_folder(ROOT)
    elif args.replay:
        replay(args.replay,args.fixture)
    else:
        build(Path(args.recommended).as_posix(),OUTPUT,args.verify)
