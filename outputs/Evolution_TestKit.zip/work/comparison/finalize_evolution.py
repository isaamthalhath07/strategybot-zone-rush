"""Publish only the exact artifact supported by the frozen audit and acceptance."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent.parent / "outputs"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    analysis = read(ROOT / "transfer_analysis.json")
    promoted = analysis["recommended"] == "transfer_candidate"
    source = OUTPUT / ("bot_transfer_candidate.py" if promoted else "bot_evolved.py")
    acceptance = read(ROOT / ("transfer_candidate_acceptance.json" if promoted else "evolved_acceptance.json"))
    assert acceptance["status"] == "pass"
    assert acceptance["source"]["sha256"] == sha(source)
    if promoted:
        assert all(analysis["promotion_conditions"].values())
        assert analysis["source_sha256"] == sha(source)
    else:
        occupied = read(ROOT / "evolved_occupied_legal_acceptance.json")
        assert occupied["status"] == "pass"
        assert not occupied["occupied_direction_legality"]["internal_faults"]
    submission = OUTPUT / "bot.py"
    historical = OUTPUT / "bot_before_evolution.py"
    if not historical.exists():
        assert sha(submission) == "630bfa2034a719b1afae62a5675f94c47b190f13b2134882353d96ef10e4327a"
        shutil.copyfile(submission, historical)
    else:
        assert sha(historical) == "630bfa2034a719b1afae62a5675f94c47b190f13b2134882353d96ef10e4327a"
    shutil.copyfile(source, submission)
    assert sha(submission) == sha(source)
    corrected = ROOT / "user_corrected.py"
    assert sha(corrected) == "942948a119bf3688b8b5137536d29bd60cf2b741f2c5c930de977c4e629fa3cc"
    shutil.copyfile(corrected, OUTPUT / "bot_user_corrected.py")
    original = Path("C:/Users/LEGION/stratergybot/bot.py")
    original_matches = sha(original) == "6ebdfb1d64c848463c526a4dbb50464288227d063c6f93c9e3597339273b5d45"
    result = {"recommended": "outputs/bot.py", "exact_source": source.name,
              "sha256": sha(submission), "bytes": submission.stat().st_size,
              "transfer_promoted": promoted, "acceptance_status": acceptance["status"],
              "original_user_submission_still_matches_snapshot": original_matches,
              "training_epochs": 22, "actual_training_games": 33312,
              "promotion_conditions": analysis["promotion_conditions"],
              "fresh_audit_summary": analysis["summary"][analysis["recommended"]]}
    (ROOT / "final_submission_lock.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    historical_report = OUTPUT / "StrategyBot_Research.md"
    old = historical_report.read_text(encoding="utf-8")
    marker = "Historical baseline report."
    if not old.startswith(marker):
        historical_report.write_text(marker + " The later evolutionary comparison and current recommendation are in Evolution_Comparison.md. This report describes the preserved bot_before_evolution.py and its original test kit.\n\n" + old, encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
