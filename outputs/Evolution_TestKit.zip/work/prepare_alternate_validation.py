import itertools
import json
from pathlib import Path
import random
import re

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / "outputs"
source = (ROOT / "planner_rules.py").read_text(encoding="utf-8")
weights = {"ALT_UPGRADE":2.2,"ALT_RAID":1.,"ALT_RISK":.2,"ALT_DEFENSE":.25}
for name,value in weights.items():
    source = re.sub(rf"^{name} = .+$",f"{name} = {value!r}",source,flags=re.M)
source = source.replace("Zone Rush bot, selected by local empirical testing on 6 November 2026.",
                        "Zone Rush conditional profile for frozen stays that accrue progress.")
(OUT / "bot_frozen_progress.py").write_text(source,encoding="utf-8")
plan = json.loads((ROOT / "holdout.json").read_text())
plan["policies"]["alternate_profile"] = {"path":str(OUT / "bot_frozen_progress.py")}
lineups = [list(row) for row in [
    ["fortress","lure","planner"], ["lure"]*3,
    ["beam_fort","macro_beam","variant14"], ["learned_tuned"]*3,
    ["learned_tuned","macro_beam","lure"]]]
maps = [(family,seed) for family in ["balanced","patchy","edge"] for seed in [3001,3002]]
experiments = []
for target,(family,seed),lineup_index,seat,token in itertools.product(
        ["alternate_profile","submission"],maps,range(5),range(4),range(1,5)):
    rivals = list(lineups[lineup_index])
    random.Random(seed*100 + seat*10 + token).shuffle(rivals)
    rivals.insert(seat,target)
    experiments.append({"bots":rivals,"family":family,"seed":seed,"token":token,
                        "target":target,"target_seat":seat,"lineup":lineup_index,
                        "frozen_progress":True})
plan["experiments"] = experiments
(ROOT / "alternate_validation.json").write_text(json.dumps(plan,indent=2))
print(f"Saved {len(experiments)} independent alternate-rule comparison games")
