"""Render the research report directly from retained experiment records."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / "outputs"


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))


def pct(value):
    return f"{100 * value:.2f}%"


def table(headers, rows):
    return "\n".join(["| " + " | ".join(headers) + " |",
                      "| " + " | ".join(["---"] * len(headers)) + " |",
                      *["| " + " | ".join(map(str, row)) + " |" for row in rows]])


def metric(rows, key):
    return sum(row[key][row["target_seat"]] for row in rows) / len(rows)


def main():
    analysis = read("holdout_analysis.json")
    all_stats, random_stats = analysis["all"], analysis["random"]
    ci = analysis["stratified_map_bootstrap"]["95pct"]
    rows = []
    for label, key in [("Pairwise credit", "pairwise"), ("Outright first", "strict_first"),
                       ("Fractional first", "first_share")]:
        rows.append([label, pct(all_stats[key]), pct(random_stats[key]),
                     f"{pct(ci[key][0])} to {pct(ci[key][1])}"])
    final_results = table(["Measure", "All 3,200 games", "2,880 new-random-map games",
                           "95% map-block interval for new random maps"], rows)
    counts = all_stats["counts"]
    final_results += (f"\n\nThe bot won {counts['strict_first']:,} games outright. Its 9,600 comparisons "
                      f"comprised {counts['wins']:,} wins, {counts['draws']} draws and "
                      f"{counts['losses']:,} losses. It finished strictly last in "
                      f"{counts['strict_last']} games. No participant incurred a bot error or time-limit "
                      f"fallback. Across 256,000 calls, the selected program averaged "
                      f"{all_stats['mean_ms']:.3f} ms and peaked at {all_stats['max_ms']:.3f} ms "
                      "on this computer, against the 200 ms turn limit.")
    labels = {
        "learned_cautious": "Adaptive cautious (selected)",
        "learned_tuned": "Adaptive with higher raid weight",
        "learned_no_bait": "Adaptive, feints disabled",
        "macro_beam": "Four-job beam search",
        "learned_fortify": "Adaptive fortification",
        "beam": "Ten-action beam search",
        "variant14": "Tuned original planner",
        "variant20": "Cautious original planner",
        "u2.2_r0.5": "Upgrade-heavy original planner",
        "u1.8_r0.5": "Low-raid original planner",
        "fortress": "Fortress policy", "lure": "Shield-baiting policy",
        "planner": "Initial planner",
    }
    selection_table = table(
        ["Candidate", "Games", "Pairwise credit", "Outright first", "Weakest lineup credit"],
        [[labels[row["name"]], row["games"], pct(row["pairwise"]), pct(row["strict_first"]),
          pct(row["worst_lineup"])] for row in read("selection_summary.json")])
    family_labels = {"balanced": "Centre-weighted random", "patchy": "Irregular random",
                     "edge": "Perimeter-heavy random", "example": "Fixed rulebook illustration",
                     "flat": "Three fixed flat boards"}
    families = table(["Map group", "Games", "Pairwise credit", "Outright first"],
                     [[family_labels[name], row["games"], pct(row["pairwise"]), pct(row["strict_first"])]
                      for name, row in analysis["family"].items()])
    lineup_names = ["Fortress + lure + initial planner", "Three shield-baiting policies",
                    "Action beam + job beam + tuned planner", "Three copies of tuned adaptive rival",
                    "Adaptive + job beam + lure"]
    lineups = table(["Opponent lineup", "Games", "Pairwise credit", "Outright first"],
                    [[lineup_names[int(name)], row["games"], pct(row["pairwise"]), pct(row["strict_first"])]
                     for name, row in analysis["lineup"].items()])
    rotations = table(["Candidate seat", "Games", "Pairwise credit", "Outright first"],
                      [[name, row["games"], pct(row["pairwise"]), pct(row["strict_first"])]
                       for name, row in analysis["seat"].items()])
    tokens = table(["Initial token holder", "Games", "Pairwise credit", "Outright first"],
                   [[name, row["games"], pct(row["pairwise"]), pct(row["strict_first"])]
                    for name, row in analysis["token"].items()])
    breakdown = "\n\n".join([families, lineups, rotations, tokens])
    breakdown += (f"\n\nApplying the Round 2 territory tiebreak gives "
                  f"{pct(all_stats['r2_pairwise'])} pairwise credit and "
                  f"{pct(all_stats['r2_strict_first'])} strict firsts before seeding. "
                  f"Cell count resolved {counts['cell_count_broke_tie']} of the "
                  f"{counts['draws']} tied pairwise score comparisons. The test kit preserves "
                  "every breakdown and a second bootstrap that resamples shared seed IDs across generators.")
    validation = read("submission_validation.json")
    cold = validation["fresh_module_every_call"]
    persistent = validation["paired_persistent_reference"]
    baseline_name = "pre_clarification_results.json" if (ROOT / "pre_clarification_results.json").exists() else "holdout_results.json"
    baseline = read(baseline_name)["records"][::20]
    alternate = read("freeze_sensitivity_results.json")["records"]
    validation_text = table(
        ["Matched execution condition", "Games", "Pairwise credit", "Outright first"],
        [["Persistent memory", 16, pct(persistent["pairwise"]), f"{persistent['strict_firsts']}/16"],
         ["Fresh module every call", 16, pct(cold["pairwise"]), f"{cold['strict_firsts']}/16"],
         ["Main freeze model, sensitivity subset", 160, pct(metric(baseline, "pairwise")),
          pct(metric(baseline, "strict_first"))],
         ["Frozen stays accrue progress, same subset", 160, pct(metric(alternate, "pairwise")),
          pct(metric(alternate, "strict_first"))]])
    validation_text += (
        "\n\nThese are two separate matched experiments. The 16-game lifecycle comparison uses the same fixtures "
        "on each side. The 160-game rule sensitivity uses every twentieth final-audit fixture. It fixes the "
        "initial token to seat 1, covers four fixed lineup/seat combinations and omits the fifth lineup. "
        "The freeze comparison used the original audited source and establishes dependence within that restricted coverage. "
        "The organiser answer has since confirmed the no-progress rule. The alternate-progress results remain historical experiments.\n\n"
        "The delivered source passed standard-library, signature, documented-field, legal-action and input-purity "
        "checks. Across 44 validation games, there were zero exceptions, illegal returns, input mutations or "
        "deadline misses. On the persistent samples, all reconstructed own turn and score vectors matched "
        "the referee, with 1,786 actionable progress checks. The fresh-module sample included 1,280 module reloads "
        f"and peaked at {cold['entry_plus_action']['max_ms']:.3f} ms including import and action.\n\n"
        "The local referee passes 23 regression tests. The terminal rule passes its 4,533-profile check. "
        "The independent holdout audit verified all 40 board values, distinct fixtures, source hashes and "
        "absence of random-map overlap with development.")
    alternate_path = ROOT / "alternate_validation_summary.json"
    if alternate_path.exists():
        alt = read(alternate_path.name)["summary"]
        validation_text += (
            "\n\nBefore the clarification, six configurations were screened under the counterfactual rule that frozen stays earn progress. "
            "A separate profile was then compared with the original main bot on six new random maps, five lineups, all seats and all initial "
            f"tokens. In 480 fixtures each, that profile earned {pct(alt['alternate_profile']['pairwise'])} pairwise credit and "
            f"{pct(alt['alternate_profile']['strict_first'])} outright wins, against {pct(alt['submission']['pairwise'])} and "
            f"{pct(alt['submission']['strict_first'])} for the original main bot. Those opponents were not independently retuned for the "
            "counterfactual. Both profiles and raw results are retained for provenance. The confirmed rules select the updated main bot.py.")
    recovery_text = ""
    if (ROOT / "clarification_replay_summary.json").exists():
        recovery_text = read("clarification_replay_summary.json")["report_text"]
    text = (ROOT / "report_template.md").read_text(encoding="utf-8")
    for marker, value in {"{{FINAL_RESULTS}}": final_results, "{{SELECTION_TABLE}}": selection_table,
                          "{{BREAKDOWN_TABLES}}": breakdown, "{{VALIDATION_RESULTS}}": validation_text,
                          "{{RECOVERY_UPDATE}}": recovery_text}.items():
        text = text.replace(marker, value)
    assert "{{" not in text
    (OUT / "StrategyBot_Research.md").write_text(text, encoding="utf-8")
    with (ROOT / "holdout_results.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["family", "seed", "lineup", "seat", "token", "score", "territory",
                         "pairwise", "outright_first", "fractional_first", "max_action_ms"])
        for row in read("holdout_results.json")["records"]:
            seat = row["target_seat"]
            writer.writerow([row["family"], row["seed"], row["lineup"], seat + 1, row["token"],
                             row["scores"][seat], row["territory"][seat], row["pairwise"][seat],
                             row["strict_first"][seat], row["first_share"][seat], row["latency_max_ms"][seat]])
    print(f"Wrote {len(text.split()):,} report words and 3,200 CSV rows")


if __name__ == "__main__":
    main()
