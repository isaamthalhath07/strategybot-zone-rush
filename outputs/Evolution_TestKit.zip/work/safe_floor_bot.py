"""Conservative 307-point minimum policy under ordinary uninterrupted starts.

It upgrades home, enters its best neighbor, then parks and upgrades there.
The competitive submission is a different program.
"""


def act(state):
    cells = [cell for row in state.board for cell in row]
    origin = next(i for i, cell in enumerate(cells) if cell.occupant == state.bot_id)
    here = cells[origin]
    if here.is_home and here.is_upgraded:
        row, column = divmod(origin, 8)
        choices = []
        for action, target, valid in [
            ("NORTH", origin - 8, row > 0),
            ("EAST", origin + 1, column < 7),
            ("SOUTH", origin + 8, row < 7),
            ("WEST", origin - 1, column > 0),
        ]:
            if valid and action in state.legal_actions and not cells[target].occupant:
                choices.append((cells[target].base_points, action))
        if choices:
            return max(choices)[1]
    return "STAY"
