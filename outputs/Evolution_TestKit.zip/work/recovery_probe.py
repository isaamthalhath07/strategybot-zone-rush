from arena import *
from validate_submission import new_module
for owner in (0,1,2,3):
 for here in ('own','enemy','home'):
  for choices in ((1,3),(1,1)):
   g=Game(values=[1]*64,start_token=3); g.pos=[27,29,63,56]; g.owner[27] = 1 if here=='own' else 3; g.upgraded[27]= here!='own'; g.owner[28]=owner; g.values[27],g.values[28]=choices; m=new_module(); a=m.act(g.state(1)); g.step(['STAY']*4); b=m.act(g.state(1)); print(owner,here,choices,a,b)
print('shield')
for count in (1,2,3):
 g=Game(values=[1]*64);g.pos=[27,28,30,45];g.owner[27]=1
 for k in range(count):
  p=g.pos[k+1];g.owner[p]=1;g.values[p]=3
 m=new_module();print(count,m.act(g.state(1)))
