# StrategyBot local test kit

Start with `StrategyBot_Research.md` for the method, results and referee assumptions. The competition entry is the updated `bot.py`. The organisers confirmed that frozen turns give no progress and that memory between turns is allowed. They offer a template/server compatibility check, with official gameplay testing reserved for the hardware stage. The other files support local testing. Use Python 3.10 or newer. The experiments used Python 3.12.10 and the standard library.

## Verify the download and try the bots

Extract the ZIP to a new folder and open a terminal in that folder. On Windows, `py` can be used in place of `python`.

```text
python -B verify_testkit.py
```

This checks the evidence files against their SHA-256 fingerprints, runs the referee, final-turn and action-recovery tests, and plays an 80-turn legal-action smoke test with each historical rules profile. `EVIDENCE_MANIFEST.json` lists the hash of every other file in the archive. The bot files are self-contained.

* `bot.py` is the current primary profile for the confirmed rules. It reconciles memory with actual observed positions and shield availability after blocked moves and server STAY substitutions.
* `bot_audited.py` preserves the previous primary source for the pre-clarification evidence. The updated source fixes two recovery defects. `pre_clarification_*` records preserve its original benchmark and validation.
* `bot_frozen_progress.py` and the alternate-rule experiments document a historical counterfactual ruled out by the organiser answer. The current competition candidate is `bot.py`.
* `safe_floor_bot.py` implements the conservative points guarantee discussed in the research. It serves as a mathematical reference.

## Reproduce the primary audit

```text
python -B analyze_holdout.py --output replay_analysis.json
python -B bench.py holdout.json replay_results.json
python -B analyze_holdout.py --results replay_results.json --output replay_game_analysis.json
```

The first command reanalyses the retained raw outcomes, checking the 3,200 fixtures, designated seat, source hashes, map uniqueness, and uncertainty intervals. The next two commands replay all primary games and analyze their results. Give output files fresh names to preserve the evidence checksums. Timing varies by machine. A deadline miss becomes a stay under the local referee.

For historical alternative-rule tests, run `python -B bench.py freeze_sensitivity.json replay_freeze.json` and `python -B bench.py alternate_validation.json replay_alternate.json`. Those plans retain the old primary source as their control. Development plans such as `tuning.json`, `validation.json`, `architecture_selection.json`, `macro_selection.json`, and `alternate_selection.json` can be replayed with the same two-argument benchmark command.

## Reading the evidence

* `holdout_results.csv` is the primary per-game table. `holdout_results.json` holds scores, cell counts, timing, and errors for all seats. `holdout_analysis.json` contains the designated bot's game-, group- and map-level summaries and intervals. Game plans list the lineup, map family, seed, seat and initial priority holder.
* `arena.py` implements the practice referee and mirrored map generators. `bench.py` gives every seat its own imported policy, calls the policy with the four public starter attributes and records fallback actions.
* Candidate source files, parameter lists, development game plans and result tables are included for comparison. Exploratory trial results may use different tie conventions. Use the designated-seat holdout analysis for the reported final rates.
* `official_snapshot.json` records the starter repository revision used for the interface. The official game server, entrant population and released map generator were unavailable. The fixed example and flat layouts serve as reference cases.
* `organizer_clarifications.json` records the answers relayed in the chat. `recovery_before.json` and `recovery_submission.json` show the old and updated recovery checks. `clarification_replay_summary.json` compares the complete 3,200-game replay after the fixes. `test_recovery.py` injects ignored shields, illegal actions, blocked departures and other substitutions while checking actual observed progress, scores and turn count.

All experiment paths in this copy are relative to this folder. The manifest records the original and portable plan fingerprints where applicable. The referee reconstructs the published rules for local research. The organisers adjudicate competition games.
