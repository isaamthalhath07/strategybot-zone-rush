import json
from pathlib import Path
j=json.loads(Path('work/tuning_results.json').read_text()); configs=json.loads(Path('work/candidates.json').read_text())
rows=sorted([(name,row) for name,row in j['summary'].items() if name in configs],key=lambda x:x[1]['pairwise'],reverse=True)
for name,row in rows[:12]: print(name, round(row['pairwise'],4),round(row['strict_first'],4),configs[name])
Path('work/top_candidates.json').write_text(json.dumps({name:configs[name] for name,row in rows[:4]},indent=2))
