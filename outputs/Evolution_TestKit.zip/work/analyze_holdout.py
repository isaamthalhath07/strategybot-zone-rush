"""Audit frozen fixtures and build a designated-seat report from real game records."""
import argparse
from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path
import random
import statistics

from arena import map_values


ROOT = Path(__file__).resolve().parent
RANDOM_FAMILIES = ("balanced", "patchy", "edge")
METRICS = ("strict_first", "first_share", "pairwise")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(data):
    return sha256(data).hexdigest()


def key(record):
    return (record["family"], record["seed"], record["lineup"],
            record["target_seat"], record["token"])


def audit_design(directory):
    path = directory / "holdout.json"
    plan = read_json(path)
    locked = read_json(directory / "holdout_lock.json")
    fixtures = plan["experiments"]
    assert len(fixtures) == locked["games"] == 3200
    outcomes = {key(row): row for row in fixtures}
    assert len(outcomes) == len(fixtures)
    hashes = {}
    for source, expected in locked["hashes"].items():
        file = Path(source)
        if not file.is_absolute():
            file = directory / file
        actual = digest(file.read_bytes())
        assert actual == expected, f"changed locked policy: {source}"
        hashes[file.name] = actual

    map_ids = {(x["family"], x["seed"]) for x in fixtures}
    maps = {m: digest(bytes(map_values(m[1], m[0]))) for m in map_ids}
    assert len(set(maps.values())) == len(maps) == 40
    actual_random = {m for m in maps if m[0] in RANDOM_FAMILIES}
    assert len(actual_random) == locked["synthetic_random_maps"] == 36
    assert len(maps) - len(actual_random) == locked["fixed_maps"] == 4
    development_maps = set()
    for filename in ("screening.json", "tuning.json", "validation.json",
                     "architecture_selection.json", "macro_selection.json"):
        config_path = directory / filename
        if not config_path.exists():
            continue
        earlier = read_json(config_path)
        for m in {(e["family"],e["seed"]) for e in earlier["experiments"]}:
            development_maps.add(digest(bytes(map_values(m[1], m[0]))))
    overlaps = sorted(m for m,hashval in maps.items() if hashval in development_maps)
    assert not any(m[0] in RANDOM_FAMILIES for m in overlaps), overlaps
    lineups = defaultdict(set)
    for row in fixtures:
        seat = row["target_seat"]
        assert 0 <= seat < 4 and row["bots"][seat] == row["target"] == "submission"
        lineups[row["lineup"]].add(tuple(sorted(
            name for i, name in enumerate(row["bots"]) if i != seat)))
    assert len(lineups) == 5 and all(len(x)==1 for x in lineups.values())
    assert all(count==80 for count in Counter((r["family"],r["seed"]) for r in fixtures).values())
    for family, seed in maps:
        for lineup in range(5):
            for seat in range(4):
                assert all((family, seed, lineup, seat, t) in outcomes for t in range(1,5))
    detail = {
        "plan_sha256": digest(path.read_bytes()),
        "locked_source_hashes": hashes,
        "fixtures": len(fixtures), "unique_maps": len(maps),
        "random_maps": len(actual_random), "fixed_maps": len(maps)-len(actual_random),
        "overlap_with_supplied_development_configs": overlaps,
        "lineups": {k: list(next(iter(v))) for k,v in lineups.items()},
        "map_hashes": {f"{m[0]}:{m[1]}": h for m,h in sorted(maps.items())},
    }
    return outcomes, detail


def rank_metrics(values, i):
    ours = values[i]
    wins = sum(ours > x for j, x in enumerate(values) if j != i)
    draws = sum(ours == x for j, x in enumerate(values) if j != i)
    above = 3-wins-draws
    return {"strict_first": int(wins == 3), "first_share": (1/(draws+1) if above == 0 else 0),
            "pairwise": (wins + .5*draws)/3, "wins": wins, "draws": draws, "losses": above,
            "top_two_share": min(1, max(0,(2-above)/(1+draws))),
            "strict_last": int(above == 3)}


def designated(row):
    i = row["target_seat"]
    assert row["bots"][i] == row["target"] == "submission"
    r1 = rank_metrics(row["scores"], i)
    assert all(abs(r1[k] - row[k][i]) < 1e-9 for k in METRICS)
    r2 = rank_metrics(list(zip(row["scores"], row["territory"])), i)
    return {**r1, "family": row["family"], "seed": row["seed"], "lineup": row["lineup"],
            "seat": i+1, "token": row["token"],
            "score": row["scores"][i],
            "errors": sum(e[1] == i + 1 for e in row["errors"]),
            "any_other_fallbacks": sum(e[1] != i + 1 for e in row["errors"]),
            "max_ms": row["latency_max_ms"][i], "mean_ms": row["latency_mean_ms"][i],
            "r2_pairwise": r2["pairwise"], "r2_first_share": r2["first_share"],
            "r2_strict_first": r2["strict_first"], "r2_top_two_share": r2["top_two_share"],
            "r2_draws": r2["draws"],
            "score_tie_games": int(r1["draws"] > 0),
            "cell_count_broke_tie": int(r1["draws"] > r2["draws"]),
            "cell_count_changed_strict_first": int(r1["strict_first"] != r2["strict_first"])}


def summarize(rows):
    total = len(rows)
    sums = ["wins","draws","losses","errors","strict_first","strict_last","score_tie_games",
            "cell_count_broke_tie","r2_draws","cell_count_changed_strict_first","any_other_fallbacks"]
    rates = [*METRICS,"top_two_share","score","r2_pairwise","r2_strict_first",
             "r2_first_share","r2_top_two_share","mean_ms"]
    return {"games":total, "pairwise_comparisons":total*3,
            **{k:statistics.mean(r[k] for r in rows) for k in rates},
            "counts":{k:sum(r[k] for r in rows) for k in sums},
            "max_ms":max(r["max_ms"] for r in rows)}


def by(rows, field):
    groups = defaultdict(list)
    for row in rows:
        groups[row[field]].append(row)
    return {k:summarize(v) for k,v in sorted(groups.items())}


def percent(xs, p):
    y = (len(xs)-1)*p
    i = int(y)
    return xs[i]+(y-i)*(xs[min(i+1,len(xs)-1)]-xs[i])


def uncertainty(rows, draws, paired=False):
    """Percentile 95% intervals; keep all 80 outcomes in each selected map."""
    blocks = defaultdict(list)
    for row in rows:
        blocks[(row["family"],row["seed"])].append(row)
    means = {m:[statistics.mean(r[k] for r in rs) for k in METRICS] for m,rs in blocks.items()}
    assert len(means)==36 and all(len(rs)==80 for rs in blocks.values())
    seeds = sorted({s for f,s in blocks})
    assert len(seeds)==12 and all((f,s) in means for f in RANDOM_FAMILIES for s in seeds)
    rng = random.Random(20261106)
    dist = [[] for _ in METRICS]
    for _ in range(draws):
        shared = rng.choices(seeds,k=12) if paired else None
        values = [means[(f,s)] for f in RANDOM_FAMILIES
                  for s in (shared if paired else rng.choices(seeds,k=12))]
        for i in range(len(METRICS)):
            dist[i].append(sum(v[i] for v in values)/36)
    ci = {}
    for k, values in zip(METRICS,dist):
        values.sort()
        ci[k] = [percent(values,.025),percent(values,.975)]
    return {"random_maps":36,"seeds":12,"bootstrap_draws":draws,"rng_seed":20261106,"95pct":ci}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--design-only", action="store_true")
    parser.add_argument("--draws",type=int,default=10000)
    args = parser.parse_args()
    fixtures, audit = audit_design(args.directory)
    if args.design_only:
        print(json.dumps({k:v for k,v in audit.items() if k!="map_hashes"},indent=2))
        return
    records = read_json(args.results or args.directory/"holdout_results.json")["records"]
    assert len(records)==len(fixtures)
    assert {key(r) for r in records}==set(fixtures)
    for r in records:
        plan = fixtures[key(r)]
        assert r["bots"]==plan["bots"] and r["target"]==plan["target"]
        assert not r["frozen_progress"]
    rows = [designated(r) for r in records]
    random_rows = [r for r in rows if r["family"] in RANDOM_FAMILIES]
    fixed_rows = [r for r in rows if r["family"] not in RANDOM_FAMILIES]
    direct = defaultdict(Counter)
    for record in records:
        seat = record["target_seat"]
        ours = record["scores"][seat]
        for j, (name, score) in enumerate(zip(record["bots"],record["scores"])):
            if seat != j:
                outcome = "wins" if ours > score else "losses" if ours < score else "draws"
                direct[name][outcome] += 1
    matchups = {name:{"wins":c["wins"],"draws":c["draws"],"losses":c["losses"],
                      "comparisons":c.total(),"pairwise":(c["wins"]+0.5*c["draws"])/c.total()}
                for name,c in sorted(direct.items())}
    report = {"design":audit,"all":summarize(rows),"random":summarize(random_rows),
              "fixed":summarize(fixed_rows),"family":by(rows,"family"),"lineup":by(rows,"lineup"),
              "seat":by(rows,"seat"),"token":by(rows,"token"),"random_lineup":by(random_rows,"lineup"),
              "fixed_map":by(fixed_rows,"seed"),"direct_opponent_counts":matchups,
              "lineup_within_family":{f:by([r for r in rows if r["family"]==f],"lineup")
                                      for f in sorted({r["family"] for r in rows})},
              "stratified_map_bootstrap":uncertainty(random_rows,args.draws),
              "paired_seed_sensitivity":uncertainty(random_rows,args.draws,paired=True)}
    output = args.output or args.directory/"holdout_analysis.json"
    output.write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps({k:report[k] for k in ("all","random","fixed","stratified_map_bootstrap",
                                             "paired_seed_sensitivity")},indent=2))


if __name__ == "__main__":
    main()
