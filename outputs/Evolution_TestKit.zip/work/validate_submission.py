"""Audit the exact submission against the public interface and reconstructed rules."""
import ast
import hashlib
import importlib.util
import inspect
import json
import platform
import statistics
import sys
from pathlib import Path
from time import perf_counter_ns
from types import SimpleNamespace

from arena import Game
from bench import load_policy

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "bot.py" if (ROOT / "bot.py").exists() else ROOT.parent / "outputs" / "bot.py"
ALLOWED_FIELDS = {"board", "bot_id", "is_priority_token", "legal_actions"}
sys.dont_write_bytecode = True


def new_module():
    spec = importlib.util.spec_from_file_location("submission_check", SOURCE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def public_input(observation):
    cells = [[SimpleNamespace(**cell._asdict()) for cell in row] for row in observation.board]
    return SimpleNamespace(board=cells, bot_id=observation.bot_id,
                           is_priority_token=observation.is_priority_token,
                           legal_actions=observation.legal_actions[:])


def snapshot(state):
    return (tuple(vars(state)), state.bot_id, state.is_priority_token,
            tuple(state.legal_actions),
            tuple(tuple(tuple(vars(cell).items()) for cell in row) for row in state.board))


def signature_check(module):
    parameter, = inspect.signature(module.act).parameters.values()
    assert parameter.name == "state" and parameter.default is parameter.empty
    assert parameter.kind is inspect.Parameter.POSITIONAL_OR_KEYWORD


def inspect_source():
    src = SOURCE.read_bytes()
    tree = ast.parse(src)
    modules = set()
    fields = set()
    rejected = {"__import__", "eval", "exec", "open", "compile", "globals", "locals"}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.update(item.name.split(".")[0] for item in node.names)
        elif isinstance(node, ast.ImportFrom):
            assert node.level == 0
            modules.add(node.module.split(".")[0])
        elif isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name):
            if node.value.id == "state":
                fields.add(node.attr)
        elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            assert node.func.id not in rejected
    assert modules <= sys.stdlib_module_names
    assert fields == ALLOWED_FIELDS
    signature_check(new_module())
    return {"sha256":hashlib.sha256(src).hexdigest(),"signature":"act(state)",
            "imports":sorted(modules),"state_attributes":sorted(fields)}


def time_summary(samples):
    ordered=sorted(x/1e6 for x in samples)
    return {"mean_ms":round(statistics.mean(ordered),4), "median_ms":round(statistics.median(ordered),4),
            "p99_ms":round(ordered[min(len(ordered)-1,int(len(ordered)*.99))],4),
            "max_ms":round(max(ordered),4)}


def run_group(cold, games):
    # Keep the selected module loaded across successive games in normal mode to
    # exercise its new-game detection for each seat as well as within-game memory.
    persistent = new_module()
    action_times, import_times, end_to_end = [], [], []
    calls=checked_progress=observed_resets=0
    points=firsts=0
    for game_no in range(games):
        seat = 1+game_no%4
        family=("balanced","patchy","flat","edge")[(game_no//4+seat-1)%4]
        game=Game(seed=121+game_no,family=family,start_token=1+(game_no//4)%4)
        policies=[load_policy(str(ROOT/"challengers.py"),name) for name in
                  ("fortress","adaptive","lure")]
        while game.turn<=80:
            state=public_input(game.state(seat))
            before=snapshot(state)
            started=perf_counter_ns()
            module=new_module() if cold else persistent
            ready=perf_counter_ns()
            action=module.act(state)
            ended=perf_counter_ns()
            elapsed=ended-started
            assert elapsed < (2_000_000_000 if game.turn==1 else 200_000_000)
            assert isinstance(action,str) and action in state.legal_actions
            assert snapshot(state)==before
            calls+=1
            action_times.append(ended-ready)
            end_to_end.append(elapsed)
            if cold:
                import_times.append(ready-started)
            memory=module._history[seat]
            if not cold:
                assert memory["turn"]==game.turn and memory["known_start"]
                assert memory["scores"][1:]==game.scores
                pos=game.pos[seat-1]
                current_owner=game.owner[pos]
                actionable=(current_owner==seat and not game.upgraded[pos]) or (
                    current_owner!=seat and not state.board[pos//8][pos%8].is_home)
                if actionable:
                    assert memory["progress"]==game.progress[seat-1]
                    checked_progress+=1
                if game.turn==1:
                    observed_resets+=1
            actions=[]
            remaining=iter(policies)
            for s in range(1,5):
                actions.append(action if s==seat else next(remaining)(game.state(s)))
            game.step(actions)
        score=game.scores[seat-1]
        points+=sum((score>v)+.5*(score==v) for i,v in enumerate(game.scores) if i!=seat-1)
        firsts+=int(all(score>v for i,v in enumerate(game.scores) if i!=seat-1))
    result={"games":games,"calls":calls,"illegal":0,"exceptions":0,"input_mutations":0,
            "deadline_misses":0,"act_duration":time_summary(action_times),
            "entry_plus_action":time_summary(end_to_end),"pairwise":points/(3*games),
            "strict_firsts":firsts}
    if cold:
        result["fresh_module_imports"]=calls
        result["import_duration"]=time_summary(import_times)
    else:
        result.update(score_vectors_verified=calls,turn_numbers_verified=calls,
                      actionable_progress_checks=checked_progress, game_starts_verified=observed_resets)
    return result


if __name__=="__main__":
    report={"status":"pass","python":platform.python_version(),"source":inspect_source(),
            "persistent":run_group(False,12),"fresh_module_every_call":run_group(True,16)}
    report["paired_persistent_reference"] = run_group(False, 16)
    target=ROOT/"submission_validation.json"
    target.write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
