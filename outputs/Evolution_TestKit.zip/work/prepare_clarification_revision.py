import hashlib,json
from pathlib import Path
root=Path('work'); out=Path('outputs')
# Preserve the original frozen evidence and its exact source.
for old,new in [('holdout_results.json','pre_clarification_results.json'),('holdout_lock.json','pre_clarification_lock.json'),('holdout.json','pre_clarification_plan.json'),('holdout_analysis.json','pre_clarification_analysis.json'),('submission_validation.json','pre_clarification_validation.json')]:
 target=root/new
 if not target.exists(): target.write_bytes((root/old).read_bytes())
old_plan=json.loads((root/'pre_clarification_plan.json').read_text())
old_plan['policies']['submission']['path']=str((root/'bot_audited.py').resolve())
(root/'pre_clarification_plan.json').write_text(json.dumps(old_plan,indent=2))
old_lock=json.loads((root/'pre_clarification_lock.json').read_text())
old_lock['hashes']={str((root/'bot_audited.py').resolve()) if Path(k).name=='bot.py' else k:v for k,v in old_lock['hashes'].items()}
(root/'pre_clarification_lock.json').write_text(json.dumps(old_lock,indent=2))
# Historical counterfactual comparisons retain their original opponent source.
for name in ['freeze_sensitivity.json','alternate_selection.json','alternate_validation.json']:
 p=root/name; plan=json.loads(p.read_text())
 plan['policies']['submission']['path']=str((root/'bot_audited.py').resolve())
 p.write_text(json.dumps(plan,indent=2))
source=(root/'bot_recovery.py').read_text(encoding='utf-8')
source=source.replace('The official server and its execution lifecycle still require validation.',
 'Organisers confirmed that frozen stays earn no progress and memory is allowed.\nMemory follows observed outcomes after blocked moves or server STAY fallbacks.\nOfficial server compatibility remains to be checked by the organisers.')
(out/'bot.py').write_text(source,encoding='utf-8')
digest=hashlib.sha256((out/'bot.py').read_bytes()).hexdigest()
lock=json.loads((root/'holdout_lock.json').read_text())
lock['hashes']={k:digest if Path(k).name=='bot.py' else v for k,v in lock['hashes'].items()}
(root/'holdout_lock.json').write_text(json.dumps(lock,indent=2))
(root/'clarification_revision.json').write_text(json.dumps({'status':'frozen before replay','sha256':digest,'previous_sha256':hashlib.sha256((root/'bot_audited.py').read_bytes()).hexdigest(),'changes':['Reconcile own shield execution using next legal actions','Count server substituted stays from observed state','Avoid false game reset on reversible opening positions'],'organiser_clarifications':'organizer_clarifications.json'},indent=2))
print('Updated primary source',digest)
