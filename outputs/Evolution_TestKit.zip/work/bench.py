"""Reproducible local experiments. Uses only documented bot observations."""
import argparse
import csv
import importlib.util
import itertools
import json
import math
from pathlib import Path
import random
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def load_policy(path, name="act", config=None):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    spec = importlib.util.spec_from_file_location("isolated_bot", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    if config:
        for key, value in config.items():
            setattr(module, key, value)
    if name == "act":
        return module.act
    return module.POLICIES[name]


def evaluate_game(specs, seed, family, token, frozen_progress=False):
    from arena import Game
    game = Game(seed=seed, family=family, start_token=token,
                frozen_stays_progress=frozen_progress)
    policies = [load_policy(**item) for item in specs]
    durations = [[] for _ in range(4)]
    errors = []
    actions_log = []
    while game.turn <= 80:
        actions = []
        for seat, policy in enumerate(policies, 1):
            state = game.state(seat)
            started = time.perf_counter()
            try:
                action = policy(state)
                elapsed = time.perf_counter() - started
                if action not in state.legal_actions:
                    raise ValueError(f"Illegal action {action!r}")
                if elapsed > (2.0 if game.turn == 1 else 0.2):
                    raise TimeoutError("Exceeded official per-turn limit")
            except Exception as error:
                elapsed = time.perf_counter() - started
                errors.append([game.turn, seat, repr(error)])
                action = "STAY"
            durations[seat - 1].append(elapsed * 1000)
            actions.append(action)
        actions_log.append(actions)
        game.step(actions)
    final_cells = [cell for row in game.state(1).board for cell in row]
    territory = [sum(cell.owner == seat for cell in final_cells) for seat in range(1, 5)]
    result = {"seed": seed, "family": family, "token": token,
              "frozen_progress": frozen_progress,
              "bots": [item.get("label", item.get("name", "act")) for item in specs],
              "scores": list(game.scores), "territory": territory, "errors": errors,
              "latency_max_ms": [max(values) for values in durations],
              "latency_mean_ms": [statistics.mean(values) for values in durations]}
    result["pairwise"] = [sum((score > other) + 0.5 * (score == other)
                              for j, other in enumerate(game.scores) if j != i) / 3
                          for i, score in enumerate(game.scores)]
    result["first_share"] = [float(score == max(game.scores)) /
                             game.scores.count(max(game.scores)) for score in game.scores]
    result["strict_first"] = [int(score > max(other for j, other in
                                              enumerate(game.scores) if j != i))
                              for i, score in enumerate(game.scores)]
    result["top_two"] = [int(sum(other > score for other in game.scores) < 2)
                         for score in game.scores]
    return result


def clean_spec(spec):
    return {key: value for key, value in spec.items() if key in {"path", "name", "config"}}


def run_game(specs, **kwargs):
    labels = [item.get("label", item.get("name", "act")) for item in specs]
    result = evaluate_game([clean_spec(item) for item in specs], **kwargs)
    result["bots"] = labels
    return result


def summarize(records, target=None):
    stats = {}
    for record in records:
        for seat, label in enumerate(record["bots"]):
            if target and label != target:
                continue
            row = stats.setdefault(label, {"pairwise": [], "strict_first": [],
                                          "first_share": [], "top_two": [],
                                          "scores": [], "latency_max_ms": [],
                                          "latency_mean_ms": [], "errors": 0})
            for key in ["pairwise", "strict_first", "first_share", "top_two", "scores",
                        "latency_max_ms", "latency_mean_ms"]:
                row[key].append(record[key][seat])
            row["errors"] += sum(error[1] == seat + 1 for error in record["errors"])
    result = {}
    for label, row in stats.items():
        result[label] = {"games": len(row["scores"]),
                         **{key: statistics.mean(row[key]) for key in
                            ["pairwise", "strict_first", "first_share", "top_two", "scores",
                             "latency_mean_ms"]},
                         "latency_max_ms": max(row["latency_max_ms"]),
                         "errors": row["errors"]}
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("config", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    records = []
    started = time.perf_counter()
    for index, experiment in enumerate(config["experiments"]):
        specs = [config["policies"][name] | {"label": name} for name in experiment["bots"]]
        record = run_game(specs, seed=experiment["seed"], family=experiment["family"],
                          token=experiment["token"],
                          frozen_progress=experiment.get("frozen_progress", False))
        for key in ("target", "target_seat", "lineup"):
            if key in experiment:
                record[key] = experiment[key]
        records.append(record)
        if (index + 1) % 20 == 0:
            print(f"{index + 1}/{len(config['experiments'])} games in "
                  f"{time.perf_counter() - started:.1f}s", flush=True)
    args.output.write_text(json.dumps({"records": records, "summary": summarize(records),
                                      "elapsed_seconds": time.perf_counter() - started}, indent=2))
    print(json.dumps(summarize(records), indent=2), flush=True)


if __name__ == "__main__":
    main()
