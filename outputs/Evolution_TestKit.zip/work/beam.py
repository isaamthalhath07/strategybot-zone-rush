"""Zone Rush action-level beam search. The entry point uses the public starter interface."""
from heapq import nlargest

WIDTH = 14
DEPTH = 10
DISCOUNT = .93
UPGRADE = 1.14
RAID = .84
DEFENSE = 1.0
BITS = tuple(1 << j for j in range(64))
DIST = tuple(tuple(abs(i // 8 - j // 8) + abs(i % 8 - j % 8)
                   for j in range(64)) for i in range(64))


def _neighbors(i):
    r, c = divmod(i, 8)
    return tuple((j, a) for j, a, valid in (
        (i - 8, "NORTH", r > 0), (i + 1, "EAST", c < 7),
        (i + 8, "SOUTH", r < 7), (i - 1, "WEST", c > 0)) if valid)


ADJ = tuple(_neighbors(i) for i in range(64))
MEM = {}


def _remember(state, cells, pos):
    me = state.bot_id
    origin = pos[me]
    own = tuple(c.owner for c in cells)
    levels = tuple(c.is_upgraded for c in cells)
    frozen = [False] + [cells[pos[s]].is_frozen for s in range(1, 5)]
    pristine = all(c.is_home or not c.owner for c in cells) and all(cells[p].is_home for p in pos[1:])
    old = MEM.get(me)
    if old is None or (pristine and (old["turn"] >= 80 or not old["pristine"])):
        old = {"turn": 1, "progress": 0, "cool": [0]*5, "tries": [0]*5,
               "stops": [0]*5, "score": [0]*5, "intrusions": [0]*5, "persist": [0]*5}
    else:
        old["turn"] = min(80, old["turn"] + 1)
        oldown, oldpos, oldlevel = old["own"], old["pos"], old["levels"]
        old["progress"] = (min(2, old["progress"] + 1)
                           if origin == oldpos[me] and oldown[origin] == own[origin]
                           and oldlevel[origin] == levels[origin] and old["action"] != "SHIELD"
                           and not frozen[me] and not old["frozen"][me] else 0)
        eligible, seen = set(), set()
        for s in range(1, 5):
            i = oldpos[s]
            defender = oldown[i]
            if (defender and defender != s and not old["frozen"][s]
                    and not old["frozen"][defender] and old["cool"][defender] == 0):
                eligible.add(defender)
                old["intrusions"][s] += 1
                old["persist"][s] += pos[s] == i and s not in seen
                if (pos[s] == i and frozen[s] and oldpos[defender] == pos[defender]
                        and not frozen[defender]):
                    seen.add(defender)
            if (pos[s] == i and not old["frozen"][s] and frozen[s] and defender in (0, s)):
                seen.add(s)
        old["cool"] = [4 if s in seen else max(0, previous-1) for s, previous in enumerate(old["cool"])]
        for s in eligible:
            old["tries"][s] += 1
            old["stops"][s] += s in seen
        for i, owner in enumerate(own):
            if owner:
                old["score"][owner] += cells[i].base_points * (1+levels[i])
                if oldown[i] and oldown[i] != owner:
                    old["score"][owner] += 8 * cells[i].base_points * (1+oldlevel[i])
    old.update(pristine=pristine, pos=pos, own=own, levels=levels, frozen=frozen)
    MEM[me] = old
    return old


def act(state):
    me = state.bot_id
    cells = [c for row in state.board for c in row]
    pos = [0]*5
    for i, cell in enumerate(cells):
        if cell.occupant:
            pos[cell.occupant] = i
    memory = _remember(state, cells, pos)
    if len(state.legal_actions) == 1:
        memory["action"] = state.legal_actions[0]
        return memory["action"]
    answer = _search(state, cells, pos, memory)
    memory["action"] = answer
    return answer


def _search(state, cells, pos, memory):
    me = state.bot_id
    legal = set(state.legal_actions)
    left = 81 - memory["turn"]
    depth = min(left, DEPTH)
    start = pos[me]
    rivals = [s for s in range(1, 5) if s != me]
    occupied = {pos[s] for s in rivals}
    pressure = [min(DIST[p][i] for p in occupied) for i in range(64)]
    p_shield = [(1.6 + memory["stops"][s]) / (3.2 + memory["tries"][s]) for s in range(5)]
    base = [c.base_points for c in cells]
    own = memory["own"]
    lvl = memory["levels"]
    init_own = sum(BITS[i] for i in range(64) if own[i] == me)
    init_upgrade = sum(BITS[i] for i in range(64) if own[i] == me and lvl[i])
    captures = [0.0]*64
    upgrades = [0.0]*64
    work = [1]*64
    denied = [.0]*5
    for s in rivals:
        gap = abs(memory["score"][me]-memory["score"][s])
        denied[s] = .25 + .40/(1+gap/(35+left*5))
    for i, c in enumerate(cells):
        v = base[i]
        # Estimate the productive lifetime of a new level-one holding, then the
        # longer life of an upgraded cell that takes three stays to steal.
        horizon = max(1, left-1)
        normal = min(horizon, 17 + 2.7*pressure[i])
        fortified = min(horizon, 28 + 3.6*pressure[i])
        if c.is_home:
            fortified = horizon
            normal = horizon
        upgrades[i] = v*UPGRADE*(fortified + .48*(fortified-normal))
        if own[i] == me or c.is_home:
            continue
        captures[i] = v*normal
        if own[i]:
            s = own[i]
            level = 1+lvl[i]
            work[i] = 3 if lvl[i] else 1
            captures[i] = RAID*v*(normal + level*(8+denied[s]*normal))
    # All moves and captures are simulated one action at a time. A small
    # potential directs partial paths toward points they can finish next.
    shortlist = []
    for i in range(64):
        values = []
        for j in range(64):
            if DIST[i][j] > 4 or (cells[j].is_home and own[j] != me) or (own[j] == me and lvl[j]):
                continue
            value = upgrades[j] if own[j] == me else captures[j]
            cost = 3 if own[j] == me else work[j]
            values.append((value/(DIST[i][j]+cost), j))
        shortlist.append(tuple(j for _, j in nlargest(4, values)))

    def potential(i, progress, owned, upgraded):
        best = 0.
        for j in shortlist[i]:
            bit = BITS[j]
            if upgraded & bit:
                continue
            ours = owned & bit
            cost = (3 if ours else work[j]) + DIST[i][j] - (progress if i == j else 0)
            estimate = (upgrades[j] if ours else captures[j]) / max(1, cost)
            if estimate > best:
                best = estimate
        # Give partial captures and upgrades credit even on newly held cells.
        if owned & BITS[i] and not upgraded & BITS[i]:
            best = max(best, upgrades[i]/(3-progress))
        return best

    shield_value = 0.
    if "SHIELD" in legal:
        miss = 1.
        for s in rivals:
            i = pos[s]
            if own[i] == me and not cells[i].is_frozen and not cells[i].is_home:
                catch = (2.4 + memory["persist"][s]) / (3.2 + memory["intrusions"][s])
                miss *= 1-catch
                shield_value += catch*(base[i]*(1+lvl[i])*(min(left, 9) + 8*denied[s])
                                        + min(3, left)*3*denied[s])
        shield_value = shield_value*DEFENSE - 2*miss*min(left, 8)

    # A node stores its exact hypothetical ownership, upgrades and stay progress.
    # Dominance is by cumulative reward at identical state and simulated time.
    frontier = [(0., start, memory["progress"], init_own, init_upgrade, "STAY")]
    for step in range(1, depth+1):
        layer = {}
        discount = DISCOUNT**(step-1)
        remaining = left-step+1
        for reward, i, progress, owned, upgraded, first in frontier:
            bit = BITS[i]
            candidates = []
            ours = owned & bit
            if not upgraded & bit and (ours or (captures[i] and not cells[i].is_home)):
                cost = 3 if ours else work[i]
                risk = (p_shield[own[i]] if not ours and own[i]
                        and memory["cool"][own[i]] < step + cost-progress-1 else 0.)
                if progress+1 >= cost:
                    if ours:
                        gain = min(upgrades[i], UPGRADE*base[i]*remaining)
                        candidates.append((i, 0, owned, upgraded | bit, "STAY", gain))
                    else:
                        maxgain = remaining*base[i]
                        if own[i]:
                            maxgain += (1+lvl[i])*base[i]*(8+denied[own[i]]*remaining)
                        gain = min(captures[i], maxgain) * (1-risk*(.95 if lvl[i] else .54))
                        candidates.append((i, 0, owned | bit, upgraded, "STAY", gain))
                else:
                    candidates.append((i, progress+1, owned, upgraded, "STAY", -risk*6))
            if step == 1 and shield_value > 0:
                candidates.append((i, 0, owned, upgraded, "SHIELD", shield_value))
            for j, action in ADJ[i]:
                if (step <= 2 and j in occupied) or (step == 1 and action not in legal):
                    continue
                penalty = 0.
                if step == 1 and pressure[j] == 1 and own[j] != me and not state.is_priority_token:
                    penalty = 4.
                candidates.append((j, 0, owned, upgraded, action, -penalty))
            if not candidates:
                candidates.append((i, 0, owned, upgraded, "STAY", 0.))
            for j, pr, o, u, act0, increment in candidates:
                total = reward+discount*increment
                key = (j, pr, o, u)
                prior = layer.get(key)
                if prior is None or total > prior[0]:
                    layer[key] = (total, j, pr, o, u, act0 if step == 1 else first)
        horizon_weight = (.78 if step < depth else .50) if step < left else 0.
        def rank(item):
            score,j,pr,o,u,_ = item
            return score + horizon_weight*discount*potential(j, pr, o, u)
        frontier = nlargest(WIDTH, layer.values(), key=rank)
    return frontier[0][-1] if frontier else "STAY"
