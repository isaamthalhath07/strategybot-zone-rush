"""Verify evidence hashes and replay one full match per rules profile."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

from arena import Game
from bench import load_policy


ROOT = Path(__file__).resolve().parent


def main():
    manifest = json.loads((ROOT/"EVIDENCE_MANIFEST.json").read_text(encoding="utf-8"))
    for name, expected in manifest["file_sha256"].items():
        if sha256((ROOT/name).read_bytes()).hexdigest() != expected:
            raise ValueError(f"Evidence differs: {name}")
    print(f"Verified SHA-256 for {len(manifest['file_sha256'])} files.", flush=True)
    for name in ("test_arena.py","test_terminal.py"):
        subprocess.run([sys.executable, "-B", str(ROOT/name)], cwd=ROOT, check=True)
    subprocess.run([sys.executable, "-B", str(ROOT/"test_recovery.py"),
                    "--bot", str(ROOT/"bot.py")], cwd=ROOT, check=True)
    for name, alternate in (("bot.py",False),("bot_frozen_progress.py",True)):
        game = Game(seed=1000, family="balanced", start_token=3, frozen_stays_progress=alternate)
        policies = [load_policy(name)] + [load_policy("challengers.py",n)
                                          for n in ("fortress","lure","adaptive")]
        while game.turn<=80:
            actions = []
            for seat, policy in enumerate(policies,1):
                state = game.state(seat)
                action = policy(state)
                if action not in state.legal_actions:
                    raise ValueError(f"{name}: illegal action at turn {game.turn}")
                actions.append(action)
            game.step(actions)
        print(f"Replayed {name} for 80 turns. Final scores {game.scores}.")


if __name__ == "__main__":
    main()
