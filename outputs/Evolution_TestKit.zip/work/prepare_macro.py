import json
from pathlib import Path
j=json.loads(Path('work/validation.json').read_text())
j['policies']['macro_beam']={'path':str(Path('work/planner_beam.py').resolve()),'config':{'RAID_WEIGHT':.7,'UPGRADE_WEIGHT':1.8,'DEFENSE_WEIGHT':.8}}
base=[e for e in j['experiments'] if 'learned_tuned' in e['bots']]
j['experiments']=[e | {'bots':['macro_beam' if n=='learned_tuned' else n for n in e['bots']]} for e in base]
Path('work/macro_selection.json').write_text(json.dumps(j,indent=2))
