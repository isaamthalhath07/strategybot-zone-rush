import hashlib,json
from pathlib import Path
root=Path('work'); old=json.loads((root/'pre_clarification_results.json').read_text())['records']; new=json.loads((root/'holdout_results.json').read_text())['records']
assert len(old)==len(new)==3200
fields=['scores','territory','bots','strict_first','pairwise','errors','target','target_seat']
changes=[i for i,(a,b) in enumerate(zip(old,new)) if any(a[k]!=b[k] for k in fields)]
recovery=json.loads((root/'recovery_submission.json').read_text()); checks=recovery['full_games']['checks']
text=('After the organiser clarification, two recovery bugs were corrected. A requested SHIELD that the server substitutes with STAY now earns the progress actually observed. A reversible opening in which all bots leave and return home preserves the turn count. The updated source passes eight recovery regressions. Across 40 full games with 765 injected own/rival action substitutions, all 3,200 turn and score observations and 2,387 actionable progress checks matched the referee. The older version had failed three of those tests, including 64 progress mismatches. The strategy weights were preserved. A complete replay of the original 3,200 audit fixtures produced '+str(len(new)-len(changes))+' matching final scoreboards, territory counts and rank outcomes, with zero bot faults. These fixtures had already been used in the original audit, and this replay checks regression after the memory fixes. The original source and evidence remain in the test kit as bot_audited.py and pre_clarification_* records. Server compatibility is still to be checked by the organisers.')
summary={'games':3200,'matching_outcomes':3200-len(changes),'changed_indices':changes,'compared_fields':fields,'source_sha256':hashlib.sha256(Path('outputs/bot.py').read_bytes()).hexdigest(),'recovery_tests':8,'fault_substitutions':765,'recovery_callbacks':3200,'progress_checks':2387,'report_text':text}
(root/'clarification_replay_summary.json').write_text(json.dumps(summary,indent=2))
p=root/'clarification_revision.json'; revision=json.loads(p.read_text()); revision['status']='passed recovery tests and complete benchmark replay'; p.write_text(json.dumps(revision,indent=2))
p=root/'selection_lock.json'; selection=json.loads(p.read_text()); selection['source_file']='bot_audited.py'; selection['current_revision']='bot.py'; selection['current_sha256']=summary['source_sha256']; p.write_text(json.dumps(selection,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='report_text'},indent=2))
