import hashlib,json
from pathlib import Path
p=Path('work/evolution/evolve_transfer.py'); run=Path('work/evolution/runs/transfer_001')
s=p.read_text(encoding='utf-8'); marker='        manifest_path = self.directory / "manifest.json"'; assert marker in s
s=s.replace(marker,'        self.manifest = json.loads(json.dumps(self.manifest))\n'+marker,1); p.write_text(s,encoding='utf-8')
manifest=run/'manifest.json'; j=json.loads(manifest.read_text()); j['source_hashes'][str(p.resolve())]=hashlib.sha256(p.read_bytes()).hexdigest(); manifest.write_text(json.dumps(j,indent=2))
(run/'state_before_repair.json').write_bytes((run/'state.json').read_bytes())
note=json.loads((run/'training_repair.json').read_text()); note['resume_fix']='Normalize JSON tuple/list representation before comparing an existing metadata manifest.'; note['driver_after_sha256']=hashlib.sha256(p.read_bytes()).hexdigest(); (run/'training_repair.json').write_text(json.dumps(note,indent=2))
# New generated transfer drivers also carry both corrections.
b=Path('work/evolution/build_transfer.py'); s=b.read_text(encoding='utf-8'); marker='compile(source, "evolve_transfer.py", "exec")'
s=s.replace(marker,'source = source.replace(\'                    tough = response_ids[-2:] or self.archive[-2:]\\n\', \'                    tough = response_ids[-2:] or self.archive[-2:]\\n                    if len(tough) == 1:\\n                        tough = tough * 2\\n\')\nsource = source.replace(\'        manifest_path = self.directory / "manifest.json"\', \'        self.manifest = json.loads(json.dumps(self.manifest))\\n        manifest_path = self.directory / "manifest.json"\')\n'+marker,1); compile(s,str(b),'exec'); b.write_text(s,encoding='utf-8')
print('Manifest normalized; policy sources preserved')
