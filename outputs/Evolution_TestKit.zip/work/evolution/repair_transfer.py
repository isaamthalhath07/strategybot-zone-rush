import hashlib,json
from pathlib import Path
p=Path('work/evolution/evolve_transfer.py'); run=Path('work/evolution/runs/transfer_001')
backup=run/'driver_before_repair.py'; backup.write_bytes(p.read_bytes())
manifest=run/'manifest.json'; (run/'manifest_before_repair.json').write_bytes(manifest.read_bytes())
s=p.read_text(encoding='utf-8'); old='                    tough = response_ids[-2:] or self.archive[-2:]\n'; new=old+'                    if len(tough) == 1:\n                        tough = tough * 2\n'; assert old in s; s=s.replace(old,new,1); p.write_text(s,encoding='utf-8')
j=json.loads(manifest.read_text()); j['source_hashes'][str(p.resolve())]=hashlib.sha256(p.read_bytes()).hexdigest(); manifest.write_text(json.dumps(j,indent=2))
(run/'training_repair.json').write_text(json.dumps({'reason':'A single saved response gave a two-opponent polish lineup; repeat that independent response policy to supply three opponents.','completed_cached_games_retained':4704,'policy_or_referee_sources_changed':False,'driver_before_sha256':hashlib.sha256(backup.read_bytes()).hexdigest(),'driver_after_sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2))
# Verify every single-response and multi-response case has exactly three opponents.
for ids in [['responseA'],['responseA','responseB']]:
 tough=ids[-2:]
 if len(tough)==1:tough=tough*2
 assert len([*tough,'macro'])==3
print('Repaired one-response schedule and retained cached completed games')
