import hashlib,json
from pathlib import Path
p=Path('work/evolution/evolve_transfer.py'); s=p.read_text(encoding='utf-8')
old='    temporary.replace(path)\n'; new='    for attempt in range(25):\n        try:\n            temporary.replace(path)\n            return\n        except PermissionError:\n            if attempt == 24:\n                raise\n            time.sleep(0.02)\n'; assert old in s; s=s.replace(old,new,1); p.write_text(s,encoding='utf-8')
run=Path('work/evolution/runs/transfer_001'); q=run/'manifest.json'; j=json.loads(q.read_text()); j['source_hashes'][str(p.resolve())]=hashlib.sha256(p.read_bytes()).hexdigest(); q.write_text(json.dumps(j,indent=2))
note=json.loads((run/'training_repair.json').read_text()); note['windows_file_lock_fix']='Retry atomic checkpoint replacement when a concurrent progress reader briefly holds a Windows file handle.'; note['driver_after_sha256']=hashlib.sha256(p.read_bytes()).hexdigest(); (run/'training_repair.json').write_text(json.dumps(note,indent=2))
# Keep future transfer generation reproducible without changing the original frozen driver.
b=Path('work/evolution/build_transfer.py'); s=b.read_text(encoding='utf-8'); marker='compile(source, "evolve_transfer.py", "exec")'
s=s.replace(marker,'source = source.replace('+repr(old)+', '+repr(new)+', 1)\n'+marker,1); compile(s,str(b),'exec'); b.write_text(s,encoding='utf-8')
