"""Reproducible island evolution and an archive of self-interested responses."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import gzip
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import random
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent))
from arena import Game

COMPILED = {}
FAMILY_PATHS = {"economic": ROOT / "economic.py", "user_route": ROOT / "user_family.py",
                "action_beam": ROOT / "action_beam.py"}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(path)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def metadata(path):
    spec = importlib.util.spec_from_file_location("policy_metadata", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return {"default": module.DEFAULT_CONFIG, "bounds": module.BOUNDS,
            "integers": sorted(getattr(module, "INTEGER_GENES", set()))}


def policy(spec):
    path = str(Path(spec["path"]).resolve())
    if path not in COMPILED:
        COMPILED[path] = compile(Path(path).read_text(encoding="utf-8-sig"), path, "exec")
    namespace = {"__name__": "evolution_policy", "__file__": path}
    exec(COMPILED[path], namespace)
    if spec.get("config_style") == "dict":
        namespace["CONFIG"] = dict(spec["config"])
    else:
        namespace.update(spec.get("config", {}))
    player = namespace["POLICIES"][spec["name"]] if "name" in spec else namespace["act"]
    if "Agent" not in namespace:
        return player
    caught = []
    original = namespace["Agent"].decide
    def audited_decide(agent, state):
        try:
            return original(agent, state)
        except Exception as error:
            caught.append(repr(error))
            raise
    namespace["Agent"].decide = audited_decide
    def audited_player(state):
        action = player(state)
        if caught:
            message = caught.pop(0)
            caught.clear()
            raise RuntimeError("Policy suppressed an internal exception: " + message)
        return action
    return audited_player


def game_row(target, registry, fixture):
    ids = fixture["opponents"][:]
    ids.insert(fixture["seat"], target)
    policies = [policy(registry[name]) for name in ids]
    game = Game(seed=fixture["seed"], family=fixture["family"], start_token=fixture["token"])
    faults = []
    maximum = [0.0] * 4
    elapsed_sum = [0.0] * 4
    while game.turn <= 80:
        actions = []
        for seat, player in enumerate(policies, 1):
            state = game.state(seat)
            start = time.perf_counter()
            try:
                action = player(state)
                duration = time.perf_counter() - start
                if action not in state.legal_actions:
                    raise ValueError(f"Illegal action {action!r}")
                if duration > (2.0 if game.turn == 1 else 0.2):
                    raise TimeoutError("Turn deadline exceeded")
            except Exception as error:
                duration = time.perf_counter() - start
                faults.append([game.turn, seat, repr(error)])
                action = "STAY"
            maximum[seat - 1] = max(maximum[seat - 1], duration * 1000)
            elapsed_sum[seat - 1] += duration * 1000
            actions.append(action)
        game.step(actions)
    scores = list(game.scores)
    credit = [sum((value > other) + 0.5 * (value == other)
                  for j, other in enumerate(scores) if i != j) / 3
              for i, value in enumerate(scores)]
    first = [int(value > max(other for j, other in enumerate(scores) if i != j))
             for i, value in enumerate(scores)]
    fraction = [float(value == max(scores)) / scores.count(max(scores)) for value in scores]
    territory = [game.owner.count(seat) for seat in range(1, 5)]
    return {"target": target, "target_seat": fixture["seat"], "family": fixture["family"],
            "seed": fixture["seed"], "token": fixture["token"], "lineup": fixture["lineup"],
            "bots": ids, "scores": scores, "territory": territory, "pairwise": credit,
            "strict_first": first, "first_share": fraction, "errors": faults,
            "latency_max_ms": maximum, "latency_mean_ms": [value / 80 for value in elapsed_sum],
            "frozen_progress": False}


def evaluate_job(job):
    target, registry, fixtures, cache_path = job
    cache_path = Path(cache_path)
    if cache_path.exists():
        with gzip.open(cache_path, "rt", encoding="utf-8") as stream:
            return target, json.load(stream), True
    rows = [game_row(target, registry, fixture) for fixture in fixtures]
    temporary = cache_path.with_suffix(".tmp")
    with gzip.open(temporary, "wt", encoding="utf-8") as stream:
        json.dump(rows, stream)
    temporary.replace(cache_path)
    return target, rows, False


def summary(rows):
    def average(key, subset):
        return statistics.mean(row[key][row["target_seat"]] for row in subset)
    groups = {name: [row for row in rows if row["lineup"] == name]
              for name in {row["lineup"] for row in rows}}
    pairs = average("pairwise", rows)
    tail = min(average("pairwise", group) for group in groups.values())
    wins = average("strict_first", rows)
    own_faults = sum(error[1] == row["target_seat"] + 1 for row in rows for error in row["errors"])
    return {"games": len(rows), "pairwise": pairs, "worst_lineup": tail,
            "strict_first": wins, "first_share": average("first_share", rows),
            "fitness": 0.78 * pairs + 0.20 * tail + 0.02 * wins - 10 * own_faults / len(rows),
            "own_faults": own_faults,
            "max_ms": max(row["latency_max_ms"][row["target_seat"]] for row in rows)}


def fixture_panel(generation, lineups, base_seed):
    early, complete = [], []
    for family_index, family in enumerate(("balanced", "patchy", "edge")):
        for map_index, lineup, seat, token_index in itertools.product(range(2), range(2), range(4), range(2)):
            seed = base_seed + 100 * generation + map_index
            token = 1 + (generation + lineup + seat + 2 * token_index) % 4
            rivals = lineups[lineup][:]
            random.Random(seed * 100 + seat * 10 + token).shuffle(rivals)
            fixture = {"family": family, "seed": seed, "lineup": lineup, "seat": seat,
                       "token": token, "opponents": rivals}
            complete.append(fixture)
            if map_index == 0 and token_index == 0:
                early.append(fixture)
    return early, complete


class Evolution:
    def __init__(self, args):
        self.args = args
        self.directory = args.directory.resolve()
        self.directory.mkdir(parents=True, exist_ok=True)
        (self.directory / "cache").mkdir(exist_ok=True)
        self.metadata = {name: metadata(path) for name, path in FAMILY_PATHS.items()}
        self.metadata["economic"]["default"] = {'backfire_cost': 1.13552,
 'breadth': 7,
 'cash_weight': 1.25275,
 'contest_cost': 0.42039,
 'denial_base': 0.66671,
 'denial_close': 0.20084,
 'depth': 2,
 'feint_weight': 1.25119,
 'fortify_premium': 1.11474,
 'income_lifetime': 40.67114,
 'inertia': 0.0496,
 'raid_late': 1.64117,
 'raid_open': 0.95839,
 'risk_late': 8.0,
 'risk_open': 1.97775,
 'route_delay': 0.02,
 'route_weight': 0.61979,
 'safety_slope': 3.52153,
 'shield_prior': 0.33333,
 'shield_weight': 1.30296,
 'stay_prior': 0.76,
 'upgrade_late': 3.3705,
 'upgrade_open': 1.46008}
        self.rng = random.Random(args.seed)
        self.registry = {
            "incumbent": {"path": str(ROOT / "evolved_reference.py")},
            "fortress": {"path": str(ROOT.parent / "challengers.py"), "name": "fortress"},
            "lure": {"path": str(ROOT.parent / "challengers.py"), "name": "lure"},
            "macro": {"path": str(ROOT.parent / "comparison" / "user_snapshot_001" / "bot.py")},
            "old_adaptive": {"path": str(ROOT.parent / "comparison" / "user_corrected.py")},
        }
        self.archive = []
        self.parents = {}
        self.history = []
        self.games = 0
        self.cache_hits = 0
        self.started = time.perf_counter()
        files = {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
                 for path in [*FAMILY_PATHS.values(), ROOT / "evolved_reference.py", ROOT.parent / "arena.py",
                              ROOT.parent / "challengers.py", ROOT.parent / "comparison" / "user_snapshot_001" / "bot.py",
                              ROOT.parent / "comparison" / "user_corrected.py", Path(__file__)]}
        self.manifest = {"seed": args.seed, "generations": args.generations,
                         "response_generations": args.response_generations, "polish_generations": args.polish_generations,
                         "population": args.population, "workers": args.workers, "source_hashes": files,
                         "family_metadata": self.metadata,
                         "fitness": "0.78 mean pairwise + 0.20 minimum lineup pairwise + 0.02 strict first; faults penalized"}
        manifest_path = self.directory / "manifest.json"
        if manifest_path.exists():
            previous = read_json(manifest_path)
            if previous != self.manifest:
                raise ValueError("Resume configuration or source changed. Use a new run directory.")
        else:
            write_json(manifest_path, self.manifest)

    def add(self, family, config, parents=()):
        name = family + "_" + digest(config)[:12]
        if name not in self.registry:
            self.registry[name] = {"path": str(FAMILY_PATHS[family]), "family": family,
                                   "config_style": "dict", "config": config, "parents": list(parents)}
        return name

    def random_config(self, family):
        info = self.metadata[family]
        values = {}
        for name, (low, high) in info["bounds"].items():
            value = self.rng.uniform(low, high)
            values[name] = int(round(value)) if name in info["integers"] else round(value, 5)
        return values

    def offspring(self, family, parents, generation):
        if not parents or self.rng.random() < 0.16:
            return self.add(family, self.random_config(family))
        first = self.rng.choice(parents)
        second = self.rng.choice(parents)
        source = self.registry[first]["config"]
        other = self.registry[second]["config"]
        info = self.metadata[family]
        scale = max(0.045, 0.18 * (0.94 ** generation))
        config = {}
        changed = False
        for gene, (low, high) in info["bounds"].items():
            value = source[gene] if self.rng.random() < 0.65 else other[gene]
            if self.rng.random() < 0.30:
                value += self.rng.gauss(0, scale * (high - low))
                changed = True
            value = min(high, max(low, value))
            config[gene] = int(round(value)) if gene in info["integers"] else round(value, 5)
        if not changed:
            gene = self.rng.choice(list(info["bounds"]))
            low, high = info["bounds"][gene]
            value = min(high, max(low, config[gene] + self.rng.gauss(0, scale * (high - low))))
            config[gene] = int(round(value)) if gene in info["integers"] else round(value, 5)
        return self.add(family, config, (first, second))

    def initial_population(self):
        population = []
        per_family = self.args.population // len(self.metadata)
        for family, info in self.metadata.items():
            members = [self.add(family, dict(info["default"]))]
            if family == "economic" and per_family >= 4:
                for depth in (1, 3):
                    members.append(self.add(family, dict(info["default"], depth=depth)))
            while len(members) < per_family:
                candidate = self.offspring(family, members[:3], 0)
                if candidate not in members:
                    members.append(candidate)
            population.extend(members)
        return population

    def next_population(self, ranked, generation):
        population = []
        per_family = self.args.population // len(self.metadata)
        for family in self.metadata:
            parents = [name for name, stats in ranked if self.registry[name].get("family") == family]
            self.parents[family] = parents[:4]
            members = parents[:2]
            while len(members) < per_family:
                name = self.offspring(family, parents[:4], generation)
                if name not in members:
                    members.append(name)
            population.extend(members)
        return population

    def evaluate(self, executor, names, fixtures, phase):
        registry = {name: {key: value for key, value in spec.items() if key in
                          ("path", "name", "config", "config_style")} for name, spec in self.registry.items()}
        futures = {}
        for name in names:
            involved = {name, *(rival for fixture in fixtures for rival in fixture["opponents"])}
            used_registry = {key: registry[key] for key in sorted(involved)}
            fingerprint = digest({"target": name, "fixtures": fixtures, "registry": used_registry})
            file = self.directory / "cache" / (fingerprint + ".json.gz")
            futures[executor.submit(evaluate_job, (name, used_registry, fixtures, str(file)))] = name
        results = {}
        for future in as_completed(futures):
            name, rows, cached = future.result()
            results[name] = rows
            self.cache_hits += int(cached)
            if not cached:
                self.games += len(rows)
            write_json(self.directory / "progress.json", {
                "phase": phase, "completed_candidates": len(results), "candidates": len(names),
                "new_games": self.games, "elapsed_seconds": time.perf_counter() - self.started,
                "last_candidate": name, "last_summary": summary(rows)})
        return results

    def run(self):
        population = self.initial_population()
        total = self.args.generations + self.args.response_generations + self.args.polish_generations
        champion = "incumbent"
        response_ids = []
        with ProcessPoolExecutor(max_workers=self.args.workers) as executor:
            for generation in range(total):
                if generation < self.args.generations:
                    stage = "league"
                    rivals = self.rng.sample(self.archive, min(2, len(self.archive)))
                    rivals += ["macro", "lure", "old_adaptive"]
                    lineups = [["incumbent"] * 3, self.rng.sample(rivals, 3)]
                elif generation < self.args.generations + self.args.response_generations:
                    stage = "response"
                    if generation == self.args.generations:
                        champion = self.history[-1]["leader"]
                    lineups = [[champion] * 3, [champion, "incumbent", "macro"]]
                else:
                    stage = "polish"
                    tough = response_ids[-2:] or self.archive[-2:]
                    lineups = [["incumbent", champion, tough[-1]], [*tough, "macro"]]
                early, complete = fixture_panel(generation, lineups, 60000)
                phase = f"{stage} generation {generation + 1}/{total}"
                first = self.evaluate(executor, population, early, phase + " screen")
                ranked_early = sorted(((name, summary(rows)) for name, rows in first.items()),
                                      key=lambda pair: (pair[1]["fitness"], pair[0]), reverse=True)
                promoted = []
                for family in self.metadata:
                    family_names = [name for name, stats in ranked_early
                                    if self.registry[name]["family"] == family]
                    # Three survivors per architecture preserve different algorithms.
                    promoted.extend(family_names[:3])
                baseline_names = list(dict.fromkeys(["incumbent", champion]))
                confirmation = promoted + [name for name in baseline_names if name not in promoted]
                remaining = [fixture for fixture in complete if fixture not in early]
                continuing = [name for name in confirmation if name in first]
                newcomers = [name for name in confirmation if name not in first]
                full = self.evaluate(executor, continuing, remaining, phase + " confirmation")
                for name in continuing:
                    full[name] = first[name] + full[name]
                if newcomers:
                    full.update(self.evaluate(executor, newcomers, complete, phase + " reference"))
                ranked = sorted(((name, summary(rows)) for name, rows in full.items() if name in promoted),
                                key=lambda pair: (pair[1]["fitness"], pair[0]), reverse=True)
                leader, stats = ranked[0]
                entry = {"generation": generation, "stage": stage, "leader": leader,
                         "leader_summary": stats, "baseline_summary": summary(full["incumbent"]),
                         "ranked": [{"id": name, **row} for name, row in ranked],
                         "lineups": lineups, "fixtures": complete}
                self.history.append(entry)
                for name, _ in ranked[:3]:
                    if name not in self.archive:
                        self.archive.append(name)
                if stage == "response":
                    response_ids.append(leader)
                write_json(self.directory / f"generation_{generation:02}.json", entry)
                write_json(self.directory / "state.json", {"history": self.history, "registry": self.registry,
                           "archive": self.archive, "population": population, "new_games": self.games,
                           "response_ids": response_ids, "cache_hits": self.cache_hits})
                print(f"{phase}: {len(self.registry)} profiles, {self.games} new games; "
                      f"leader {leader} pairwise={stats['pairwise']:.3f}, "
                      f"first={stats['strict_first']:.3f}, baseline={summary(full['incumbent'])['pairwise']:.3f}",
                      flush=True)
                population = self.next_population(ranked, generation + 1)
        write_json(self.directory / "progress.json", {"phase": "evolution complete",
                   "new_games": self.games, "profiles": len(self.registry),
                   "elapsed_seconds": time.perf_counter() - self.started})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path, default=ROOT / "runs" / "transfer_001")
    parser.add_argument("--generations", type=int, default=10)
    parser.add_argument("--response-generations", type=int, default=4)
    parser.add_argument("--polish-generations", type=int, default=2)
    parser.add_argument("--population", type=int, default=36)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=20261106)
    args = parser.parse_args()
    if args.population % len(FAMILY_PATHS) or args.population < 9:
        parser.error("Population must be a multiple of three and at least nine")
    Evolution(args).run()


if __name__ == "__main__":
    main()
