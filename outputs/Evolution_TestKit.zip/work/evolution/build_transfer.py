"""Create a separate reproducible league seeded with the comparison leaders."""
import json
from pathlib import Path
import pprint

ROOT = Path(__file__).resolve().parent
source = (ROOT / "evolve.py").read_text(encoding="utf-8")
source = source.replace('"tactical": ROOT / "tactical.py"', '"user_route": ROOT / "user_family.py"')
source = source.replace('ROOT / "incumbent.py"', 'ROOT / "evolved_reference.py"')
source = source.replace('ROOT.parent / "planner_beam.py"',
                        'ROOT.parent / "comparison" / "user_snapshot_001" / "bot.py"')
source = source.replace('ROOT.parent / "planner_adaptive.py"',
                        'ROOT.parent / "comparison" / "user_corrected.py"')
start = source.index('        self.registry = {\n')
end = source.index('        self.archive = []', start)
source = source[:start] + '''        self.registry = {
            "incumbent": {"path": str(ROOT / "evolved_reference.py")},
            "fortress": {"path": str(ROOT.parent / "challengers.py"), "name": "fortress"},
            "lure": {"path": str(ROOT.parent / "challengers.py"), "name": "lure"},
            "macro": {"path": str(ROOT.parent / "comparison" / "user_snapshot_001" / "bot.py")},
            "old_adaptive": {"path": str(ROOT.parent / "comparison" / "user_corrected.py")},
        }
''' + source[end:]
genome = json.loads((ROOT.parent / "comparison" / "evolved_export.json").read_text())["config"]
marker = '        self.rng = random.Random(args.seed)'
source = source.replace(marker, '        self.metadata["economic"]["default"] = ' +
                        pprint.pformat(genome, width=100) + '\n' + marker)
source = source.replace('fixture_panel(generation, lineups, 20000)',
                        'fixture_panel(generation, lineups, 60000)')
source = source.replace('ROOT / "runs" / "league_001"', 'ROOT / "runs" / "transfer_001"')
old_return = '    return namespace["POLICIES"][spec["name"]] if "name" in spec else namespace["act"]'
new_return = '''    player = namespace["POLICIES"][spec["name"]] if "name" in spec else namespace["act"]
    if "Agent" not in namespace:
        return player
    caught = []
    original = namespace["Agent"].decide
    def audited_decide(agent, state):
        try:
            return original(agent, state)
        except Exception as error:
            caught.append(repr(error))
            raise
    namespace["Agent"].decide = audited_decide
    def audited_player(state):
        action = player(state)
        if caught:
            message = caught.pop(0)
            caught.clear()
            raise RuntimeError("Policy suppressed an internal exception: " + message)
        return action
    return audited_player'''
assert old_return in source
source = source.replace(old_return, new_return)
source = source.replace('                    tough = response_ids[-2:] or self.archive[-2:]\n', '                    tough = response_ids[-2:] or self.archive[-2:]\n                    if len(tough) == 1:\n                        tough = tough * 2\n')
source = source.replace('        manifest_path = self.directory / "manifest.json"', '        self.manifest = json.loads(json.dumps(self.manifest))\n        manifest_path = self.directory / "manifest.json"')
source = source.replace('    temporary.replace(path)\n', '    for attempt in range(25):\n        try:\n            temporary.replace(path)\n            return\n        except PermissionError:\n            if attempt == 24:\n                raise\n            time.sleep(0.02)\n', 1)
compile(source, "evolve_transfer.py", "exec")
(ROOT / "evolve_transfer.py").write_text(source, encoding="utf-8")
reference = ROOT.parent.parent / "outputs" / "bot_evolved.py"
(ROOT / "evolved_reference.py").write_bytes(reference.read_bytes())
print("Prepared a new league with the evolved economic reference and corrected user route family")
