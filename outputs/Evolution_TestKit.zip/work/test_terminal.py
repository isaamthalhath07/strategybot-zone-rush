"""Exhaustive joint-opponent-action checks for the final-turn dominance result."""
import copy
from itertools import product
import random
from arena import Game, HOMES
from planner_terminal import choose_terminal


def candidate(game, seat):
    state = game.state(seat)
    cells = [cell for row in state.board for cell in row]
    return choose_terminal(state, cells, seat, game.pos[seat-1], game.progress[seat-1])


def pairwise_margins(game, seat):
    score = game.scores[seat-1]
    return tuple(score-s for i, s in enumerate(game.scores, 1) if i != seat)


def variants():
    # Every constructed position has at least one intruder and exercises
    # a different local progress/home/freeze/collision configuration.
    for seed in range(32):
        rnd = random.Random(seed)
        g = Game(seed, "balanced", 1 + seed % 4, frozen_stays_progress=bool(seed % 2))
        me = seed % 4 + 1
        g.turn = 80
        free = [i for i in range(64) if i not in HOMES]
        g.pos = rnd.sample(free,4)
        g.scores = [rnd.randint(300,400) for _ in range(4)]
        g.progress = [rnd.randrange(3) for _ in range(4)]
        g.owner = [rnd.randrange(5) for _ in range(64)]
        g.upgraded = [bool(owner and rnd.randrange(2)) for owner in g.owner]
        for k,p in enumerate(HOMES,1):
            g.owner[p]=k
        foes=[k for k in range(4) if k+1!=me]
        for k in foes[:1+seed%3]:
            g.owner[g.pos[k]]=me
            g.frozen[k] = int(rnd.random() < .18)
        who=me-1
        typ=seed%6
        if typ==0:
            # Our own level-two holding yields no further upgrade.
            g.owner[g.pos[who]]=me
            g.upgraded[g.pos[who]]=True
        elif typ==1:
            # Incomplete upgrade on home.
            g.pos[who]=HOMES[who]
            g.upgraded[g.pos[who]]=False
            g.progress[who]=1
        elif typ==2:
            # A rival home is untakeable at every progress level.
            g.pos[who]=HOMES[foes[0]]
        elif typ==3:
            # An unfinished raid on upgraded land.
            g.owner[g.pos[who]]=foes[0]+1
            g.upgraded[g.pos[who]]=True
            g.progress[who]=1
        elif typ==4:
            # An unfinished upgrade on our non-home holding.
            g.owner[g.pos[who]]=me
            g.upgraded[g.pos[who]]=False
            g.progress[who]=0
        else:
            # Force two rival movers adjacent to a common free square and
            # therefore include blocked-move STAY captures among joint profiles.
            g.pos[who],g.pos[foes[0]],g.pos[foes[1]],g.pos[foes[2]]=20,27,29,36
            g.owner[20]=me
            g.upgraded[20]=True
            g.owner[27]=g.owner[29]=me
            g.upgraded[27]=g.upgraded[29]=False
            g.frozen = [0]*4
        yield g,me


def check():
    evaluations=improvements=0
    for g,me in variants():
        assert candidate(g,me)=="SHIELD"
        opponents=[i for i in range(4) if i!=me-1]
        for profile in product(*(g.legal(i) for i in opponents)):
            acts=["STAY"]*4
            for i,a in zip(opponents,profile):
                acts[i]=a
            after_stay,after_shield=copy.deepcopy(g),copy.deepcopy(g)
            after_stay.step(acts)
            acts[me-1]="SHIELD"
            after_shield.step(acts)
            baseline=pairwise_margins(after_stay,me)
            protected=pairwise_margins(after_shield,me)
            assert all(b<=p for b,p in zip(baseline,protected)),(g.pos,acts,baseline,protected)
            evaluations+=1
            improvements += protected!=baseline
    for who,up,progress in [(0,False,0),(2,False,0),(2,True,2),(1,False,2)]:
        g=Game()
        g.pos[0],g.pos[1]=10,18
        g.owner[10],g.owner[18]=who,1
        g.upgraded[10],g.progress[0]=up,progress
        assert candidate(g,1) is None
    print(evaluations,"joint-action profiles,",improvements,"strictly improved a score margin, zero worsened.")
    print("All four own scoring opportunity classes preserved.")


if __name__=="__main__":
    check()
