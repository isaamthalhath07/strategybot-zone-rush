import itertools,json,random
from pathlib import Path
configs={'default':{},'fortify':{'RAID_WEIGHT':.7,'UPGRADE_WEIGHT':1.8,'DEFENSE_WEIGHT':.8}}
for upgrade,raid in itertools.product([1.4,1.8,2.2,2.6,3.2],[.5,.8,1.1]):
 configs[f'u{upgrade}_r{raid}']={'UPGRADE_WEIGHT':upgrade,'RAID_WEIGHT':raid}
rng=random.Random(20261106)
for i in range(24):
 configs[f'variant{i:02}']={'UPGRADE_WEIGHT':round(rng.uniform(1.2,3.0),2),'RAID_WEIGHT':round(rng.uniform(.45,1.35),2),'DEFENSE_WEIGHT':rng.choice([0,.3,.7,1,1.5]),'ROUTE_WEIGHT':rng.choice([0,.25,.5,.8]),'RISK_WEIGHT':rng.choice([.5,1,2,4])}
Path('work/candidates.json').write_text(json.dumps(configs,indent=2))
