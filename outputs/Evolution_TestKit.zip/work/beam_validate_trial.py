from multiprocessing import Pool
from pathlib import Path
import json
from bench import run_game, summarize
configs={"beam_fort":{"UPGRADE":1.25,"RAID":.5,"DEFENSE":1.,"DEPTH":8,"WIDTH":12},"beam_mid":{"UPGRADE":1.35,"RAID":.8,"DEFENSE":1.,"DEPTH":8,"WIDTH":14}}
def run(x):
 cfg,label,pol,e=x
 spec=[pol[n] | ({"config":cfg,"label":label} if n=="beam" else {"label":n}) for n in e['bots']]
 return run_game(spec,seed=e['seed'],family=e['family'],token=e['token'],frozen_progress=e.get('frozen_progress',False))
if __name__=='__main__':
 j=json.loads(Path("architecture_selection.json").read_text())
 fixtures=[e for e in j["experiments"] if "beam" in e["bots"]]
 args=[(cfg,lab,j['policies'],e) for lab,cfg in configs.items() for e in fixtures]
 with Pool(4) as p: rec=list(p.map(run,args,chunksize=5))
 summary=summarize(rec)
 Path("beam_finalists_validation.json").write_text(json.dumps({"summary":summary,"records":rec}))
 print({name:summary[name] for name in configs})
