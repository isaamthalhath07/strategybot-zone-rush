@echo off
cd /d "%~dp0"
python play.py %*
