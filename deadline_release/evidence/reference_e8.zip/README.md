# Zone Rush portable release

Use Python 3.12. No installation, Git, Torch, NumPy or network connection is required.
Run `python play.py` (or double-click `play.cmd` on Windows), then open
http://127.0.0.1:8779/. Three separate copies of the selected bot play against you.
The menu also offers the explicitly retained tester bots.

Run `python -I -S -B tools/check_release.py` for the packaged rules, public-input,
catalog, recording and interface checks. These checks execute one opening per
source but no full policy games. An optional explicit process smoke is
`python -I -S -B tools/smoke_release.py --games 1`; this is a control/interface
check, not evidence that the bot is strongest. Its output and complete turn
recording are saved under `validation/`.

New games use the official STAY-only Shield interpretation. A moving rival
escapes; a blocked move counts as STAY. The simulator is a bundled local
reference, and the competition server remains authoritative. AI view exposes
only the four documented public fields. Ordinary play records observer history
under `simulator/history/`; that history is never supplied to bots.

`bot.py` and each tester are copied byte for byte. `release_manifest.json` pins
the selectable sources. `package_manifest.json` pins the shipped files, tool
closure and supplied public decision evidence. Local future play, snapshots,
and later validation reports are intentionally outside the original file map.
The research history remains in the development repository, outside this compact
runtime package. No selection or new research credit is created by packaging.

Selection status: **reference_only**. Selected source SHA-256: `e8b3682d8b39d3fc4d22cdcd8927161290a90cd472d3ede4132ae716f8c6f8f5`.

Known e8 reference portability check, not final selection.
